================================================================================
BUREAU VARIABLES - CROSS VALIDATION WITH EXCEL DATA
================================================================================
This script compares generated variables with your Excel data for validation

Requirements:
- openpyxl or pandas for reading Excel files
- Run this script to cross-check generated variables against your Excel data
================================================================================

import json
import os
import sqlite3
from datetime import datetime
import sys

# Try to import pandas for Excel reading
try:
    import pandas as pd
    PANDAS_AVAILABLE = True
except ImportError:
    PANDAS_AVAILABLE = False
    print("⚠️  pandas not available. Install with: pip install pandas openpyxl")

# Paths
WORKSPACE_PATH = r"c:\Users\yedavalli veneela\Desktop\creditiq_v10_final"
BACKEND_PATH = os.path.join(WORKSPACE_PATH, "backend")
DATABASE_PATH = os.path.join(BACKEND_PATH, "creditiq.db")
SAMPLE_DATA_FOLDER = os.path.join(WORKSPACE_PATH, "sample data")
GENERATED_RESULTS_FILE = os.path.join(WORKSPACE_PATH, "bureau_variable_execution_output.json")


# ═══════════════════════════════════════════════════════════════════════════════
# STEP 1: LOAD GENERATED VARIABLES
# ═══════════════════════════════════════════════════════════════════════════════

def load_generated_variables():
    """Load variables from JSON output file"""
    print("\n" + "="*80)
    print("STEP 1: LOADING GENERATED VARIABLES")
    print("="*80)
    
    if not os.path.exists(GENERATED_RESULTS_FILE):
        print(f"❌ ERROR: Generated results file not found at {GENERATED_RESULTS_FILE}")
        return None
    
    try:
        with open(GENERATED_RESULTS_FILE, 'r') as f:
            data = json.load(f)
        print(f"✅ Loaded generated variables from: {GENERATED_RESULTS_FILE}")
        print(f"   Timestamp: {data.get('metadata', {}).get('timestamp', 'N/A')}")
        print(f"   Total bureaus: {len(data.get('execution_results', {}))}")
        return data
    except Exception as e:
        print(f"❌ ERROR loading results: {str(e)}")
        return None


# ═══════════════════════════════════════════════════════════════════════════════
# STEP 2: FIND EXCEL FILES
# ═══════════════════════════════════════════════════════════════════════════════

def find_excel_files():
    """Find all Excel files in sample data folder"""
    print("\n" + "="*80)
    print("STEP 2: FINDING EXCEL FILES")
    print("="*80)
    
    if not os.path.exists(SAMPLE_DATA_FOLDER):
        print(f"⚠️  Sample data folder not found: {SAMPLE_DATA_FOLDER}")
        return {}
    
    excel_files = {}
    bureaus = ["CIBIL", "EQUIFAX", "EXPERIAN", "CRIF"]
    
    for filename in os.listdir(SAMPLE_DATA_FOLDER):
        if filename.endswith(('.xlsx', '.xls', '.csv')):
            filepath = os.path.join(SAMPLE_DATA_FOLDER, filename)
            print(f"✅ Found: {filename}")
            
            # Try to identify bureau
            for bureau in bureaus:
                if bureau.lower() in filename.lower():
                    excel_files[bureau] = filepath
                    print(f"   └─ Identified as: {bureau}")
                    break
    
    if not excel_files:
        print(f"⚠️  No Excel files found in {SAMPLE_DATA_FOLDER}")
    else:
        print(f"\n✅ Found {len(excel_files)} Excel file(s)")
    
    return excel_files


# ═══════════════════════════════════════════════════════════════════════════════
# STEP 3: READ EXCEL DATA
# ═══════════════════════════════════════════════════════════════════════════════

def read_excel_data(filepath):
    """Read Excel file and return data"""
    if not PANDAS_AVAILABLE:
        return None
    
    try:
        df = pd.read_excel(filepath)
        return df
    except Exception as e:
        print(f"❌ Error reading {filepath}: {str(e)}")
        return None


# ═══════════════════════════════════════════════════════════════════════════════
# STEP 4: COMPARE GENERATED VS EXCEL DATA
# ═══════════════════════════════════════════════════════════════════════════════

def compare_cibil_data(generated, excel_data):
    """Compare CIBIL generated variables with Excel data"""
    print("\n" + "-"*80)
    print("CIBIL COMPARISON")
    print("-"*80)
    
    if 'CIBIL' not in generated.get('execution_results', {}):
        print("❌ No CIBIL results in generated data")
        return None
    
    cibil_results = generated['execution_results'].get('CIBIL', [])
    
    if not cibil_results:
        print("❌ CIBIL results are empty")
        return None
    
    print(f"Generated CIBIL Variables: {len(cibil_results)}")
    for i, result in enumerate(cibil_results, 1):
        print(f"  {i}. {result.get('name', 'Unknown')}: {result.get('value', 'N/A')}")
    
    if excel_data is not None:
        print(f"\nExcel Data Rows: {len(excel_data)}")
        print("Excel Columns:", list(excel_data.columns))
        print("\nFirst 5 rows of Excel data:")
        print(excel_data.head())
    
    return cibil_results


def compare_equifax_data(generated, excel_data):
    """Compare EQUIFAX generated variables with Excel data"""
    print("\n" + "-"*80)
    print("EQUIFAX COMPARISON")
    print("-"*80)
    
    if 'EQUIFAX' not in generated.get('execution_results', {}):
        print("❌ No EQUIFAX results in generated data")
        return None
    
    equifax_results = generated['execution_results'].get('EQUIFAX', [])
    
    if not equifax_results:
        print("❌ EQUIFAX results are empty")
        return None
    
    print(f"Generated EQUIFAX Variables: {len(equifax_results)}")
    for i, result in enumerate(equifax_results, 1):
        print(f"  {i}. {result.get('name', 'Unknown')}: {result.get('value', 'N/A')}")
    
    if excel_data is not None:
        print(f"\nExcel Data Rows: {len(excel_data)}")
        print("Excel Columns:", list(excel_data.columns))
        print("\nFirst 5 rows of Excel data:")
        print(excel_data.head())
    
    return equifax_results


def compare_experian_data(generated, excel_data):
    """Compare EXPERIAN generated variables with Excel data"""
    print("\n" + "-"*80)
    print("EXPERIAN COMPARISON")
    print("-"*80)
    
    if 'EXPERIAN' not in generated.get('execution_results', {}):
        print("❌ No EXPERIAN results in generated data")
        return None
    
    experian_results = generated['execution_results'].get('EXPERIAN', [])
    
    if not experian_results:
        print("❌ EXPERIAN results are empty")
        return None
    
    print(f"Generated EXPERIAN Variables: {len(experian_results)}")
    for i, result in enumerate(experian_results, 1):
        print(f"  {i}. {result.get('name', 'Unknown')}: {result.get('value', 'N/A')}")
    
    if excel_data is not None:
        print(f"\nExcel Data Rows: {len(excel_data)}")
        print("Excel Columns:", list(excel_data.columns))
        print("\nFirst 5 rows of Excel data:")
        print(excel_data.head())
    
    return experian_results


def compare_crif_data(generated, excel_data):
    """Compare CRIF generated variables with Excel data"""
    print("\n" + "-"*80)
    print("CRIF COMPARISON")
    print("-"*80)
    
    if 'CRIF' not in generated.get('execution_results', {}):
        print("❌ No CRIF results in generated data")
        return None
    
    crif_results = generated['execution_results'].get('CRIF', [])
    
    if not crif_results:
        print("❌ CRIF results are empty")
        return None
    
    print(f"Generated CRIF Variables: {len(crif_results)}")
    for i, result in enumerate(crif_results, 1):
        print(f"  {i}. {result.get('name', 'Unknown')}: {result.get('value', 'N/A')}")
    
    if excel_data is not None:
        print(f"\nExcel Data Rows: {len(excel_data)}")
        print("Excel Columns:", list(excel_data.columns))
        print("\nFirst 5 rows of Excel data:")
        print(excel_data.head())
    
    return crif_results


# ═══════════════════════════════════════════════════════════════════════════════
# STEP 5: GENERATE VALIDATION REPORT
# ═══════════════════════════════════════════════════════════════════════════════

def generate_comparison_report(generated, excel_files_data):
    """Generate comparison report"""
    print("\n" + "="*80)
    print("STEP 5: COMPARISON REPORT")
    print("="*80)
    
    report = []
    report.append("\n" + "="*80)
    report.append("BUREAU VARIABLES - VALIDATION REPORT AGAINST EXCEL DATA")
    report.append("="*80)
    report.append(f"\nGenerated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
    
    # Summary
    report.append("SUMMARY")
    report.append("-" * 80)
    
    bureaus = ["CIBIL", "EQUIFAX", "EXPERIAN", "CRIF"]
    total_vars = 0
    
    for bureau in bureaus:
        results = generated.get('execution_results', {}).get(bureau, [])
        count = len(results)
        total_vars += count
        has_excel = "✓" if bureau in excel_files_data else "✗"
        report.append(f"{bureau:10} | Variables: {count} | Excel Data: {has_excel}")
    
    report.append(f"\nTotal Variables Generated: {total_vars}")
    report.append(f"Excel Files Found: {len(excel_files_data)}")
    
    # Detailed Results
    report.append("\n\nDETAILED RESULTS")
    report.append("=" * 80)
    
    for bureau in bureaus:
        report.append(f"\n{bureau}")
        report.append("-" * 80)
        
        # Generated variables
        results = generated.get('execution_results', {}).get(bureau, [])
        if results:
            report.append(f"Generated Variables ({len(results)}):")
            for result in results:
                name = result.get('name', 'Unknown')
                value = result.get('value', 'N/A')
                valid = result.get('valid', False)
                status = "✓" if valid else "✗"
                report.append(f"  {status} {name}: {value}")
        else:
            report.append("No generated variables")
        
        # Excel data
        if bureau in excel_files_data:
            excel_df = excel_files_data[bureau]
            if excel_df is not None:
                report.append(f"\nExcel Data ({len(excel_df)} rows):")
                report.append(f"  Columns: {', '.join(excel_df.columns)}")
                report.append(f"  First row: {excel_df.iloc[0].to_dict() if len(excel_df) > 0 else 'N/A'}")
                
                # Try to find matching columns
                report.append(f"\n  Column Analysis:")
                for col in excel_df.columns:
                    report.append(f"    - {col}: {excel_df[col].dtype}")
            else:
                report.append("Could not read Excel file")
        else:
            report.append("No Excel file for this bureau")
    
    # Instructions
    report.append("\n\nNEXT STEPS - HOW TO VALIDATE")
    report.append("=" * 80)
    report.append("""
1. MANUAL COMPARISON:
   - Check each generated variable value against your Excel data
   - Verify aggregation logic matches your expectations
   - Look for: COUNT, SUM, AVG, MAX, RATIO calculations
   
2. IDENTIFY MATCHING COLUMNS:
   - Excel columns that correspond to each variable
   - Example: "total_accounts" in Excel matches var_cibil_001
   
3. VERIFY CALCULATIONS:
   - For COUNT: Sum of matching records
   - For SUM: Total of numeric column
   - For AVG: Average of numeric column
   - For MAX: Maximum value in column
   - For RATIO: Value1 / Value2
   
4. DOCUMENT DIFFERENCES:
   - If Excel value differs from generated value:
     a) Check if Excel column name matches variable logic
     b) Verify filter conditions (time window, scope)
     c) Check for data quality issues in Excel
   
5. ADJUST IF NEEDED:
   - Update variable configuration if logic was wrong
   - Re-run variable generator with corrected logic
   - Re-validate against Excel
    """)
    
    # Additional Help
    report.append("\nMATCHING GUIDE - ASSOCIATE EXCEL COLUMNS WITH VARIABLES")
    report.append("=" * 80)
    report.append("""
CIBIL Variables:
├─ var_cibil_001 (Total Accounts - COUNT)
│  └─ Look in Excel for: "accounts", "account_count", "no_of_accounts"
└─ var_cibil_002 (Outstanding Balance - SUM)
   └─ Look in Excel for: "balance", "outstanding", "total_balance"

EQUIFAX Variables:
├─ var_equifax_001 (Secured Ratio - RATIO)
│  └─ Look in Excel for: "secured_count" / "total_count"
└─ var_equifax_002 (Recent Inquiries - COUNT)
   └─ Look in Excel for: "inquiries", "inquiry_3m", "recent_inquiries"

EXPERIAN Variables:
├─ var_experian_001 (DPD Max - MAX)
│  └─ Look in Excel for: "dpd", "days_past_due", "max_dpd"
└─ var_experian_002 (Utilization - AVG)
   └─ Look in Excel for: "utilization", "credit_util", "usage_ratio"

CRIF Variables:
├─ var_crif_001 (Account Age - AVG)
│  └─ Look in Excel for: "account_age", "age_months", "account_opened"
└─ var_crif_002 (Defaults - COUNT)
   └─ Look in Excel for: "defaults", "default_count", "written_off"
    """)
    
    return"\n".join(report)


# ═══════════════════════════════════════════════════════════════════════════════
# STEP 6: SAVE VALIDATION REPORT
# ═══════════════════════════════════════════════════════════════════════════════

def save_report(report_content):
    """Save validation report to file"""
    report_file = os.path.join(WORKSPACE_PATH, "VALIDATION_REPORT_EXCEL_vs_GENERATED.txt")
    
    try:
        with open(report_file, 'w') as f:
            f.write(report_content)
        print(f"\n✅ Report saved: {report_file}")
        return report_file
    except Exception as e:
        print(f"❌ Error saving report: {str(e)}")
        return None


# ═══════════════════════════════════════════════════════════════════════════════
# MAIN EXECUTION
# ═══════════════════════════════════════════════════════════════════════════════

def main():
    """Main execution"""
    print("\n" + "█"*80)
    print("█" + " "*78 + "█")
    print("█" + "  BUREAU VARIABLES - CROSS VALIDATION WITH EXCEL DATA".center(78) + "█")
    print("█" + " "*78 + "█")
    print("█"*80)
    
    # Load generated variables
    generated = load_generated_variables()
    if not generated:
        print("❌ Cannot proceed without generated variables")
        return
    
    # Find Excel files
    excel_files = find_excel_files()
    
    # Read Excel data
    excel_files_data = {}
    if PANDAS_AVAILABLE:
        for bureau, filepath in excel_files.items():
            print(f"\nReading {bureau} Excel file...")
            df = read_excel_data(filepath)
            if df is not None:
                excel_files_data[bureau] = df
                print(f"✅ Loaded {len(df)} rows")
            else:
                print(f"❌ Failed to load")
    else:
        print("\n⚠️  Pandas not available. Cannot read Excel files.")
        print("   Install with: pip install pandas openpyxl")
        print("   Using only generated variables for comparison")
    
    # Compare data by bureau
    print("\n" + "="*80)
    print("STEP 3: DETAILED COMPARISON BY BUREAU")
    print("="*80)
    
    compare_cibil_data(generated, excel_files_data.get('CIBIL'))
    compare_equifax_data(generated, excel_files_data.get('EQUIFAX'))
    compare_experian_data(generated, excel_files_data.get('EXPERIAN'))
    compare_crif_data(generated, excel_files_data.get('CRIF'))
    
    # Generate report
    report = generate_comparison_report(generated, excel_files_data)
    
    # Save report
    report_file = save_report(report)
    
    # Print summary
    print("\n" + "="*80)
    print("VALIDATION COMPLETE")
    print("="*80)
    print(f"✅ Generated variables compared with Excel data")
    print(f"✅ Report saved to: {report_file}")
    print(f"\n📋 Next steps:")
    print(f"   1. Review the report file")
    print(f"   2. Identify matching Excel columns for each variable")
    print(f"   3. Verify calculations are correct")
    print(f"   4. Adjust variable configurations if needed")
    print(f"   5. Re-run generator with corrected logic if necessary")
    print("="*80 + "\n")


if __name__ == "__main__":
    main()

# CreditIQ Quick Reference Card
## Cheat Sheet for All Workflows

---

## 🚀 QUICK START (Copy-Paste)

### Terminal 1: Start Backend
```bash
cd backend
python main.py
```

### Browser: Open Dashboard
```
http://localhost:8000/dashboard.html
```

---

## 📊 THREE MAIN WORKFLOWS

### 🔬 **WORKFLOW A: Data Scientist** (UI-Based)
1. Open Dashboard → **"📊 Variable Browser"** → Search variables
2. Click **"⚙️ Generator"** → Select "Production" → Generate 1,200
3. Click **"▶️ Execution"** → Pick build → Start job
4. Click **"📈 Results"** → Download JSON/CSV
5. Use results in Python/Excel/BI tool

**Time:** 10-30 minutes | **Coding:** None

---

### 💻 **WORKFLOW B: ML Engineer** (API-Based)
```python
import requests

# 1. Generate
resp = requests.get("http://localhost:8000/api/variables/generate?subset=production")
vars = resp.json()["variables"]  # 1,200 variables

# 2. Execute
resp = requests.post("http://localhost:8000/api/variables/execute", 
    json={"build_id": 1, "bureau": "CIBIL"})
batch_id = resp.json()["batch_id"]

# 3. Monitor
resp = requests.get(f"http://localhost:8000/api/variables/batch/{batch_id}")
status = resp.json()  # Check progress

# 4. Download
resp = requests.get(f"http://localhost:8000/api/variables/batch/{batch_id}/results")
results = resp.json()["results"]

# 5. Process
import pandas as pd
df = pd.DataFrame(results)  # Ready for ML!
```

**Time:** 5-20 minutes | **Coding:** Required

---

### 📈 **WORKFLOW C: Analyst** (Comparison-Based)
1. Open Dashboard → **"🔄 Comparison"** tab
2. Select: Variable 1 & Variable 2
3. Sample size: 100 customers
4. View: Correlation, distribution, statistics
5. Repeat for hypothesis testing

**Time:** 5 minutes per comparison | **Coding:** None

---

## 🎯 FIVE MOST COMMON TASKS

### Task 1: Generate 1,200 Production Variables
**UI:**
```
Dashboard → ⚙️ Generator → Select "Production (1,200)" → Generate
```

**API:**
```bash
curl "http://localhost:8000/api/variables/generate?subset=production"
```

**Output:** 1,200 balanced variables (240 each type)

---

### Task 2: Execute Variables Against Data
**UI:**
```
Dashboard → ▶️ Execution → Select Build → Start
```

**API:**
```bash
curl -X POST "http://localhost:8000/api/variables/execute" \
  -H "Content-Type: application/json" \
  -d '{"build_id": 1, "bureau": "CIBIL"}'
```

**Output:** Batch ID for monitoring

---

### Task 3: Download Results
**UI:**
```
Dashboard → 📈 Results → Select Batch → ⬇️ Download
```

**API:**
```bash
curl "http://localhost:8000/api/variables/batch/42/results?format=json"
```

**Output:** JSON or CSV with 1,200 features × N customers

---

### Task 4: Monitor Batch Status
**UI:**
```
Dashboard → ▶️ Execution → View Status Table
```

**API:**
```bash
curl "http://localhost:8000/api/variables/batch/42"
```

**Output:** Status, progress, success/fail counts

---

### Task 5: Compare Variables
**UI:**
```
Dashboard → 🔄 Comparison → Pick 2 variables → Compare
```

**API:**
```bash
curl -X POST "http://localhost:8000/api/variables/compare" \
  -H "Content-Type: application/json" \
  -d '{"variable_ids": [1, 2], "customer_sample_size": 100}'
```

**Output:** Correlation, statistics, insights

---

## 📁 WHAT TO WORK WITH

### Available Variables: 8,128 Total
```
Enquiry:        714 (8.8%)      ✓ Volume, recency, inquiry patterns
Trade:         3,426 (42.2%)    ✓ DPD, delinquency, payment behavior  
Account:       1,878 (23.1%)    ✓ Tenure, balance history, utilization
Trade History: 2,040 (25.1%)    ✓ DPD patterns, payment consistency
Cross-Product:   70 (0.9%)      ✓ Inquiry↔Trade relationships

All 6 Time Windows: 1m, 3m, 6m, 12m, 24m, 36m
All 15 Aggregations: count, sum, avg, max, min, median, std, cv, etc.
```

### Production Subset: 1,200 Recommended
```
Best of each type (~240 variables)
- Highest variance features
- Balanced across all types  
- Ready for model training
- Recommended first choice
```

---

## 🔍 HOW TO SEARCH

### Search by Variable Type
```
Filter: Enquiry → See 714 inquiry variables
Filter: Trade → See 3,426 trade variables
Filter: Account → See 1,878 account variables
```

### Search by Pattern
```
Search "dpd" → All DPD-related variables
Search "payment" → All payment pattern variables
Search "consistency" → All consistency/regularity vars
Search "1m" → All 1-month window variables
```

### Search by Category
```
volume → Count of transactions/accounts
amount → Sum/average of balance/exposure
dpd → Days past due metrics
utilization → Credit limit utilization
payment → Payment behavior patterns
```

---

## 💾 OUTPUT FORMATS

### JSON Format
```json
{
  "batch_id": 42,
  "total": 5000,
  "results": [
    {
      "customer_id": "CUST-001",
      "feature_name": "enq_volume_count_1m",
      "feature_value": 3.5,
      "status": "ready"
    },
    ...
  ]
}
```
**Use for:** Python, ML pipelines, APIs

### CSV Format
```csv
customer_id,enq_volume_count_1m,trade_dpd_history_consistency,...
CUST-001,3.5,75.2,...
CUST-002,2.1,82.3,...
```
**Use for:** Excel, Power BI, R, SQL

---

## 🔗 API ENDPOINTS (All 15)

| Method | Endpoint | Purpose |
|--------|----------|---------|
| GET | `/api/variables/generate` | Generate variables |
| GET | `/api/variables/list` | Browse with filter |
| GET | `/api/variables/production` | Get 1,200 subset |
| GET | `/api/variables/{id}/details` | Variable metadata |
| POST | `/api/variables/bulk-create` | Create batch |
| POST | `/api/variables/execute` | Execute variables |
| GET | `/api/variables/batch/{id}` | Check status |
| GET | `/api/variables/batch/{id}/results` | Download results |
| POST | `/api/variables/compare` | Compare variables |

**Base URL:** `http://localhost:8000`

---

## ⏱️ TYPICAL TIMES

```
Generate 1,200 variables:     < 1 second
Create batch in build:        < 2 seconds
Execute 1,200 variables:      5-30 minutes (depends on data)
Download results:             < 5 seconds
Compare 2 variables:          < 2 seconds
Total workflow:               10-45 minutes
```

---

## 🛠️ TROUBLESHOOTING

### Dashboard Won't Load
```bash
# Check backend is running
curl http://localhost:8000/health
# Should return: {"status": "ok", ...}

# If not working:
# Terminal: python main.py
```

### Batch Execution Slow
```
Normal: 5-30 minutes depends on data volume
Check: /api/variables/batch/{id} for progress
Monitor: Success count increasing over time
```

### Features Missing
```
Check: Did you select correct variable types?
Check: Did you select correct bureau (CIBIL/Equifax/Experian)?
Check: Are there customers with data for that bureau?
```

### API Returns Error
```bash
# Check API is working
curl "http://localhost:8000/api/variables/list"

# If error, check main.py includes router:
grep "var_mgmt_router" backend/main.py
```

---

## 📚 FILES TO KNOW

| File | Purpose |
|------|---------|
| `frontend/dashboard.html` | Interactive UI |
| `backend/routers/variable_management.py` | 15 API endpoints |
| `backend/services/variable_generator.py` | Generates 8,128 variables |
| `backend/bureau/feature_engine.py` | Executes calculations |
| `backend/bureau/behavioral_engine.py` | DPD scoring, composites |
| `WORKFLOW_GUIDE.md` | This guide (complete) |
| `PHASE_3_SUMMARY.md` | Implementation overview |
| `PHASE_3_FRONTEND_INTEGRATION.md` | API reference |

---

## 🚀 NEXT STEPS

1. **Start Backend**
   ```bash
   cd backend && python main.py
   ```

2. **Open Dashboard**
   ```
   http://localhost:8000/dashboard.html
   ```

3. **Generate Features**
   ```
   Click ⚙️ Generator → Select "Production" → Generate
   ```

4. **Execute Variables**
   ```
   Click ▶️ Execution → Select Build → Start Job
   ```

5. **Download Results**
   ```
   Click 📈 Results → Select Batch → Download JSON
   ```

6. **Analyze**
   ```python
   import json
   with open("results.json") as f:
       data = json.load(f)
   # Ready for modeling!
   ```

---

## ✨ KEY FEATURES

✅ **8,128 total variables** generated from metadata  
✅ **1,200 production-ready** curated subset  
✅ **5 variable types** completely covered  
✅ **15 API endpoints** for automation  
✅ **Interactive dashboard** for exploration  
✅ **Monitoring & status** tracking  
✅ **Multiple export formats** (JSON, CSV)  
✅ **Real-time comparison** analytics  

---

**YOU'RE READY! Start with: `http://localhost:8000/dashboard.html`** 🚀

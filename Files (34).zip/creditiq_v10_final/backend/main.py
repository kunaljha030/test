"""
CreditIQ — FastAPI Backend
Entry point — serves frontend + API both
"""
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, Response
import os
import json

from core.config import settings
from db.database import Base, engine, SessionLocal
from routers import auth, builds, variables, bureau, beneficiaries
from db.models import User, Variable
from services.variable_service import _extract_scope_fields
from routers.feature_builder import router as builder_router   # ← NEW
from routers.variable_management import router as var_mgmt_router  # ← PHASE 3

# ── Create all DB tables ──────────────────────────
Base.metadata.create_all(bind=engine)

# ── Safe migration: add any missing columns ────────
def _run_migrations():
    from sqlalchemy import text, inspect
    with engine.connect() as conn:
        inspector = inspect(engine)
        
        # Add 'source' column to variables if missing
        var_cols = [c['name'] for c in inspector.get_columns('variables')]
        if 'source' not in var_cols:
            conn.execute(text("ALTER TABLE variables ADD COLUMN source VARCHAR(20)"))
            conn.commit()
            print("[migration] Added 'source' column to variables")
        variable_column_defs = {
            "product_scope": "VARCHAR(255)",
            "secured_scope": "VARCHAR(50)",
            "lender_scope": "TEXT",
            "loan_type_scope": "TEXT",
            "account_status_scope": "VARCHAR(100)",
            "ownership_scope": "VARCHAR(100)",
        }
        for col_name, col_type in variable_column_defs.items():
            if col_name not in var_cols:
                conn.execute(text(f"ALTER TABLE variables ADD COLUMN {col_name} {col_type}"))
                conn.commit()
                print(f"[migration] Added '{col_name}' column to variables")

        # Add 'description' column to builds if missing
        build_cols = [c['name'] for c in inspector.get_columns('builds')]
        if 'description' not in build_cols:
            conn.execute(text("ALTER TABLE builds ADD COLUMN description TEXT"))
            conn.commit()
            print("[migration] Added 'description' column to builds")

        inquiry_cols = [c['name'] for c in inspector.get_columns('normalized_inquiries')]
        inquiry_column_defs = {
            "member_id": "VARCHAR(100)",
            "ownership_type": "VARCHAR(50)",
            "inquiry_purpose": "VARCHAR(100)",
        }
        for col_name, col_type in inquiry_column_defs.items():
            if col_name not in inquiry_cols:
                conn.execute(text(f"ALTER TABLE normalized_inquiries ADD COLUMN {col_name} {col_type}"))
                conn.commit()
                print(f"[migration] Added '{col_name}' column to normalized_inquiries")

try:
    _run_migrations()
except Exception as e:
    print(f"[migration] {e}")

def _backfill_variable_scopes():
    db = SessionLocal()
    try:
        updated = 0
        for var in db.query(Variable).all():
            scopes = _extract_scope_fields(json.loads(var.config_json or "{}"))
            dirty = False
            for key, value in scopes.items():
                if not getattr(var, key, None):
                    setattr(var, key, value)
                    dirty = True
            if dirty:
                updated += 1
        if updated:
            db.commit()
            print(f"[migration] Backfilled scope fields for {updated} variables")
    except Exception as e:
        db.rollback()
        print(f"[migration] scope backfill: {e}")
    finally:
        db.close()

_backfill_variable_scopes()

# ── Auto-create guest user if not exists ──────────
def _ensure_guest_user():
    from db.database import SessionLocal
    from core.security import hash_password
    db = SessionLocal()
    try:
        existing = db.query(User).filter(User.username == "guest").first()
        if not existing:
            guest = User(
                email="guest@creditiq.local",
                username="guest",
                hashed_password=hash_password("guest")
            )
            db.add(guest); db.commit()
    except Exception as e:
        print(f"[startup] guest user init: {e}")
    finally:
        db.close()

_ensure_guest_user()

app = FastAPI(
    title="CreditIQ API",
    description="Credit Intelligence Variable Studio",
    version="2.0.0",
)

# ── CORS ─────────────────────────────────────────
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*", "null"],   # "null" covers file:// protocol requests
    allow_credentials=False,        # Must be False when allow_origins=["*"]
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── API Routers ───────────────────────────────────
app.include_router(auth.router,      tags=["Auth"])
app.include_router(builds.router,    tags=["Builds"])
app.include_router(builds.router,    prefix="/api", tags=["Builds"])
app.include_router(variables.router, tags=["Variables"])
app.include_router(bureau.router,    tags=["Bureau"])
app.include_router(beneficiaries.router, tags=["Beneficiaries"])
app.include_router(builder_router)                             # ← /builder/* endpoints
app.include_router(var_mgmt_router, prefix="/api/variables", tags=["Variable Management"])  # ← PHASE 3


@app.get("/health", tags=["Health"])
def health():
    return {"status": "ok", "app": "CreditIQ API", "version": "1.0.0"}


# ── Serve Frontend Static Files ───────────────────
# Frontend folder should be at: backend/../frontend/
FRONTEND_DIR = os.path.join(os.path.dirname(__file__), "..", "frontend")
FRONTEND_DIR = os.path.abspath(FRONTEND_DIR)

if os.path.exists(FRONTEND_DIR):
    # Serve static files (css, js, images etc)
    app.mount("/static", StaticFiles(directory=FRONTEND_DIR), name="static")

    @app.get("/", include_in_schema=False)
    def serve_frontend():
        return FileResponse(os.path.join(FRONTEND_DIR, "main.html"))

    @app.get("/index.html", include_in_schema=False)
    def serve_index():
        return FileResponse(os.path.join(FRONTEND_DIR, "main.html"))

    @app.get("/app.js", include_in_schema=False)
    def serve_js():
        return FileResponse(os.path.join(FRONTEND_DIR, "app.js"))

    @app.get("/api.js", include_in_schema=False)
    def serve_api_js():
        return FileResponse(os.path.join(FRONTEND_DIR, "api.js"))

    @app.get("/auth.js", include_in_schema=False)
    def serve_auth_js():
        return FileResponse(os.path.join(FRONTEND_DIR, "auth.js"))

    @app.get("/style.css", include_in_schema=False)
    def serve_css():
        return FileResponse(os.path.join(FRONTEND_DIR, "style.css"))

    @app.get("/cascade_bridge.js", include_in_schema=False)
    def serve_bridge():
        return FileResponse(os.path.join(FRONTEND_DIR, "cascade_bridge.js"))

    @app.get("/dashboard.html", include_in_schema=False)
    def serve_dashboard():
        return FileResponse(os.path.join(FRONTEND_DIR, "dashboard.html"))

    @app.get("/favicon.ico", include_in_schema=False)
    def serve_favicon():
        favicon_path = os.path.join(FRONTEND_DIR, "favicon.ico")
        if os.path.exists(favicon_path):
            return FileResponse(favicon_path)
        # Return a 204 No Content if favicon.ico doesn't exist
        return Response(status_code=204)

else:
    @app.get("/", tags=["Health"])
    def root():
        return {
            "status": "ok",
            "message": "Frontend folder not found. Place frontend/ next to backend/",
            "docs": "/docs"
        }

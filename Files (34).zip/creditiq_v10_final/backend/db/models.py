"""db/models.py — SQLAlchemy ORM table models"""
import json
from datetime import datetime
from sqlalchemy import Column, Integer, String, Text, DateTime, ForeignKey, Float, Boolean
from sqlalchemy.orm import relationship
from db.database import Base


class User(Base):
    __tablename__ = "users"
    id               = Column(Integer, primary_key=True, index=True)
    email            = Column(String(255), unique=True, index=True)
    username         = Column(String(100), unique=True, index=True)
    hashed_password  = Column(String(255))
    created_at       = Column(DateTime, default=datetime.utcnow)


class Build(Base):
    __tablename__ = "builds"
    id              = Column(Integer, primary_key=True, index=True)
    name            = Column(String(255), index=True)
    owner           = Column(String(100), index=True)
    bureau          = Column(String(50), nullable=True)
    file_type       = Column(String(50), nullable=True)
    file_identifier = Column(String(255), nullable=True)
    description     = Column(Text, nullable=True)
    created_at      = Column(DateTime, default=datetime.utcnow)
    updated_at      = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    variables        = relationship("Variable", back_populates="build", cascade="all, delete")
    beneficiaries    = relationship("Beneficiary", back_populates="build", cascade="all, delete")
    execution_runs   = relationship("ExecutionRun", back_populates="build", cascade="all, delete")
    trade_outputs    = relationship("TradeVariableOutput", back_populates="build", cascade="all, delete")
    output_builds    = relationship("OutputBuild", back_populates="build", cascade="all, delete")


class Beneficiary(Base):
    __tablename__ = "beneficiaries"
    id             = Column(Integer, primary_key=True, index=True)
    owner          = Column(String(100), index=True)
    build_id       = Column(Integer, ForeignKey("builds.id"), nullable=True, index=True)
    name           = Column(String(255), nullable=False)
    bank_name      = Column(String(255), nullable=False)
    account_number = Column(String(100), nullable=False)
    avatar_letter  = Column(String(4), nullable=True)
    avatar_color   = Column(String(50), nullable=True)
    created_at     = Column(DateTime, default=datetime.utcnow)
    updated_at     = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    build = relationship("Build", back_populates="beneficiaries")


class Variable(Base):
    __tablename__ = "variables"
    id            = Column(Integer, primary_key=True, index=True)
    name          = Column(String(255), index=True)
    build_id      = Column(Integer, ForeignKey("builds.id"))
    variable_type = Column(String(50))
    sub_category  = Column(String(100), nullable=True)
    measure       = Column(String(100), nullable=True)
    aggregation   = Column(String(50), nullable=True)
    time_window   = Column(String(50), nullable=True)
    product_scope = Column(String(255), nullable=True)
    secured_scope = Column(String(50), nullable=True)
    lender_scope  = Column(Text, nullable=True)
    loan_type_scope = Column(Text, nullable=True)
    account_status_scope = Column(String(100), nullable=True)
    ownership_scope = Column(String(100), nullable=True)
    config_json   = Column(Text, default="{}")
    source        = Column(String(20), nullable=True)  # 'wizard' or 'catalog'
    created_at    = Column(DateTime, default=datetime.utcnow)

    build = relationship("Build", back_populates="variables")
    output_builds = relationship("OutputBuild", back_populates="variable", cascade="all, delete")

    @property
    def config(self):
        return json.loads(self.config_json or "{}")


class ExecutionRun(Base):
    __tablename__ = "execution_runs"
    id            = Column(Integer, primary_key=True, index=True)
    build_id      = Column(Integer, ForeignKey("builds.id"))
    bureau        = Column(String(50))
    file_name     = Column(String(255), nullable=True)
    parse_status  = Column(String(50), default="pending")
    error_message = Column(Text, nullable=True)
    started_at    = Column(DateTime, default=datetime.utcnow)
    finished_at   = Column(DateTime, nullable=True)

    build           = relationship("Build", back_populates="execution_runs")
    feature_outputs = relationship("FeatureOutput", back_populates="run", cascade="all, delete")


class NormalizedApplicant(Base):
    __tablename__ = "normalized_applicant"
    id            = Column(Integer, primary_key=True, index=True)
    run_id        = Column(Integer, ForeignKey("execution_runs.id"))
    customer_id   = Column(String(100), index=True)
    full_name     = Column(String(255), nullable=True)
    date_of_birth = Column(String(50), nullable=True)
    pan           = Column(String(20), nullable=True)
    mobile        = Column(String(20), nullable=True)
    bureau_source = Column(String(50))


class NormalizedAccount(Base):
    __tablename__ = "normalized_accounts"
    id               = Column(Integer, primary_key=True, index=True)
    run_id           = Column(Integer, ForeignKey("execution_runs.id"))
    customer_id      = Column(String(100), index=True)
    account_number   = Column(String(100), nullable=True)
    lender_name      = Column(String(255), nullable=True)
    loan_type        = Column(String(50), nullable=True)
    account_status   = Column(String(50), nullable=True)
    ownership_type   = Column(String(50), nullable=True)
    sanction_amount  = Column(Float, nullable=True)
    current_balance  = Column(Float, nullable=True)
    overdue_amount   = Column(Float, nullable=True)
    emi_amount       = Column(Float, nullable=True)
    credit_limit     = Column(Float, nullable=True)
    dpd              = Column(Integer, nullable=True)
    writeoff_amount  = Column(Float, nullable=True)
    date_opened      = Column(String(50), nullable=True)
    date_closed      = Column(String(50), nullable=True)
    date_reported    = Column(String(50), nullable=True)
    last_payment_date = Column(String(50), nullable=True)
    is_secured       = Column(Boolean, nullable=True)
    bureau_source    = Column(String(50))
    dpd_string       = Column(Text, nullable=True)
    balance_history  = Column(Text, nullable=True)


class NormalizedInquiry(Base):
    __tablename__ = "normalized_inquiries"
    id             = Column(Integer, primary_key=True, index=True)
    run_id         = Column(Integer, ForeignKey("execution_runs.id"))
    customer_id    = Column(String(100), index=True)
    member_id      = Column(String(100), nullable=True)
    ownership_type = Column(String(50), nullable=True)
    inquiry_date   = Column(String(50), nullable=True)
    inquiry_amount = Column(Float, nullable=True)
    inquiry_purpose = Column(String(100), nullable=True)
    loan_type      = Column(String(50), nullable=True)
    lender_name    = Column(String(255), nullable=True)
    is_secured     = Column(Boolean, nullable=True)
    bureau_source  = Column(String(50))


class FeatureOutput(Base):
    __tablename__ = "feature_outputs"
    id            = Column(Integer, primary_key=True, index=True)
    run_id        = Column(Integer, ForeignKey("execution_runs.id"))
    customer_id   = Column(String(100), index=True)
    feature_name  = Column(String(255), index=True)
    feature_value = Column(Text, nullable=True)
    status        = Column(String(50), default="ready")
    skip_reason   = Column(Text, nullable=True)

    run = relationship("ExecutionRun", back_populates="feature_outputs")


class TradeVariableOutput(Base):
    __tablename__ = "trade_variable_outputs"
    id              = Column(Integer, primary_key=True, index=True)
    build_id        = Column(Integer, ForeignKey("builds.id"), nullable=True, index=True)
    variable_name   = Column(String(255), index=True)
    variable_type   = Column(String(50), default="Trade")
    sub_category    = Column(String(100), nullable=True)
    measure         = Column(String(100), nullable=True)
    aggregation     = Column(String(50), nullable=True)
    time_window     = Column(String(50), nullable=True)
    loan_type_scope = Column(Text, nullable=True)
    secured_scope   = Column(String(50), nullable=True)
    config_json     = Column(Text, default="{}")
    generated_at    = Column(DateTime, default=datetime.utcnow)

    build = relationship("Build", back_populates="trade_outputs")


class OutputBuild(Base):
    __tablename__ = "output_builds"
    id              = Column(Integer, primary_key=True, index=True)
    build_id        = Column(Integer, ForeignKey("builds.id"), index=True)
    variable_id     = Column(Integer, ForeignKey("variables.id"), index=True)
    run_id          = Column(Integer, ForeignKey("execution_runs.id"), nullable=True, index=True)
    variable_name   = Column(String(255), index=True)
    variable_type   = Column(String(50), nullable=True)
    row_type        = Column(String(50), default="detail")  # summary or detail
    output_value    = Column(Text, nullable=True)
    customer_id     = Column(String(100), nullable=True, index=True)
    member_id       = Column(String(100), nullable=True)
    ownership_type  = Column(String(50), nullable=True)
    inquiry_date    = Column(String(50), nullable=True)
    inquiry_purpose = Column(String(100), nullable=True)
    loan_type       = Column(String(50), nullable=True)
    lender_name     = Column(String(255), nullable=True)
    inquiry_amount  = Column(Float, nullable=True)
    source_table    = Column(String(100), default="normalized_inquiries")
    details_json    = Column(Text, default="{}")
    created_at      = Column(DateTime, default=datetime.utcnow)

    build = relationship("Build", back_populates="output_builds")
    variable = relationship("Variable", back_populates="output_builds")

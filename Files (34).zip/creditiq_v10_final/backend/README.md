# CreditIQ — Quick Start Guide

## ⚠️ IMPORTANT — Do NOT open HTML file directly

Do NOT double-click `frontend/main.html` to open it.
This will NOT work because browser blocks API calls from `file://` protocol.

---

## ✅ Correct Way to Run

### Windows
Double-click `start.bat` from the project root folder.

OR run manually:
```
cd backend
pip install -r requirements.txt
uvicorn main:app --reload --port 8000
```

### Mac / Linux
```bash
chmod +x start.sh
./start.sh
```

OR:
```bash
cd backend
pip install -r requirements.txt
uvicorn main:app --reload --port 8000
```

---

## Open in Browser

After backend starts, open:

**http://localhost:8000**

Login with:
- Username: `guest`
- Password: `guest`

---

## What gets stored in DB

| Action | Stored in DB |
|--------|-------------|
| Login | User session (JWT token) |
| Create build | builds table |
| Add variable | variables table |
| Generate Trade variables and store generated output | trade_variable_outputs table |
| Upload bureau file | execution_runs + normalized tables |
| Run batch | feature_outputs table |

All data is stored in `backend/creditiq.db` (SQLite file).

---

## API Docs

http://localhost:8000/docs

## Sample Data

Test files are in `sample data/` folder:
- `cibil_sample.xml` — CIBIL (20 customers)
- `experian_sample.json` — Experian (20 customers)
- `crif_high_mark_sample.json` — CRIF (20 customers)
- `equifax_sample.xml` — Equifax (20 customers)

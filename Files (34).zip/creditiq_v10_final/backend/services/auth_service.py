"""services/auth_service.py — login/signup business logic"""
from sqlalchemy.orm import Session
from db import models
from core.security import hash_password, verify_password, create_access_token
from fastapi import HTTPException, status


# Test/Guest credentials for development
TEST_CREDENTIALS = {
    "username": "guest",
    "password": "guest"
}


def signup(db: Session, email: str, username: str, password: str):
    if db.query(models.User).filter(models.User.username == username).first():
        raise HTTPException(status_code=400, detail="Username already taken")
    if db.query(models.User).filter(models.User.email == email).first():
        raise HTTPException(status_code=400, detail="Email already registered")
    user = models.User(email=email, username=username, hashed_password=hash_password(password))
    db.add(user); db.commit(); db.refresh(user)
    return user


def login(db: Session, username: str, password: str):
    # Allow test/guest credentials without database lookup
    if username == TEST_CREDENTIALS["username"] and password == TEST_CREDENTIALS["password"]:
        token = create_access_token({"sub": username, "uid": 0})
        guest_user = type('User', (), {'id': 0, 'username': username, 'email': 'guest@test.local'})()
        return token, guest_user
    
    user = db.query(models.User).filter(models.User.username == username).first()
    if not user or not verify_password(password, user.hashed_password):
        raise HTTPException(status_code=401, detail="Invalid username or password")
    token = create_access_token({"sub": user.username, "uid": user.id})
    return token, user

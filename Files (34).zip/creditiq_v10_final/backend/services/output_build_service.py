"""Materialize variable output details into output_builds."""
import json
from datetime import date, datetime
from typing import Optional

from sqlalchemy.orm import Session

from db import models


def materialize_variable_output_details(
    db: Session,
    build: models.Build,
    variable: models.Variable,
) -> dict:
    """Save a summary row and matching source-detail rows for enquiry variables."""
    db.query(models.OutputBuild).filter(
        models.OutputBuild.variable_id == variable.id
    ).delete(synchronize_session=False)

    cfg = json.loads(variable.config_json or "{}")
    var_type = (cfg.get("variable_type") or variable.variable_type or "").lower()
    run = _find_latest_run_with_inquiries(db, build.id)

    if not run:
        summary = _summary_row(
            build_id=build.id,
            variable=variable,
            run_id=None,
            output_value=None,
            details={"status": "skipped", "reason": "No normalized inquiry data found"},
        )
        db.add(summary)
        db.commit()
        return {"saved_rows": 1, "matched_rows": 0, "output_value": None, "run_id": None}

    if "enquiry" not in var_type:
        summary = _summary_row(
            build_id=build.id,
            variable=variable,
            run_id=run.id,
            output_value=None,
            details={"status": "skipped", "reason": "Only enquiry variables are materialized into output_builds"},
        )
        db.add(summary)
        db.commit()
        return {"saved_rows": 1, "matched_rows": 0, "output_value": None, "run_id": run.id}

    inquiries = db.query(models.NormalizedInquiry).filter_by(run_id=run.id).all()
    matches = _filter_inquiries_for_variable(cfg, inquiries)
    output_value = _compute_output_value(cfg, matches)

    rows = [
        _summary_row(
            build_id=build.id,
            variable=variable,
            run_id=run.id,
            output_value=output_value,
            details={"status": "ready", "matched_rows": len(matches)},
        )
    ]

    for inquiry in matches:
        rows.append(
            models.OutputBuild(
                build_id=build.id,
                variable_id=variable.id,
                run_id=run.id,
                variable_name=variable.name,
                variable_type=variable.variable_type,
                row_type="detail",
                output_value=str(output_value) if output_value is not None else None,
                customer_id=inquiry.customer_id,
                member_id=inquiry.member_id,
                ownership_type=inquiry.ownership_type,
                inquiry_date=inquiry.inquiry_date,
                inquiry_purpose=inquiry.inquiry_purpose,
                loan_type=inquiry.loan_type,
                lender_name=inquiry.lender_name,
                inquiry_amount=inquiry.inquiry_amount,
                source_table="normalized_inquiries",
                details_json=json.dumps({
                    "bureau_source": inquiry.bureau_source,
                    "is_secured": inquiry.is_secured,
                }),
            )
        )

    db.add_all(rows)
    db.commit()
    return {
        "saved_rows": len(rows),
        "matched_rows": len(matches),
        "output_value": output_value,
        "run_id": run.id,
    }


def get_output_build_rows(
    db: Session,
    build_id: int,
    variable_id: Optional[int] = None,
):
    query = db.query(models.OutputBuild).filter_by(build_id=build_id)
    if variable_id is not None:
        query = query.filter_by(variable_id=variable_id)
    return query.order_by(models.OutputBuild.created_at.desc(), models.OutputBuild.id.desc()).all()


def serialize_output_build(row: models.OutputBuild) -> dict:
    return {
        "id": row.id,
        "build_id": row.build_id,
        "variable_id": row.variable_id,
        "run_id": row.run_id,
        "variable_name": row.variable_name,
        "variable_type": row.variable_type,
        "row_type": row.row_type,
        "output_value": row.output_value,
        "customer_id": row.customer_id,
        "member_id": row.member_id,
        "ownership_type": row.ownership_type,
        "inquiry_date": row.inquiry_date,
        "inquiry_purpose": row.inquiry_purpose,
        "loan_type": row.loan_type,
        "lender_name": row.lender_name,
        "inquiry_amount": row.inquiry_amount,
        "source_table": row.source_table,
        "details": json.loads(row.details_json or "{}"),
        "created_at": row.created_at.isoformat() if row.created_at else None,
    }


def _summary_row(build_id: int, variable: models.Variable, run_id: Optional[int], output_value, details: dict):
    return models.OutputBuild(
        build_id=build_id,
        variable_id=variable.id,
        run_id=run_id,
        variable_name=variable.name,
        variable_type=variable.variable_type,
        row_type="summary",
        output_value=str(output_value) if output_value is not None else None,
        source_table="normalized_inquiries",
        details_json=json.dumps(details),
    )


def _find_latest_run_with_inquiries(db: Session, build_id: int) -> Optional[models.ExecutionRun]:
    runs = (
        db.query(models.ExecutionRun)
        .filter(models.ExecutionRun.build_id == build_id)
        .order_by(models.ExecutionRun.started_at.desc(), models.ExecutionRun.id.desc())
        .all()
    )
    for run in runs:
        has_rows = db.query(models.NormalizedInquiry).filter_by(run_id=run.id).first()
        if has_rows:
            return run
    return None


def _filter_inquiries_for_variable(cfg: dict, inquiries: list[models.NormalizedInquiry]) -> list[models.NormalizedInquiry]:
    filters = cfg.get("filters") or {}
    loan_types = filters.get("product") or cfg.get("loan_types") or []
    inquiry_purposes = filters.get("inquiry_purpose") or filters.get("product_subtype") or []
    secured_filter = filters.get("secured")
    lenders = filters.get("lender") or []
    if isinstance(inquiry_purposes, str):
        inquiry_purposes = [inquiry_purposes]
    inquiry_purposes = {str(p).strip().lower() for p in inquiry_purposes if str(p).strip()}
    if isinstance(lenders, str):
        lenders = [lenders]
    lenders = {str(l).strip().lower() for l in lenders if str(l).strip()}
    window_months = _parse_window(cfg.get("time_window") or cfg.get("window") or "12m")

    matched = []
    for inquiry in inquiries:
        if loan_types and inquiry.loan_type not in loan_types:
            continue
        if inquiry_purposes and (inquiry.inquiry_purpose or "").strip().lower() not in inquiry_purposes:
            continue
        if secured_filter in ("secured", "unsecured"):
            expected = secured_filter == "secured"
            if inquiry.is_secured is not expected:
                continue
        if lenders and (inquiry.lender_name or "").strip().lower() not in lenders:
            continue
        if window_months:
            age = _months_ago(inquiry.inquiry_date)
            if age is None or age > window_months:
                continue
        matched.append(inquiry)
    return matched


def _compute_output_value(cfg: dict, inquiries: list[models.NormalizedInquiry]):
    agg = str(cfg.get("aggregation") or "count").lower()
    amounts = [float(i.inquiry_amount or 0) for i in inquiries]

    if agg == "count":
        return len(inquiries)
    if agg == "flag":
        return 1 if inquiries else 0
    if agg == "sum":
        return round(sum(amounts), 4)
    if agg == "avg":
        return round(sum(amounts) / len(amounts), 4) if amounts else 0
    if agg == "max":
        return max(amounts) if amounts else 0
    if agg == "min":
        return min(amounts) if amounts else 0
    return len(inquiries)


def _parse_window(window_str) -> int:
    if not window_str:
        return 12
    raw = str(window_str).lower().replace("m", "").strip()
    try:
        return int(raw)
    except Exception:
        return 12


def _parse_date(date_str) -> Optional[date]:
    if not date_str:
        return None
    for fmt in ("%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y", "%Y%m%d", "%m/%Y"):
        try:
            return datetime.strptime(str(date_str)[:10], fmt).date()
        except Exception:
            continue
    return None


def _months_ago(date_str) -> Optional[int]:
    parsed = _parse_date(date_str)
    if parsed is None:
        return None
    today = date.today()
    diff = (today.year - parsed.year) * 12 + (today.month - parsed.month)
    return max(0, diff)

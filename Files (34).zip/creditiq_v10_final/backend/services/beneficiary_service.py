"""services/beneficiary_service.py - Beneficiary CRUD logic."""
from datetime import datetime
from fastapi import HTTPException
from sqlalchemy import or_
from sqlalchemy.orm import Session

from db import models


DEFAULT_BENEFICIARIES = [
    {"name": "Ayokunle Adeshina", "bank_name": "Wells Fargo", "account_number": "0040513756", "avatar_letter": "W", "avatar_color": "avatar-red"},
    {"name": "Ben Thompson", "bank_name": "Chase Bank", "account_number": "0040513756", "avatar_letter": "C", "avatar_color": "avatar-blue"},
    {"name": "Christiana Adeoti", "bank_name": "Guaranty Trust Bank", "account_number": "0040513756", "avatar_letter": "G", "avatar_color": "avatar-orange"},
    {"name": "Daniel Bakare", "bank_name": "Bank of America", "account_number": "0040513756", "avatar_letter": "B", "avatar_color": "avatar-gold"},
    {"name": "Olawale Oguntayo", "bank_name": "ALAT by Wema", "account_number": "0040513756", "avatar_letter": "A", "avatar_color": "avatar-darkred"},
    {"name": "Tosin Adebayo", "bank_name": "UBA", "account_number": "0040513756", "avatar_letter": "U", "avatar_color": "avatar-teal"},
    {"name": "Kehinde Bello", "bank_name": "Kuda Bank", "account_number": "0040513756", "avatar_letter": "K", "avatar_color": "avatar-purple"},
]

VALID_AVATAR_COLORS = {
    "avatar-red",
    "avatar-blue",
    "avatar-orange",
    "avatar-gold",
    "avatar-darkred",
    "avatar-teal",
    "avatar-purple",
}


def _serialize_beneficiary(row: models.Beneficiary) -> dict:
    return {
        "id": row.id,
        "owner": row.owner,
        "build_id": row.build_id,
        "build_name": row.build.name if row.build else None,
        "name": row.name,
        "bank_name": row.bank_name,
        "account_number": row.account_number,
        "avatar_letter": row.avatar_letter,
        "avatar_color": row.avatar_color,
        "created_at": row.created_at.isoformat() if row.created_at else None,
        "updated_at": row.updated_at.isoformat() if row.updated_at else None,
    }


def _normalize_avatar_letter(name: str, bank_name: str, value: str | None) -> str:
    raw = (value or "").strip()
    if raw:
        return raw[:1].upper()
    seed = (bank_name or name or "?").strip()
    return seed[:1].upper() if seed else "?"


def _normalize_avatar_color(value: str | None) -> str:
    color = (value or "").strip()
    return color if color in VALID_AVATAR_COLORS else "avatar-blue"


def _get_build(db: Session, owner: str, build_name: str | None) -> models.Build | None:
    if not build_name:
        return None
    return (
        db.query(models.Build)
        .filter(models.Build.owner == owner, models.Build.name == build_name)
        .first()
    )


def ensure_default_beneficiaries(db: Session, owner: str) -> None:
    existing = (
        db.query(models.Beneficiary)
        .filter(models.Beneficiary.owner == owner, models.Beneficiary.build_id.is_(None))
        .first()
    )
    if existing:
        return

    now = datetime.utcnow()
    rows = [
        models.Beneficiary(
            owner=owner,
            build_id=None,
            name=item["name"],
            bank_name=item["bank_name"],
            account_number=item["account_number"],
            avatar_letter=item["avatar_letter"],
            avatar_color=item["avatar_color"],
            created_at=now,
            updated_at=now,
        )
        for item in DEFAULT_BENEFICIARIES
    ]
    db.add_all(rows)
    db.commit()


def list_beneficiaries(db: Session, owner: str, build_name: str | None = None) -> list[dict]:
    ensure_default_beneficiaries(db, owner)
    build = _get_build(db, owner, build_name)
    query = db.query(models.Beneficiary).filter(models.Beneficiary.owner == owner)

    if build:
        query = query.filter(
            or_(models.Beneficiary.build_id.is_(None), models.Beneficiary.build_id == build.id)
        )
    else:
        query = query.filter(models.Beneficiary.build_id.is_(None))

    rows = (
        query.order_by(models.Beneficiary.build_id.is_not(None), models.Beneficiary.updated_at.desc())
        .all()
    )
    return [_serialize_beneficiary(row) for row in rows]


def create_beneficiary(
    db: Session,
    *,
    owner: str,
    name: str,
    bank_name: str,
    account_number: str,
    build_name: str | None = None,
    avatar_letter: str | None = None,
    avatar_color: str | None = None,
) -> dict:
    build = _get_build(db, owner, build_name)
    row = models.Beneficiary(
        owner=owner,
        build_id=build.id if build else None,
        name=name.strip(),
        bank_name=bank_name.strip(),
        account_number=account_number.strip(),
        avatar_letter=_normalize_avatar_letter(name, bank_name, avatar_letter),
        avatar_color=_normalize_avatar_color(avatar_color),
    )
    db.add(row)
    db.commit()
    db.refresh(row)
    return _serialize_beneficiary(row)


def update_beneficiary(
    db: Session,
    beneficiary_id: int,
    *,
    owner: str,
    name: str | None = None,
    bank_name: str | None = None,
    account_number: str | None = None,
    build_name: str | None = None,
    avatar_letter: str | None = None,
    avatar_color: str | None = None,
) -> dict:
    row = (
        db.query(models.Beneficiary)
        .filter(models.Beneficiary.id == beneficiary_id, models.Beneficiary.owner == owner)
        .first()
    )
    if not row:
        raise HTTPException(status_code=404, detail="Beneficiary not found")

    if name is not None:
        row.name = name.strip()
    if bank_name is not None:
        row.bank_name = bank_name.strip()
    if account_number is not None:
        row.account_number = account_number.strip()
    if build_name is not None:
        build = _get_build(db, owner, build_name)
        row.build_id = build.id if build else None

    row.avatar_letter = _normalize_avatar_letter(row.name, row.bank_name, avatar_letter or row.avatar_letter)
    row.avatar_color = _normalize_avatar_color(avatar_color or row.avatar_color)
    row.updated_at = datetime.utcnow()
    db.commit()
    db.refresh(row)
    return _serialize_beneficiary(row)


def delete_beneficiary(db: Session, beneficiary_id: int, *, owner: str) -> None:
    row = (
        db.query(models.Beneficiary)
        .filter(models.Beneficiary.id == beneficiary_id, models.Beneficiary.owner == owner)
        .first()
    )
    if not row:
        raise HTTPException(status_code=404, detail="Beneficiary not found")
    db.delete(row)
    db.commit()

"""services/variable_service.py — variable add/delete logic + variableMetadata"""
import json
from sqlalchemy.orm import Session
from db import models
from services.build_service import create_or_get_build, _serialize_build
from services.output_build_service import materialize_variable_output_details
from fastapi import HTTPException


VARIABLE_METADATA = {
    "types": ["Enquiry", "Trade", "Account", "Trade History", "Other"],
    "subcategories": {
        "Enquiry": ["volume", "recency", "amount", "trend", "distribution", "concentration"],
        "Trade": ["exposure", "delinquency", "recency", "trend", "balance", "distribution",
                  "concentration", "volume", "vintage", "utilization", "ratio"],
        "Account": ["utilization", "payment_behavior", "credit_mix", "cross_entity",
                    "lifecycle", "balance_dynamics", "stability"],
        "Trade History": ["balance_history", "dpd_history", "payment_pattern", "velocity",
                          "trend", "risk_ratio", "balance_dynamics"],
        "Other": ["custom"],
    },
    "aggregations": ["count", "sum", "avg", "max", "min", "std", "pct", "flag", "ratio"],
    "time_windows": ["1m", "3m", "6m", "12m", "24m", "36m", "custom"],
    "bureaus": ["CIBIL", "Experian", "CRIF", "Equifax"],
    "loan_types": ["PL", "CC", "HL", "AL", "BL", "GL", "OD", "LAP", "CD", "Consumer"],
    "account_statuses": ["Active", "Closed", "Written-Off", "Settled", "Suit-Filed", "NPA", "SMA", "Restructured"],
}


def get_variable_metadata():
    return VARIABLE_METADATA


DOMAIN_TO_TYPE = {
    "enquiry":       "Enquiry",
    "trade":         "Trade",
    "trade_history": "Trade History",
    "account":       "Account",
}


def _scope_str(val, default="all"):
    if val is None:
        return default
    if isinstance(val, (list, tuple, set)):
        cleaned = [str(x) for x in val if str(x).strip()]
        return ",".join(cleaned) if cleaned else default
    sval = str(val).strip()
    return sval or default


def _extract_scope_fields(variable_config: dict) -> dict:
    filters = variable_config.get("filters") or {}
    portfolio_scope = variable_config.get("portfolio_scope") or {}
    trade_scope = variable_config.get("trade_scope") or {}

    return {
        "product_scope": _scope_str(filters.get("product"), "all"),
        "secured_scope": _scope_str(
            filters.get("secured")
            or portfolio_scope.get("secured_flag")
            or trade_scope.get("secured"),
            "all",
        ),
        "lender_scope": _scope_str(filters.get("lender"), "all"),
        "loan_type_scope": _scope_str(
            portfolio_scope.get("loan_type") or trade_scope.get("loanType"),
            "all",
        ),
        "account_status_scope": _scope_str(
            portfolio_scope.get("account_status") or trade_scope.get("status"),
            "all",
        ),
        "ownership_scope": _scope_str(
            portfolio_scope.get("ownership_type") or trade_scope.get("ownership"),
            "all",
        ),
    }


def add_variable(db: Session, build_name: str, owner: str, bureau, file_type, file_identifier, variable_config: dict):
    build = create_or_get_build(db, build_name, owner, bureau, file_type, file_identifier)
    var_name = variable_config.get("name") or variable_config.get("feature_name") or "unnamed_variable"

    # Resolve variable_type from domain if not explicitly set
    vtype = variable_config.get("variable_type")
    if not vtype or vtype == "Other":
        domain = (variable_config.get("domain") or "").lower()
        vtype = DOMAIN_TO_TYPE.get(domain, vtype or "Other")
    variable_config["variable_type"] = vtype

    # Normalize time_window — could be object {value:6,unit:'month'}, string '6m', or time_window_str
    tw = variable_config.get("time_window_str") or variable_config.get("time_window")
    if isinstance(tw, dict):
        tw = str(tw.get("value", "")) + (tw.get("unit", "m")[0] if tw.get("unit") else "m")
    elif tw is not None:
        tw = str(tw)

    scope_fields = _extract_scope_fields(variable_config)

    # Check for duplicate name in this build
    existing = db.query(models.Variable).filter(
        models.Variable.build_id == build.id,
        models.Variable.name == var_name
    ).first()
    if existing:
        # update it
        def _sf(val): return (val.get('k') or str(val)) if isinstance(val, dict) else (str(val) if val is not None else None)
        existing.variable_type = variable_config.get("variable_type", existing.variable_type)
        existing.sub_category  = variable_config.get("sub_category", existing.sub_category)
        existing.measure       = _sf(variable_config.get("measure")) or existing.measure
        existing.aggregation   = _sf(variable_config.get("aggregation")) or existing.aggregation
        existing.time_window   = tw
        existing.product_scope = scope_fields["product_scope"]
        existing.secured_scope = scope_fields["secured_scope"]
        existing.lender_scope = scope_fields["lender_scope"]
        existing.loan_type_scope = scope_fields["loan_type_scope"]
        existing.account_status_scope = scope_fields["account_status_scope"]
        existing.ownership_scope = scope_fields["ownership_scope"]
        existing.config_json   = json.dumps(variable_config)
        db.commit()
        db.refresh(existing)
        db.refresh(build)
        output_build = materialize_variable_output_details(db, build, existing)
        return {
            "message": f"Variable '{var_name}' updated in build '{build_name}'",
            "build": _serialize_build(build),
            "output_build": output_build,
        }

    # Normalize measure/aggregation — catalog sends {k:'count'}, wizard sends 'count'
    def _str_field(val):
        if isinstance(val, dict): return val.get('k') or val.get('label') or str(val)
        return str(val) if val is not None else None

    var = models.Variable(
        name=var_name,
        build_id=build.id,
        variable_type=variable_config.get("variable_type", "Other"),
        sub_category=variable_config.get("sub_category"),
        measure=_str_field(variable_config.get("measure")),
        aggregation=_str_field(variable_config.get("aggregation")),
        time_window=tw,
        product_scope=scope_fields["product_scope"],
        secured_scope=scope_fields["secured_scope"],
        lender_scope=scope_fields["lender_scope"],
        loan_type_scope=scope_fields["loan_type_scope"],
        account_status_scope=scope_fields["account_status_scope"],
        ownership_scope=scope_fields["ownership_scope"],
        source=variable_config.get("source", "wizard"),
        config_json=json.dumps(variable_config),
    )
    db.add(var)
    db.commit()
    db.refresh(var)
    db.refresh(build)
    output_build = materialize_variable_output_details(db, build, var)
    return {
        "message": f"Variable '{var_name}' added to build '{build_name}'",
        "build": _serialize_build(build),
        "output_build": output_build,
    }


def delete_variable(db: Session, build_name: str, variable_name: str, owner: str):
    build = db.query(models.Build).filter(models.Build.name == build_name, models.Build.owner == owner).first()
    if not build:
        raise HTTPException(status_code=404, detail=f"Build '{build_name}' not found")
    var = db.query(models.Variable).filter(
        models.Variable.build_id == build.id,
        models.Variable.name == variable_name
    ).first()
    if not var:
        raise HTTPException(status_code=404, detail=f"Variable '{variable_name}' not found")
    db.delete(var); db.commit()
    return {"message": f"Variable '{variable_name}' deleted from build '{build_name}'"}

"""
services/batch_service.py
Orchestrates the full 4-Bureau batch run pipeline:
  1. Load build + variables
  2. Find latest ExecutionRun for the build
  3. Run feature_engine on normalized data
  4. Return summary: ready / skipped / invalid counts
"""
import json
from sqlalchemy.orm import Session
from db import models
from bureau.feature_engine import run_features
from fastapi import HTTPException
from datetime import datetime


def run_batch(db: Session, build_name: str, owner: str) -> dict:
    # ── Load build ────────────────────────────────────────────────────
    build = db.query(models.Build).filter(
        models.Build.name == build_name,
        models.Build.owner == owner
    ).first()
    if not build:
        raise HTTPException(status_code=404, detail=f"Build '{build_name}' not found for owner '{owner}'")

    if not build.variables:
        raise HTTPException(status_code=400, detail="No variables in this build. Add variables first.")

    # ── Find latest normalized run ────────────────────────────────────
    run = db.query(models.ExecutionRun).filter(
        models.ExecutionRun.build_id == build.id,
        models.ExecutionRun.parse_status == "normalized"
    ).order_by(models.ExecutionRun.started_at.desc()).first()

    if not run:
        # Create a synthetic run using build metadata (demo mode)
        run = _create_demo_run(db, build)

    # ── Execute features ──────────────────────────────────────────────
    run.parse_status = "running"
    db.commit()

    outputs = run_features(db, run, build.variables)

    run.parse_status = "done"
    run.finished_at  = datetime.utcnow()
    db.commit()

    # ── Build summary ─────────────────────────────────────────────────
    summary = _build_summary(outputs, build.variables)
    return {
        "message": f"Batch completed for build '{build_name}'",
        "run_id": run.id,
        "bureau": run.bureau,
        "total_variables": len(build.variables),
        "total_customers": len({o.customer_id for o in outputs}),
        "summary": summary,
        "outputs": [
            {
                "customer_id": o.customer_id,
                "feature_name": o.feature_name,
                "feature_value": o.feature_value,
                "status": o.status,
                "skip_reason": o.skip_reason,
            }
            for o in outputs[:200]  # cap for API response
        ],
    }


def _create_demo_run(db: Session, build: models.Build) -> models.ExecutionRun:
    """Create a synthetic run with demo data when no real bureau file has been uploaded"""
    run = models.ExecutionRun(
        build_id=build.id,
        bureau=build.bureau or "CIBIL",
        file_name="demo_synthetic",
        parse_status="normalized",
    )
    db.add(run); db.commit(); db.refresh(run)

    # Inject minimal synthetic normalized data so features can compute
    _inject_synthetic_data(db, run)
    return run


def _inject_synthetic_data(db: Session, run: models.ExecutionRun):
    """Generate a small synthetic portfolio for demo execution"""
    import random; random.seed(42)
    customers = [f"CUST_{i:04d}" for i in range(1, 11)]
    loan_types = ["PL", "CC", "HL", "AL", "BL", "OD", "LAP"]
    statuses   = ["Active", "Closed", "NPA", "Written-Off"]

    for cid in customers:
        db.add(models.NormalizedApplicant(
            run_id=run.id, customer_id=cid,
            full_name=f"Demo Customer {cid}",
            bureau_source=run.bureau
        ))
        for j in range(random.randint(2, 6)):
            lt = random.choice(loan_types)
            db.add(models.NormalizedAccount(
                run_id=run.id, customer_id=cid,
                loan_type=lt,
                account_status=random.choice(statuses),
                ownership_type="Individual",
                sanction_amount=random.uniform(100000, 5000000),
                current_balance=random.uniform(0, 4000000),
                overdue_amount=random.uniform(0, 100000),
                emi_amount=random.uniform(5000, 80000),
                dpd=random.choice([0, 0, 0, 30, 60, 90]),
                date_reported="2024-12-01",
                is_secured=lt in {"HL", "AL", "GL", "LAP"},
                bureau_source=run.bureau
            ))
        for j in range(random.randint(1, 5)):
            lt = random.choice(loan_types)
            db.add(models.NormalizedInquiry(
                run_id=run.id, customer_id=cid,
                inquiry_date=f"202{random.randint(3,4)}-{random.randint(1,12):02d}-01",
                inquiry_amount=random.uniform(100000, 2000000),
                loan_type=lt,
                is_secured=lt in {"HL", "AL", "GL", "LAP"},
                bureau_source=run.bureau
            ))
    db.commit()


def _build_summary(outputs, variables) -> dict:
    ready   = sum(1 for o in outputs if o.status == "ready")
    skipped = sum(1 for o in outputs if o.status == "skipped")
    invalid = sum(1 for o in outputs if o.status == "invalid")
    customers = {o.customer_id for o in outputs}
    return {
        "ready": ready,
        "skipped": skipped,
        "invalid": invalid,
        "total_outputs": len(outputs),
        "unique_customers": len(customers),
        "execution_summary": [
            {
                "feature": v.name,
                "type": v.variable_type,
                "ready_count": sum(1 for o in outputs if o.feature_name == v.name and o.status == "ready"),
                "skipped_count": sum(1 for o in outputs if o.feature_name == v.name and o.status == "skipped"),
            }
            for v in variables
        ],
    }

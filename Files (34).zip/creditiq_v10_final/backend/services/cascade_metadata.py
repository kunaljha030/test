"""
services/cascade_metadata.py  —  EXACT match with UI app.js schemas
=====================================================================
All 4 types + sub-categories + measures + aggregations copied
directly from the frontend INQ_SCHEMA / TRD_SCHEMA / ACT_SCHEMA /
TRD_HIST_SCHEMA so the cascade API returns exactly what the UI expects.
"""

# ─────────────────────────────────────────────────────────────────────
# GLOBAL OPTIONS
# ─────────────────────────────────────────────────────────────────────
GLOBAL = {
    "time_windows": [
        {"value": "1m",  "label": "1 Month"},
        {"value": "3m",  "label": "3 Months"},
        {"value": "6m",  "label": "6 Months"},
        {"value": "12m", "label": "12 Months"},
        {"value": "24m", "label": "24 Months"},
        {"value": "36m", "label": "36 Months"},
        {"value": "48m", "label": "48 Months"},
        {"value": "custom", "label": "Custom"},
    ],
    "loan_types": [
        {"value": "PL",    "label": "Personal Loan"},
        {"value": "CC",    "label": "Credit Card"},
        {"value": "HL",    "label": "Home Loan"},
        {"value": "AL",    "label": "Auto Loan"},
        {"value": "BL",    "label": "Business Loan"},
        {"value": "GL",    "label": "Gold Loan"},
        {"value": "OD",    "label": "Overdraft"},
        {"value": "LAP",   "label": "Loan Against Property"},
        {"value": "LAS",   "label": "Loan Against Shares/Securities"},
        {"value": "CD",    "label": "Consumer Durable"},
        {"value": "TW",    "label": "Two-Wheeler Loan"},
        {"value": "CV",    "label": "Commercial Vehicle Loan"},
        {"value": "EL",    "label": "Education Loan"},
        {"value": "CE",    "label": "Construction Equipment Loan"},
        {"value": "Other", "label": "Other / Miscellaneous"},
    ],
    "account_statuses": [
        {"value": "Active",       "label": "Active"},
        {"value": "Closed",       "label": "Closed"},
        {"value": "Written-Off",  "label": "Written-Off"},
        {"value": "Settled",      "label": "Settled"},
        {"value": "Suit-Filed",   "label": "Suit Filed"},
        {"value": "NPA",          "label": "NPA"},
        {"value": "SMA",          "label": "SMA"},
        {"value": "Restructured", "label": "Restructured"},
    ],
    "secured_options": [
        {"value": "all",       "label": "All"},
        {"value": "secured",   "label": "Secured Only"},
        {"value": "unsecured", "label": "Unsecured Only"},
    ],
    "ownership_options": [
        {"value": "all",        "label": "All"},
        {"value": "individual", "label": "Individual"},
        {"value": "joint",      "label": "Joint"},
        {"value": "guarantor",  "label": "Guarantor"},
    ],
    "aggregation_labels": {
        "count": "Count", "sum": "Sum", "avg": "Average", "max": "Maximum",
        "min": "Minimum", "std": "Std Deviation", "flag": "Flag (0/1)",
        "ratio": "Ratio", "pct": "Percentile", "median": "Median",
        "variance": "Variance", "cv": "CV (Coeff of Variation)",
        "skew": "Skewness", "kurtosis": "Kurtosis", "iqr": "IQR",
        "outlier_count": "Outlier Count", "percentile": "Percentile",
        "difference": "Difference", "growth_rate": "Growth Rate",
        "slope": "Slope", "acceleration": "Acceleration",
        "volatility": "Volatility", "regression": "Regression",
        "classification": "Classification", "value": "Value",
        "index": "Index", "rate": "Rate",
        "velocity": "Velocity", "trend": "Trend",
        "entropy": "Entropy", "lag_corr": "Lag Correlation",
        "max_streak": "Max Streak",
    },
}

# ─────────────────────────────────────────────────────────────────────
# CASCADE TREE  —  Exact match with app.js schemas
# ─────────────────────────────────────────────────────────────────────
CASCADE = {

    # ══════════════════════════════════════════════════════════════════
    # ENQUIRY
    # ══════════════════════════════════════════════════════════════════
    "Enquiry": {
        "label": "Enquiry", "abbr": "enq",
        "description": "Application / inquiry level features", "icon": "🔍",
        "data_source": "normalized_inquiries",
        "sub_categories": [
            {"value": "volume",        "label": "Volume",        "description": "Count of inquiries in period"},
            {"value": "amount",        "label": "Amount",        "description": "Inquiry amount aggregations"},
            {"value": "gap",           "label": "Gap",           "description": "Days between inquiries"},
            {"value": "recency",       "label": "Recency",       "description": "Time since last inquiry"},
            {"value": "concentration", "label": "Concentration", "description": "Lender concentration / HHI"},
            {"value": "velocity",      "label": "Velocity",      "description": "Window-to-window change rate"},
            {"value": "mix",           "label": "Mix",           "description": "Secured/Unsecured ratio"},
            {"value": "threshold",     "label": "Threshold",     "description": "Count above/below amount threshold"},
            {"value": "distribution",       "label": "Distribution",          "description": "Distribution shape statistics"},
            {"value": "product_diversity",  "label": "Product Diversity",     "description": "Distinct loan-type count / HHI across product types"},
            {"value": "secured_split",      "label": "Secured Split",         "description": "Secured vs unsecured count, ratio and flag"},
            {"value": "amount_bucket",      "label": "Amount Bucket",         "description": "Count of inquiries in fixed amount bands"},
            {"value": "inter_enquiry_timing","label": "Inter-Enquiry Timing", "description": "Enquiry spread (months) and burst window detection"},
        ],
        "measures_by_subcat": {
            "volume":       [{"value": "count", "label": "Count", "col": None}],
            "amount":       [{"value": "inquiry_amount", "label": "Inquiry Amount", "col": "inquiry_amount"}],
            "gap":          [{"value": "days_between", "label": "Days Between Inquiries", "col": "inquiry_date"}],
            "recency":      [
                {"value": "months_since_last",   "label": "Months Since Last Inquiry",   "col": "inquiry_date"},
                {"value": "months_since_oldest", "label": "Months Since Oldest Inquiry", "col": "inquiry_date"},
            ],
            "concentration": [
                {"value": "distinct_lenders",  "label": "Distinct Lenders",   "col": "lender_name"},
                {"value": "top_lender_share",  "label": "Top Lender Share",   "col": "lender_name"},
                {"value": "hhi_index",         "label": "HHI Index",          "col": "lender_name"},
            ],
            "velocity": [
                {"value": "count_change",  "label": "Count Change (diff)",  "col": None},
                {"value": "count_ratio",   "label": "Count Ratio",          "col": None},
                {"value": "growth_rate",   "label": "Growth Rate %",        "col": None},
                {"value": "slope",         "label": "Linear Trend Slope",   "col": "inquiry_date"},
            ],
            "mix":       [{"value": "secured_unsecured_ratio", "label": "Secured/Unsecured Ratio", "col": "is_secured"}],
            "threshold": [
                {"value": "count_threshold",  "label": "Count above/below threshold", "col": None},
                {"value": "amount_threshold", "label": "Amount above/below threshold", "col": "inquiry_amount"},
            ],
            "distribution": [
                {"value": "amount_distribution", "label": "Amount Distribution Stats", "col": "inquiry_amount"},
                {"value": "gap_distribution",    "label": "Gap Distribution Stats",    "col": "inquiry_date"},
            ],
            "product_diversity": [
                {"value": "distinct_products",   "label": "Distinct Product Types",   "col": "loan_type"},
                {"value": "product_hhi",         "label": "Product HHI Index",        "col": "loan_type"},
                {"value": "dominant_product_share","label": "Top Product Share",      "col": "loan_type"},
            ],
            "secured_split": [
                {"value": "secured_count",       "label": "Secured Inquiry Count",    "col": "is_secured"},
                {"value": "unsecured_count",     "label": "Unsecured Inquiry Count",  "col": "is_secured"},
                {"value": "secured_ratio",       "label": "Secured Ratio",            "col": "is_secured"},
                {"value": "secured_flag",        "label": "Has Secured Inquiry Flag", "col": "is_secured"},
            ],
            "amount_bucket": [
                {"value": "bucket_lt_25k",       "label": "Count < 25K",              "col": "inquiry_amount"},
                {"value": "bucket_25k_1l",       "label": "Count 25K–1L",             "col": "inquiry_amount"},
                {"value": "bucket_1l_5l",        "label": "Count 1L–5L",              "col": "inquiry_amount"},
                {"value": "bucket_gt_5l",        "label": "Count > 5L",               "col": "inquiry_amount"},
            ],
            "inter_enquiry_timing": [
                {"value": "enquiry_span_months", "label": "Enquiry Span (months)",    "col": "inquiry_date"},
                {"value": "burst_count_30d",     "label": "Burst Count (≤30 days)",   "col": "inquiry_date"},
                {"value": "burst_flag",          "label": "Burst Flag (3+ in 30d)",   "col": "inquiry_date"},
            ],
        },
        "aggregations_by_subcat": {
            "volume":       ["count", "ratio", "flag"],
            "amount":       ["sum", "avg", "max", "min", "median", "std", "variance", "cv", "skew", "kurtosis", "percentile"],
            "gap":          ["avg", "median", "min", "max", "std", "cv", "skew", "kurtosis", "percentile", "iqr"],
            "recency":      ["value"],
            "concentration":["count", "ratio", "index"],
            "velocity":     ["difference", "ratio", "growth_rate", "slope"],
            "mix":          ["ratio"],
            "threshold":    ["flag", "count"],
            "distribution":         ["std", "variance", "cv", "skew", "kurtosis", "percentile", "iqr"],
            "product_diversity":     ["count", "index", "ratio"],
            "secured_split":         ["count", "ratio", "flag"],
            "amount_bucket":         ["count"],
            "inter_enquiry_timing":  ["value", "count", "flag"],
        },
        "scope_fields": ["loan_types", "secured"],
        "threshold_by_subcat": {
            "volume": None,
            "amount": {"enabled": True, "type": "amount", "label": "Amount Filter", "col": "inquiry_amount",
                       "operators": [">", ">=", "<", "<=", "="], "placeholder": "e.g. 50000"},
            "gap": None, "recency": None, "concentration": None, "mix": None,
            "velocity": {"enabled": True, "type": "prior_window", "label": "Prior Window (months)",
                         "col": None, "operators": ["="], "placeholder": "e.g. 6 — defaults to 2× time window"},
            "threshold": {"enabled": True, "type": "amount", "label": "Threshold Amount", "col": "inquiry_amount",
                          "operators": [">", ">=", "<", "<=", "="], "placeholder": "e.g. 50000"},
            "distribution": {"enabled": True, "type": "percentile", "label": "Percentile Value (for percentile agg)",
                             "col": None, "operators": ["="], "placeholder": "e.g. 75"},
            "product_diversity": None,
            "secured_split": None,
            "amount_bucket": None,
            "inter_enquiry_timing": None,
        },
    },

    # ══════════════════════════════════════════════════════════════════
    # TRADE
    # ══════════════════════════════════════════════════════════════════
    "Trade": {
        "label": "Trade", "abbr": "trd",
        "description": "Trade/account level balance & delinquency features", "icon": "📊",
        "data_source": "normalized_accounts",
        "sub_categories": [
            {"value": "exposure",          "label": "Exposure",         "description": "Balance & amount aggregations"},
            {"value": "volume",            "label": "Volume",           "description": "Account count features"},
            {"value": "delinquency",       "label": "Delinquency",      "description": "DPD / overdue analysis"},
            {"value": "utilization",       "label": "Utilization",      "description": "Credit utilization ratio"},
            {"value": "vintage",           "label": "Vintage",          "description": "Account age / maturity"},
            {"value": "recency",           "label": "Recency",          "description": "Months since event"},
            {"value": "trend",             "label": "Trend",            "description": "Window-to-window trend"},
            {"value": "balance_dynamics",  "label": "Balance Dynamics", "description": "Monthly balance evolution"},
            {"value": "writeoff",          "label": "WriteOff",         "description": "Write-off event features"},
            {"value": "settlement",        "label": "Settlement",       "description": "Settlement event features"},
            {"value": "portfolio_mix",     "label": "Portfolio Mix",    "description": "Product/segment composition"},
            {"value": "risk_ratio",        "label": "Risk Ratio",       "description": "FOIR, LVR, debt burden"},
            {"value": "transition_matrix", "label": "Transition Matrix","description": "DPD band state transitions"},
            {"value": "vintage_cohort",    "label": "Vintage Cohort",   "description": "Origination cohort performance"},
            {"value": "stability_score",   "label": "Stability Score",  "description": "PSI / rank-order stability"},
        ],
        "measures_by_subcat": {
            "exposure": [
                {"value": "sanctioned_amount",  "label": "Sanctioned Amount",        "col": "sanction_amount"},
                {"value": "current_balance",    "label": "Outstanding Balance",      "col": "current_balance"},
                {"value": "overdue_amount",     "label": "Overdue Amount",           "col": "overdue_amount"},
                {"value": "credit_limit",       "label": "Credit Limit",             "col": "credit_limit"},
                {"value": "emi_amount",         "label": "EMI Amount",               "col": "emi_amount"},
                {"value": "writeoff_amount",    "label": "Writeoff Amount",          "col": "writeoff_amount"},
                {"value": "settlement_amount",  "label": "Settlement Amount",        "col": None},
            ],
            "volume": [
                {"value": "active_count",    "label": "Active Account Count",   "col": "account_status"},
                {"value": "closed_count",    "label": "Closed Account Count",   "col": "account_status"},
                {"value": "total_count",     "label": "Total Account Count",    "col": "account_status"},
                {"value": "writeoff_count",  "label": "Writeoff Count",         "col": "writeoff_amount"},
                {"value": "settled_count",   "label": "Settled Count",          "col": None},
            ],
            "delinquency": [
                {"value": "dpd",             "label": "Days Past Due (DPD)",    "col": "dpd"},
                {"value": "overdue_amount",  "label": "Overdue Amount",         "col": "overdue_amount"},
                {"value": "dpd_30",          "label": "DPD 30+ Count (SMA)",    "col": "dpd"},
                {"value": "dpd_60",          "label": "DPD 60+ Count",          "col": "dpd"},
                {"value": "dpd_90",          "label": "DPD 90+ / NPA Count",    "col": "dpd"},
                {"value": "delinquent_flag", "label": "Ever Delinquent Flag",   "col": "dpd"},
            ],
            "utilization": [
                {"value": "utilization_ratio", "label": "Balance / Credit Limit",   "col": "current_balance"},
                {"value": "high_util_flag",    "label": "High Utilization Flag",    "col": "credit_limit"},
                {"value": "avg_utilization",   "label": "Average Utilization",      "col": "credit_limit"},
                {"value": "max_utilization",   "label": "Max Utilization (peak)",   "col": "credit_limit"},
            ],
            "vintage": [
                {"value": "account_age",          "label": "Account Age (months)",          "col": "date_opened"},
                {"value": "months_since_oldest",  "label": "Months Since Oldest Account",  "col": "date_opened"},
                {"value": "months_since_newest",  "label": "Months Since Newest Account",  "col": "date_opened"},
                {"value": "months_since_first_delq", "label": "Months Since First Delinquency", "col": "date_reported"},
            ],
            "recency": [
                {"value": "months_since_last_dpd30",  "label": "Months Since Last DPD ≥ 30", "col": "date_reported"},
                {"value": "months_since_last_dpd60",  "label": "Months Since Last DPD ≥ 60", "col": "date_reported"},
                {"value": "months_since_last_dpd90",  "label": "Months Since Last DPD ≥ 90", "col": "date_reported"},
                {"value": "months_since_last_writeoff","label": "Months Since Last Writeoff", "col": "date_reported"},
                {"value": "months_since_last_settled", "label": "Months Since Last Settled", "col": "date_closed"},
                {"value": "months_since_last_npa",     "label": "Months Since Last NPA",      "col": "date_reported"},
                {"value": "months_since_last_suit",    "label": "Months Since Last Suit Filed","col": "date_reported"},
                {"value": "months_since_peak_exposure","label": "Months Since Peak Exposure",  "col": "date_reported"},
                {"value": "recency_of_transition",     "label": "Months Since Last Status Transition","col": "date_reported"},
            ],
            "trend": [
                {"value": "balance_growth",        "label": "Outstanding Balance",      "col": "current_balance"},
                {"value": "utilization_change",    "label": "Utilization Rate",         "col": "credit_limit"},
                {"value": "dpd_trend",             "label": "DPD (Days Past Due)",      "col": "dpd"},
                {"value": "overdue_trend",         "label": "Overdue Amount",           "col": "overdue_amount"},
                {"value": "account_count_trend",   "label": "Active Account Count",     "col": "account_status"},
                {"value": "emi_trend",             "label": "EMI Amount",               "col": "emi_amount"},
            ],
            "balance_dynamics": [
                {"value": "outstanding_balance",  "label": "Outstanding Balance",         "col": "current_balance"},
                {"value": "overdue_amount",       "label": "Overdue Amount",              "col": "overdue_amount"},
                {"value": "emi_amount",           "label": "EMI Amount",                  "col": "emi_amount"},
                {"value": "peak_balance",         "label": "Peak Balance (Max in Window)","col": "current_balance"},
                {"value": "trough_balance",       "label": "Trough Balance (Min)",        "col": "current_balance"},
                {"value": "avg_monthly_balance",  "label": "Avg Monthly Balance",         "col": "current_balance"},
                {"value": "balance_volatility",   "label": "Balance Volatility (Std Dev)","col": "current_balance"},
                {"value": "time_weighted_balance","label": "Time-Weighted Avg Balance",   "col": "current_balance"},
            ],
            "writeoff":      [
                {"value": "writeoff_amount", "label": "Write-off Amount", "col": "writeoff_amount"},
                {"value": "writeoff_count",  "label": "Write-off Count",  "col": "writeoff_amount"},
            ],
            "settlement":    [
                {"value": "settlement_amount", "label": "Settlement Amount", "col": None},
                {"value": "settlement_count",  "label": "Settlement Count",  "col": None},
            ],
            "portfolio_mix": [
                {"value": "pl_share",             "label": "PL Exposure Share",       "col": "sanction_amount"},
                {"value": "unsecured_share",      "label": "Unsecured Exposure Share","col": "sanction_amount"},
                {"value": "secured_share",        "label": "Secured Exposure Share",  "col": "sanction_amount"},
                {"value": "cc_share",             "label": "CC Exposure Share",       "col": "sanction_amount"},
                {"value": "closed_to_open_ratio", "label": "Closed to Open Ratio",    "col": "account_status"},
                {"value": "loan_type_hhi",        "label": "Loan Type HHI",           "col": "loan_type"},
            ],
            "risk_ratio": [
                {"value": "foir",                   "label": "FOIR (EMI / Income)",         "col": "emi_amount"},
                {"value": "lvr",                    "label": "LVR (Loan / Value)",          "col": "sanction_amount"},
                {"value": "db_ratio",               "label": "Debt Burden Ratio",           "col": "current_balance"},
                {"value": "delinquent_ratio",       "label": "Delinquent Account Ratio",    "col": "dpd"},
                {"value": "high_utilization_ratio", "label": "High Utilization Ratio (≥80%)","col": "credit_limit"},
            ],
            "transition_matrix": [
                {"value": "dpd_to_dpd0",    "label": "DPD>0 → DPD0 (Cure Rate)",      "col": "dpd"},
                {"value": "dpd0_to_dpd30",  "label": "DPD0 → DPD30+ (Default Rate)",  "col": "dpd"},
                {"value": "dpd30_to_dpd90", "label": "DPD30 → DPD90+ (Worsening)",    "col": "dpd"},
                {"value": "active_to_npa",  "label": "Active → NPA Rate",             "col": "account_status"},
                {"value": "npa_to_active",  "label": "NPA → Active (Cure Rate)",      "col": "account_status"},
                {"value": "upgrade_count",  "label": "DPD Band Upgrade Count",        "col": "dpd"},
                {"value": "downgrade_count","label": "DPD Band Downgrade Count",      "col": "dpd"},
                {"value": "net_transition", "label": "Net Transition Score",          "col": "dpd"},
            ],
            "vintage_cohort": [
                {"value": "mob_bucket",          "label": "Months-on-Book Band",           "col": "date_opened"},
                {"value": "vintage_dpd_rate",    "label": "DPD30+ Rate at MOB",            "col": "dpd"},
                {"value": "vintage_npa_rate",    "label": "NPA Rate at MOB",               "col": "account_status"},
                {"value": "cumulative_default",  "label": "Cumulative Default Rate",       "col": "dpd"},
                {"value": "early_delinquency",   "label": "Early Delinquency (MOB 1–3)",   "col": "dpd"},
                {"value": "vintage_cohort_size", "label": "Cohort Account Count",          "col": "date_opened"},
                {"value": "vintage_avg_balance", "label": "Cohort Avg Outstanding Balance","col": "current_balance"},
            ],
            "stability_score": [
                {"value": "psi_score",        "label": "Population Stability Index (PSI)", "col": None},
                {"value": "rank_correlation", "label": "Rank-Order Stability (Spearman ρ)","col": None},
                {"value": "gini_stability",   "label": "Gini Coefficient Stability",       "col": None},
                {"value": "feature_drift",    "label": "Feature Distribution Drift",       "col": None},
            ],
        },
        "aggregations_by_subcat": {
            "exposure":          ["sum", "avg", "max", "min", "count", "median", "std", "variance", "cv", "skew", "kurtosis", "iqr", "outlier_count", "percentile"],
            "volume":            ["count", "sum"],
            "delinquency":       ["count", "max", "avg", "ratio", "flag", "median", "std", "variance", "cv", "skew", "kurtosis"],
            "utilization":       ["avg", "max", "min", "median", "std", "cv", "ratio", "flag"],
            "vintage":           ["avg", "min", "max", "value"],
            "recency":           ["value", "min", "max"],
            "trend":             ["difference", "growth_rate", "ratio", "slope", "acceleration", "volatility", "regression", "classification"],
            "balance_dynamics":  ["max", "min", "avg", "std", "cv", "value", "ratio", "slope"],
            "writeoff":          ["sum", "count", "flag", "avg"],
            "settlement":        ["sum", "count", "flag", "avg"],
            "portfolio_mix":     ["ratio", "index", "avg"],
            "risk_ratio":        ["avg", "max", "min", "ratio"],
            "transition_matrix": ["count", "ratio", "flag", "avg"],
            "vintage_cohort":    ["ratio", "count", "avg"],
            "stability_score":   ["value", "flag"],
        },
        "scope_fields": ["loan_types", "secured", "account_status", "ownership"],
        "threshold_by_subcat": {
            "exposure": None,
            "volume": None,
            "delinquency": {"enabled": True, "type": "dpd", "label": "DPD Threshold", "col": "dpd", "operators": [">=", ">", "=", "<", "<="], "placeholder": "e.g. 30, 60, 90"},
            "utilization": None, "vintage": None, "recency": None, "trend": None,
            "balance_dynamics": None, "writeoff": None, "settlement": None,
            "portfolio_mix": None, "risk_ratio": None,
            "transition_matrix": None, "vintage_cohort": None, "stability_score": None,
        },
    },

    # ══════════════════════════════════════════════════════════════════
    # ACCOUNT
    # ══════════════════════════════════════════════════════════════════
    "Account": {
        "label": "Account", "abbr": "acc",
        "description": "Account portfolio snapshot features", "icon": "🏦",
        "data_source": "normalized_accounts",
        "sub_categories": [
            {"value": "portfolio_count",       "label": "Portfolio Count",       "description": "Account count by status/type"},
            {"value": "portfolio_exposure",    "label": "Portfolio Exposure",    "description": "Balance & amount aggregations"},
            {"value": "credit_age",            "label": "Credit Age",            "description": "Account age & history length"},
            {"value": "account_mix",           "label": "Account Mix",           "description": "Secured/Unsecured/HHI mix"},
            {"value": "delinquency_profile",   "label": "Delinquency Profile",   "description": "DPD bucket & delinquency flags"},
            {"value": "utilization_profile",   "label": "Utilization Profile",   "description": "CC & revolving utilization"},
            {"value": "account_flags",         "label": "Account Flags",         "description": "Binary stress flags"},
            {"value": "derived_ratios",        "label": "Derived Ratios",        "description": "FOIR, NPA ratio, overdue ratio"},
            {"value": "behavioral",            "label": "Behavioral",            "description": "DPD spikes, payment consistency"},
            {"value": "velocity",              "label": "Velocity",              "description": "Window-to-window change"},
            {"value": "recency",               "label": "Recency",               "description": "Months since last event"},
            {"value": "trend",                 "label": "Trend",                 "description": "Directional change"},
            {"value": "distribution",          "label": "Distribution",          "description": "Distribution shape stats"},
            {"value": "concentration",         "label": "Concentration",         "description": "Lender HHI / concentration"},
            {"value": "vintage",               "label": "Vintage / Age",         "description": "Account age & cohort"},
            {"value": "utilization",           "label": "Utilization",           "description": "Portfolio utilization ratios"},
            {"value": "product_mix",           "label": "Product Mix",           "description": "Loan type diversity"},
            {"value": "lifecycle",             "label": "Account Lifecycle",     "description": "Opened/closed in period"},
            {"value": "delinquency_severity",  "label": "Delinquency Severity",  "description": "Severity index & DPD buckets"},
            {"value": "cross_entity",          "label": "Cross Entity",          "description": "Inquiry-to-account joins"},
            {"value": "utilization_engine",    "label": "Utilization Engine",    "description": "Formula-driven utilization"},
            {"value": "payment_behavior",      "label": "Payment Behavior",      "description": "EMI, DPD payment patterns"},
            {"value": "credit_mix",            "label": "Credit Mix",            "description": "Secured/revolving/installment mix"},
        ],
        "measures_by_subcat": {
            "portfolio_count": [
                {"value": "total_accounts",      "label": "Total Accounts",            "col": "account_status"},
                {"value": "active_accounts",     "label": "Active Accounts",           "col": "account_status"},
                {"value": "closed_accounts",     "label": "Closed Accounts",           "col": "account_status"},
                {"value": "npa_accounts",        "label": "NPA Accounts",              "col": "account_status"},
                {"value": "written_off",         "label": "Written Off Accounts",      "col": "writeoff_amount"},
                {"value": "settled_accounts",    "label": "Settled Accounts",          "col": None},
                {"value": "delinquent_accounts", "label": "Delinquent Accounts (DPD>0)","col": "dpd"},
            ],
            "portfolio_exposure": [
                {"value": "total_outstanding",  "label": "Total Outstanding Balance",  "col": "current_balance"},
                {"value": "total_sanctioned",   "label": "Total Sanctioned Amount",    "col": "sanction_amount"},
                {"value": "total_overdue",      "label": "Total Overdue Amount",       "col": "overdue_amount"},
                {"value": "total_credit_limit", "label": "Total Credit Limit",         "col": "credit_limit"},
                {"value": "total_writeoff",     "label": "Total Writeoff Amount",      "col": "writeoff_amount"},
                {"value": "total_emi",          "label": "Total EMI Obligation",       "col": "emi_amount"},
                {"value": "avg_balance",        "label": "Avg Outstanding Balance",   "col": "current_balance"},
                {"value": "max_balance",        "label": "Max Outstanding Balance",   "col": "current_balance"},
            ],
            "credit_age": [
                {"value": "age_oldest",          "label": "Age of Oldest Account (months)",  "col": "date_opened"},
                {"value": "age_newest",          "label": "Age of Newest Account (months)",  "col": "date_opened"},
                {"value": "credit_history_len",  "label": "Credit History Length (months)",  "col": "date_opened"},
                {"value": "months_since_opened", "label": "Months Since Last Account Opened","col": "date_opened"},
                {"value": "months_since_closed", "label": "Months Since Last Account Closed","col": "date_closed"},
                {"value": "avg_account_age",     "label": "Average Account Age (months)",    "col": "date_opened"},
            ],
            "account_mix": [
                {"value": "secured_unsecured_ratio", "label": "Secured / Unsecured Count Ratio",   "col": "is_secured"},
                {"value": "secured_exposure_ratio",  "label": "Secured Exposure Ratio (Amt)",       "col": "sanction_amount"},
                {"value": "loan_type_hhi",           "label": "Loan Type HHI (Concentration)",      "col": "loan_type"},
                {"value": "num_distinct_lenders",    "label": "Number of Distinct Lenders",          "col": "lender_name"},
                {"value": "top_lender_share",        "label": "Top Lender Share (Count %)",          "col": "lender_name"},
                {"value": "num_distinct_types",      "label": "Number of Distinct Loan Types",       "col": "loan_type"},
                {"value": "pl_share",                "label": "PL Share of Total Exposure",          "col": "sanction_amount"},
                {"value": "cc_share",                "label": "CC Share of Total Exposure",          "col": "sanction_amount"},
            ],
            "delinquency_profile": [
                {"value": "current_dpd",        "label": "Current DPD (latest)",      "col": "dpd"},
                {"value": "max_dpd_ever",       "label": "Max DPD Ever",              "col": "dpd"},
                {"value": "count_dpd30",        "label": "Count of 30+ DPD Accounts", "col": "dpd"},
                {"value": "count_dpd60",        "label": "Count of 60+ DPD Accounts", "col": "dpd"},
                {"value": "count_dpd90",        "label": "Count of 90+ DPD Accounts", "col": "dpd"},
                {"value": "ever_npa_flag",      "label": "Ever NPA Flag",             "col": "account_status"},
                {"value": "ever_wo_flag",       "label": "Ever Written Off Flag",     "col": "writeoff_amount"},
                {"value": "ever_settled_flag",  "label": "Ever Settled Flag",         "col": None},
            ],
            "utilization_profile": [
                {"value": "cc_utilization",       "label": "CC Utilization (Balance/CreditLimit)", "col": "credit_limit"},
                {"value": "avg_util_all_cards",   "label": "Avg Utilization Across Cards",        "col": "credit_limit"},
                {"value": "max_util_single_card", "label": "Max Utilization (Single Card)",        "col": "credit_limit"},
                {"value": "high_util_count",      "label": "Count of High Utilization Accounts (>75%)", "col": "credit_limit"},
                {"value": "high_util_flag",       "label": "High Utilization Flag (any card >80%)", "col": "credit_limit"},
            ],
            "account_flags": [
                {"value": "has_npa",        "label": "Has Any NPA Account",          "col": "account_status"},
                {"value": "has_writeoff",   "label": "Has Any Written Off Account",  "col": "writeoff_amount"},
                {"value": "has_settled",    "label": "Has Any Settled Account",      "col": None},
                {"value": "has_overdue",    "label": "Has Any Overdue Account",      "col": "overdue_amount"},
                {"value": "has_sma",        "label": "Has Any SMA Account",          "col": "account_status"},
                {"value": "has_dpd30",      "label": "Has Account with DPD ≥ 30",   "col": "dpd"},
                {"value": "has_dpd90",      "label": "Has Account with DPD ≥ 90",   "col": "dpd"},
                {"value": "has_any_stress", "label": "Has Any Stress Account",       "col": "account_status"},
            ],
            "derived_ratios": [
                {"value": "foir",                   "label": "FOIR (Total EMI / Income)",           "col": "emi_amount"},
                {"value": "active_account_ratio",   "label": "Active Account Ratio",               "col": "account_status"},
                {"value": "delinquent_ratio",       "label": "Delinquent Account Ratio (DPD>0)",   "col": "dpd"},
                {"value": "npa_ratio",              "label": "NPA Ratio (NPA / Total)",            "col": "account_status"},
                {"value": "overdue_to_outstanding", "label": "Overdue to Outstanding Ratio",       "col": "overdue_amount"},
                {"value": "emi_to_sanction",        "label": "EMI to Sanction Amount Ratio",       "col": "emi_amount"},
                {"value": "writeoff_to_sanctioned", "label": "Writeoff to Total Sanctioned",       "col": "writeoff_amount"},
            ],
            "behavioral": [
                {"value": "ever_90dpd",             "label": "Ever Had 90+ DPD",                 "col": "dpd"},
                {"value": "months_since_last_delq", "label": "Months Since Last Delinquency",    "col": "date_reported"},
                {"value": "dpd_spike_indicator",    "label": "DPD Spike Indicator",              "col": "dpd"},
                {"value": "payment_consistency",    "label": "Payment Consistency Score",        "col": "dpd"},
                {"value": "balance_paydown_rate",   "label": "Balance Paydown Rate",             "col": "current_balance"},
                {"value": "account_closure_rate",   "label": "Account Closure Rate",             "col": "date_closed"},
            ],
            "velocity": [
                {"value": "new_accounts_opened",  "label": "New Accounts Opened in Period",        "col": "date_opened"},
                {"value": "accounts_closed",      "label": "Accounts Closed in Period",            "col": "date_closed"},
                {"value": "balance_growth",       "label": "Balance Change (recent vs prior)",     "col": "current_balance"},
                {"value": "overdue_acceleration", "label": "Overdue Amount Acceleration",          "col": "overdue_amount"},
                {"value": "dpd_frequency_change", "label": "Change in DPD Frequency",             "col": "dpd"},
                {"value": "lender_count_change",  "label": "Change in Number of Lenders",         "col": "lender_name"},
            ],
            "recency": [
                {"value": "months_since_last_acc_open",    "label": "Months Since Last Account Opened",   "col": "date_opened"},
                {"value": "months_since_last_acc_close",   "label": "Months Since Last Account Closed",   "col": "date_closed"},
                {"value": "months_since_last_acc_delq",    "label": "Months Since Last Delinquency",      "col": "date_reported"},
                {"value": "months_since_last_acc_npa",     "label": "Months Since Last NPA Status",       "col": "account_status"},
                {"value": "months_since_last_acc_overdue", "label": "Months Since Last Overdue Event",    "col": "overdue_amount"},
                {"value": "months_since_oldest_acc",       "label": "Months Since Oldest Account Opened", "col": "date_opened"},
            ],
            "trend": [
                {"value": "balance_change",         "label": "Balance Change (Window vs Prior)",      "col": "current_balance"},
                {"value": "overdue_change",         "label": "Overdue Amount Change",                "col": "overdue_amount"},
                {"value": "account_count_change",   "label": "Account Count Change",                 "col": "account_status"},
                {"value": "dpd_change",             "label": "DPD Level Change",                     "col": "dpd"},
                {"value": "utilization_change_acc", "label": "Utilization Change",                   "col": "credit_limit"},
                {"value": "emi_change",             "label": "EMI Obligation Change",                "col": "emi_amount"},
            ],
            "distribution": [
                {"value": "balance_distribution",      "label": "Outstanding Balance",     "col": "current_balance"},
                {"value": "credit_limit_distribution", "label": "Credit Limit",            "col": "credit_limit"},
                {"value": "sanction_distribution",     "label": "Sanctioned Amount",       "col": "sanction_amount"},
                {"value": "overdue_distribution",      "label": "Overdue Amount",          "col": "overdue_amount"},
                {"value": "emi_distribution",          "label": "EMI Amount",              "col": "emi_amount"},
                {"value": "dpd_distribution",          "label": "DPD (Across Accounts)",   "col": "dpd"},
            ],
            "concentration": [
                {"value": "top_lender_exposure_ratio",  "label": "Top Lender Exposure Ratio",       "col": "current_balance"},
                {"value": "top_3_lender_share",         "label": "Top 3 Lenders Share",             "col": "current_balance"},
                {"value": "lender_concentration_index", "label": "Lender Concentration Index (HHI)","col": "sanction_amount"},
                {"value": "loan_type_concentration",    "label": "Loan Type Concentration (HHI)",   "col": "loan_type"},
                {"value": "single_lender_flag",         "label": "Single Lender Dominance (>80%)",  "col": "lender_name"},
            ],
            "vintage": [
                {"value": "avg_account_age",          "label": "Average Account Age (months)",      "col": "date_opened"},
                {"value": "oldest_account_age",       "label": "Oldest Account Age (months)",       "col": "date_opened"},
                {"value": "newest_account_age",       "label": "Newest Account Age (months)",       "col": "date_opened"},
                {"value": "new_accounts_last_6m",     "label": "New Accounts Opened (Last 6m)",     "col": "date_opened"},
                {"value": "new_accounts_last_12m",    "label": "New Accounts Opened (Last 12m)",    "col": "date_opened"},
                {"value": "weighted_avg_age",         "label": "Weighted Avg Age (by Balance)",     "col": "date_opened"},
            ],
            "utilization": [
                {"value": "acc_credit_utilization",    "label": "Portfolio Credit Utilization (SUM bal/SUM limit)", "col": "credit_limit"},
                {"value": "credit_utilization_ratio",  "label": "Credit Utilization Ratio (Avg per account)",      "col": "credit_limit"},
                {"value": "max_util_single_account",   "label": "Max Utilization (Worst Single Account)",          "col": "credit_limit"},
                {"value": "high_util_accounts_ratio",  "label": "High Utilization Account Ratio (>75%)",           "col": "credit_limit"},
                {"value": "util_above_80_count",       "label": "Count Accounts Util > 80%",                       "col": "credit_limit"},
                {"value": "balance_to_sanction_ratio", "label": "Balance to Sanction Ratio (Portfolio)",           "col": "sanction_amount"},
                {"value": "overdue_to_outstanding",    "label": "Overdue to Outstanding Ratio",                    "col": "overdue_amount"},
            ],
            "product_mix": [
                {"value": "product_mix_score",         "label": "Product Mix Score (diversity)",     "col": "loan_type"},
                {"value": "unique_product_count",      "label": "Unique Product / Loan Type Count",  "col": "loan_type"},
                {"value": "product_hhi",               "label": "Product HHI (concentration)",       "col": "loan_type"},
                {"value": "secured_product_share",     "label": "Secured Product Share (%)",         "col": "sanction_amount"},
                {"value": "revolving_product_share",   "label": "Revolving Product Share (CC/OD)",   "col": "loan_type"},
                {"value": "installment_product_share", "label": "Installment Product Share",         "col": "loan_type"},
                {"value": "cc_to_total_ratio",         "label": "Credit Card to Total Accounts Ratio","col": "loan_type"},
            ],
            "lifecycle": [
                {"value": "new_accounts_opened",    "label": "New Accounts Opened in Period",    "col": "date_opened"},
                {"value": "accounts_closed_period", "label": "Accounts Closed in Period",        "col": "date_closed"},
                {"value": "net_account_change",     "label": "Net Account Change (Opened−Closed)","col": "date_opened"},
                {"value": "newly_opened_balance",   "label": "Total Balance of Newly Opened Accounts","col": "current_balance"},
                {"value": "new_to_total_ratio",     "label": "New Accounts / Total Accounts Ratio","col": "date_opened"},
                {"value": "churned_account_ratio",  "label": "Churned Account Ratio (Closed/All)", "col": "date_closed"},
            ],
            "delinquency_severity": [
                {"value": "dpd_90plus_accounts",      "label": "Count of Accounts with DPD ≥ 90",        "col": "dpd"},
                {"value": "dpd_60plus_accounts",      "label": "Count of Accounts with DPD ≥ 60",        "col": "dpd"},
                {"value": "dpd_30plus_accounts",      "label": "Count of Accounts with DPD ≥ 30",        "col": "dpd"},
                {"value": "dpd_severity_index",       "label": "DPD Severity Index (weighted bucket)",   "col": "dpd"},
                {"value": "max_dpd_across_accounts",  "label": "Maximum DPD Across All Accounts",        "col": "dpd"},
                {"value": "avg_dpd_delinquent",       "label": "Average DPD (Delinquent Accounts Only)", "col": "dpd"},
                {"value": "severe_delinquency_ratio", "label": "Severe Delinquency Ratio (90+ DPD/Total)","col": "dpd"},
                {"value": "npa_exposure_ratio",       "label": "NPA Exposure as % of Total Outstanding", "col": "current_balance"},
            ],
            "cross_entity": [
                {"value": "accounts_with_inquiry_last_30d", "label": "Accounts with Inquiry in Last 30 Days","col": "customer_id"},
                {"value": "accounts_with_inquiry_last_90d", "label": "Accounts with Inquiry in Last 90 Days","col": "customer_id"},
                {"value": "inquiry_to_account_ratio",       "label": "Inquiry to Account Count Ratio",       "col": "customer_id"},
                {"value": "inq_count_per_active_lender",    "label": "Inquiry Count per Active Lender",      "col": "lender_name"},
            ],
            "utilization_engine": [
                {"value": "credit_utilization_ratio",    "label": "Credit Utilization Ratio (Balance÷Credit Limit)",     "col": "credit_limit"},
                {"value": "balance_to_sanction_ratio",   "label": "Balance to Sanction Ratio",                           "col": "sanction_amount"},
                {"value": "overdue_to_balance_ratio",    "label": "Overdue to Balance Ratio",                            "col": "overdue_amount"},
                {"value": "avg_utilization",             "label": "Average Utilization (All Accounts)",                  "col": "credit_limit"},
                {"value": "max_utilization_account",     "label": "Max Utilization (Worst Single Account)",              "col": "credit_limit"},
                {"value": "high_util_accounts",          "label": "Count of High Utilization Accounts (>75%)",           "col": "credit_limit"},
                {"value": "util_above_80",               "label": "Count of Accounts with Utilization > 80%",            "col": "credit_limit"},
                {"value": "util_above_90",               "label": "Count of Maxed-Out Accounts (>90%)",                  "col": "credit_limit"},
            ],
            "payment_behavior": [
                {"value": "on_time_payment_ratio",    "label": "On-Time Payment Ratio (DPD=0 months/Total)", "col": "dpd"},
                {"value": "missed_payment_count",     "label": "Missed Payment Count (DPD>0 events)",        "col": "dpd"},
                {"value": "dpd_transition_rate",      "label": "DPD Transition Rate (clean→delinquent)",     "col": "dpd"},
                {"value": "rolling_dpd_trend",        "label": "Rolling DPD Trend (slope of DPD)",           "col": "dpd"},
                {"value": "consecutive_clean_months", "label": "Consecutive Clean Months (DPD=0 streak)",    "col": "dpd"},
                {"value": "payment_consistency_score","label": "Payment Consistency Score (0–100)",          "col": "dpd"},
                {"value": "ever_missed_12m",          "label": "Ever Missed Payment in Last 12m (flag)",     "col": "dpd"},
            ],
            "credit_mix": [
                {"value": "credit_mix_score",           "label": "Credit Mix Score (composite diversity)",    "col": "loan_type"},
                {"value": "secured_to_unsecured_ratio", "label": "Secured to Unsecured Ratio (count-based)", "col": "sanction_amount"},
                {"value": "secured_exposure_ratio",     "label": "Secured Exposure Ratio (balance-based)",   "col": "current_balance"},
                {"value": "loan_type_diversity",        "label": "Loan Type Diversity Index (Shannon)",      "col": "loan_type"},
                {"value": "revolving_to_installment",   "label": "Revolving to Installment Count Ratio",     "col": "loan_type"},
                {"value": "has_both_types",             "label": "Has Both Secured and Unsecured (flag)",    "col": "is_secured"},
                {"value": "unsecured_exposure_share",   "label": "Unsecured Exposure Share (% of total)",   "col": "current_balance"},
            ],
        },
        "aggregations_by_subcat": {
            "portfolio_count":      ["count", "ratio"],
            "portfolio_exposure":   ["sum", "avg", "max", "min", "median", "std", "cv", "percentile"],
            "credit_age":           ["value", "min", "max", "avg"],
            "account_mix":          ["ratio", "count", "index"],
            "delinquency_profile":  ["flag", "count", "max", "avg", "ratio"],
            "utilization_profile":  ["avg", "max", "ratio", "flag", "count"],
            "account_flags":        ["flag"],
            "derived_ratios":       ["ratio", "percentage", "avg"],
            "behavioral":           ["flag", "count", "ratio", "value"],
            "velocity":             ["difference", "ratio", "growth_rate"],
            "recency":              ["value", "min", "max"],
            "trend":                ["difference", "growth_rate", "ratio", "slope"],
            "distribution":         ["std", "variance", "cv", "percentile", "iqr", "median", "skew"],
            "concentration":        ["ratio", "index", "count", "flag"],
            "vintage":              ["avg", "max", "min", "count", "median"],
            "utilization":          ["ratio", "avg", "max", "flag", "count"],
            "product_mix":          ["ratio", "count", "index", "avg"],
            "lifecycle":            ["count", "sum", "ratio", "avg"],
            "delinquency_severity": ["count", "ratio", "max", "avg", "index", "flag"],
            "cross_entity":         ["count", "ratio", "flag", "avg"],
            "utilization_engine":   ["ratio", "avg", "max", "count", "flag", "std", "percentile"],
            "payment_behavior":     ["ratio", "count", "avg", "flag", "slope", "value"],
            "credit_mix":           ["ratio", "index", "count", "flag", "avg"],
        },
        "scope_fields": ["loan_types", "secured", "account_status", "ownership"],
        "threshold_by_subcat": {
            "portfolio_count": None, "portfolio_exposure": None, "credit_age": None,
            "account_mix": None,
            "delinquency_profile": {"enabled": True, "type": "dpd", "label": "DPD Threshold", "col": "dpd", "operators": [">=", ">", "="], "placeholder": "e.g. 30, 60, 90"},
            "utilization_profile": None, "account_flags": None, "derived_ratios": None,
            "behavioral": None, "velocity": None, "recency": None, "trend": None,
            "distribution": None, "concentration": None, "vintage": None, "utilization": None,
            "product_mix": None, "lifecycle": None, "delinquency_severity": None,
            "cross_entity": None, "utilization_engine": None,
            "payment_behavior": {"enabled": True, "type": "dpd", "label": "DPD Threshold", "col": "dpd", "operators": [">=", ">", "="], "placeholder": "e.g. 30"},
            "credit_mix": None,
        },
    },

    # ══════════════════════════════════════════════════════════════════
    # TRADE HISTORY
    # ══════════════════════════════════════════════════════════════════
    "Trade History": {
        "label": "Trade History", "abbr": "th",
        "description": "Month-wise DPD/balance payment history features", "icon": "📈",
        "data_source": "normalized_accounts",
        "sub_categories": [
            {"value": "exposure",              "label": "Exposure",             "description": "Monthly balance aggregations"},
            {"value": "volume",                "label": "Volume",               "description": "Count of months in states"},
            {"value": "delinquency",           "label": "Delinquency",          "description": "DPD measures from history string"},
            {"value": "utilization",           "label": "Utilization",          "description": "Historical utilization ratio"},
            {"value": "vintage",               "label": "Vintage",              "description": "Account age & history length"},
            {"value": "recency",               "label": "Recency",              "description": "Months since last event in history"},
            {"value": "trend",                 "label": "Trend",                "description": "Window-to-window trend in history"},
            {"value": "balance_dynamics",      "label": "Balance Dynamics",     "description": "Dynamic balance evolution"},
            {"value": "writeoff",              "label": "Write-Off",            "description": "Write-off event detection"},
            {"value": "settlement",            "label": "Settlement",           "description": "Settlement event detection"},
            {"value": "portfolio_mix",         "label": "Portfolio Mix",        "description": "Historical product composition"},
            {"value": "risk_ratio",            "label": "Risk Ratio",           "description": "Historical risk ratios"},
            {"value": "transition_matrix",     "label": "Transition Matrix",    "description": "DPD-band transitions in history"},
            {"value": "vintage_cohort",        "label": "Vintage Cohort",       "description": "Cohort performance from history"},
            {"value": "stability_score",       "label": "Stability Score",      "description": "PSI from payment history"},
            {"value": "payment_behaviour",     "label": "Payment Behaviour",    "description": "On-time/late/missed payment patterns"},
            {"value": "risk_momentum",         "label": "Risk Momentum",        "description": "Velocity & acceleration of risk signals"},
            {"value": "delinquency_severity_seq","label": "Delinquency Severity","description": "DPD sequence severity & streaks"},
            {"value": "credit_line_dynamics",  "label": "Credit Line Dynamics", "description": "Credit limit changes & util spikes"},
            {"value": "account_stability_idx", "label": "Account Stability Index","description": "Statistical stability CV/IQR/entropy"},
            {"value": "streak_features",       "label": "Payment Streak",       "description": "Consecutive run analysis on DPD_String"},
            {"value": "behaviour_trend",       "label": "Behaviour Trend",      "description": "Recent vs historical window comparison"},
            {"value": "cure_behaviour",        "label": "Cure Behaviour",       "description": "Recovery time after delinquency"},
            {"value": "roll_rate",             "label": "Roll Rate",            "description": "DPD bucket-to-bucket transition rates"},
            {"value": "payment_stability",     "label": "Payment Stability",    "description": "Erratic payment behaviour measurement"},
        ],
        "measures_by_subcat": {
            "exposure": [
                {"value": "hist_avg_balance",      "label": "Avg Monthly Balance (History)",    "col": "balance_history"},
                {"value": "hist_max_balance",      "label": "Peak Monthly Balance (History)",   "col": "balance_history"},
                {"value": "hist_sum_balance",      "label": "Sum of Monthly Balances",          "col": "balance_history"},
                {"value": "hist_avg_overdue",      "label": "Avg Monthly Overdue (History)",    "col": "balance_history"},
                {"value": "hist_max_overdue",      "label": "Peak Overdue Amount (History)",    "col": "balance_history"},
                {"value": "hist_avg_emi",          "label": "Avg EMI Amount (History)",         "col": "balance_history"},
                {"value": "hist_sanction_amount",  "label": "Sanctioned Amount (Static)",       "col": "sanction_amount"},
            ],
            "volume": [
                {"value": "months_with_dpd",       "label": "Months with Any DPD (>0)",         "col": "dpd_string"},
                {"value": "total_history_months",  "label": "Total History Length (months)",    "col": "dpd_string"},
                {"value": "months_as_active",      "label": "Months in Active Status",          "col": "dpd_string"},
                {"value": "months_as_npa",         "label": "Months in NPA / Written-Off",      "col": "dpd_string"},
                {"value": "months_ever_delinquent","label": "Total Delinquent Months (ever)",   "col": "dpd_string"},
            ],
            "delinquency": [
                {"value": "max_dpd_in_history",   "label": "Max DPD in History Window",    "col": "dpd_string"},
                {"value": "count_dpd30_months",   "label": "Count of DPD 30+ Months",      "col": "dpd_string"},
                {"value": "count_dpd60_months",   "label": "Count of DPD 60+ Months",      "col": "dpd_string"},
                {"value": "count_dpd90_months",   "label": "Count of DPD 90+ Months",      "col": "dpd_string"},
                {"value": "avg_dpd_history",      "label": "Avg DPD Over History Window",  "col": "dpd_string"},
                {"value": "ever_dpd90_flag",      "label": "Ever DPD 90+ Flag (in window)","col": "dpd_string"},
            ],
            "utilization": [
                {"value": "avg_util_history",     "label": "Avg Utilization Over History",  "col": "balance_history"},
                {"value": "max_util_history",     "label": "Peak Utilization in History",   "col": "balance_history"},
                {"value": "min_util_history",     "label": "Trough Utilization in History", "col": "balance_history"},
                {"value": "util_above_80_months", "label": "Months with Utilization ≥ 80%","col": "balance_history"},
            ],
            "vintage": [
                {"value": "account_age_months",      "label": "Account Age (months)",              "col": "date_opened"},
                {"value": "hist_months_on_books",    "label": "Months on Books (History Length)",  "col": "dpd_string"},
                {"value": "months_since_first_delq", "label": "Months Since First Delinquency",   "col": "dpd_string"},
                {"value": "months_since_first_dpd90","label": "Months Since First DPD 90+",       "col": "dpd_string"},
            ],
            "recency": [
                {"value": "months_since_last_dpd30",      "label": "Months Since Last DPD ≥ 30",         "col": "dpd_string"},
                {"value": "months_since_last_dpd60",      "label": "Months Since Last DPD ≥ 60",         "col": "dpd_string"},
                {"value": "months_since_last_dpd90",      "label": "Months Since Last DPD ≥ 90 (NPA)",   "col": "dpd_string"},
                {"value": "months_since_last_dpd_custom", "label": "Months Since Last DPD (Custom)",     "col": "dpd_string"},
                {"value": "months_since_last_writeoff",   "label": "Months Since Last Writeoff",         "col": "writeoff_amount"},
                {"value": "months_since_last_payment",    "label": "Months Since Last Payment",          "col": "date_reported"},
                {"value": "months_since_last_settled",    "label": "Months Since Last Settled",          "col": "date_closed"},
                {"value": "months_since_last_npa",        "label": "Months Since Last NPA Status",       "col": "dpd_string"},
                {"value": "months_since_peak_balance",    "label": "Months Since Peak Balance (History)","col": "balance_history"},
            ],
            "trend": [
                {"value": "hist_dpd_trend",          "label": "DPD Trend (History Window)",        "col": "dpd_string"},
                {"value": "hist_balance_trend",      "label": "Balance Trend (History Window)",    "col": "balance_history"},
                {"value": "hist_overdue_trend",      "label": "Overdue Amount Trend",              "col": "balance_history"},
                {"value": "hist_utilization_trend",  "label": "Utilization Rate Trend",            "col": "balance_history"},
                {"value": "hist_dpd_volatility",     "label": "DPD Volatility (Std Dev History)",  "col": "dpd_string"},
                {"value": "hist_balance_volatility", "label": "Balance Volatility Trend",          "col": "balance_history"},
            ],
            "balance_dynamics": [
                {"value": "hist_outstanding_balance",  "label": "Hist Avg Outstanding Balance",    "col": "balance_history"},
                {"value": "hist_peak_balance",         "label": "Hist Peak Balance (Max)",         "col": "balance_history"},
                {"value": "hist_trough_balance",       "label": "Hist Trough Balance (Min)",       "col": "balance_history"},
                {"value": "hist_avg_monthly_balance",  "label": "Avg Monthly Balance (Window)",    "col": "balance_history"},
                {"value": "hist_balance_volatility",   "label": "Balance Volatility (Std Dev)",    "col": "balance_history"},
                {"value": "hist_balance_cv",           "label": "Balance CV (Volatility/Mean)",    "col": "balance_history"},
                {"value": "hist_time_weighted_balance","label": "Time-Weighted Avg Balance",       "col": "balance_history"},
                {"value": "hist_emi_amount",           "label": "Hist Avg EMI Amount",             "col": "balance_history"},
                {"value": "hist_credit_limit",         "label": "Hist Avg Credit Limit",           "col": "balance_history"},
            ],
            "writeoff": [
                {"value": "hist_writeoff_amount", "label": "Write-off Amount (History)", "col": "writeoff_amount"},
                {"value": "hist_writeoff_count",  "label": "Write-off Count (History)",  "col": "writeoff_amount"},
            ],
            "settlement": [
                {"value": "hist_settlement_amount", "label": "Settlement Amount (History)", "col": None},
                {"value": "hist_settlement_count",  "label": "Settlement Count (History)",  "col": None},
            ],
            "portfolio_mix": [
                {"value": "hist_pl_share",           "label": "PL Balance Share (History)",        "col": "balance_history"},
                {"value": "hist_unsecured_share",    "label": "Unsecured Balance Share (History)", "col": "balance_history"},
                {"value": "hist_cc_share",           "label": "CC Balance Share (History)",        "col": "balance_history"},
                {"value": "hist_loan_type_hhi",      "label": "Loan Type HHI (History)",           "col": "loan_type"},
            ],
            "risk_ratio": [
                {"value": "hist_dpd_rate",              "label": "DPD Month Rate (DPD>0/Total Months)",   "col": "dpd_string"},
                {"value": "hist_stress_rate",           "label": "Stress Rate (NPA+WO Months/Total)",     "col": "dpd_string"},
                {"value": "hist_overdue_to_balance",    "label": "Avg Overdue-to-Balance Ratio (Hist)",   "col": "balance_history"},
                {"value": "hist_high_utilization_ratio","label": "High Util Month Ratio (≥80% months)",  "col": "balance_history"},
                {"value": "hist_emi_obligation_ratio",  "label": "EMI Obligation Ratio (Avg EMI/Avg Bal)","col": "balance_history"},
            ],
            "transition_matrix": [
                {"value": "hist_dpd_to_dpd0",       "label": "DPD>0 → DPD0 (Cure Rate, History)",     "col": "dpd_string"},
                {"value": "hist_dpd0_to_dpd30",     "label": "DPD0 → DPD30+ (Default Rate, History)", "col": "dpd_string"},
                {"value": "hist_dpd30_to_dpd90",    "label": "DPD30 → DPD90+ (Worsening, History)",   "col": "dpd_string"},
                {"value": "hist_dpd90_to_dpd0",     "label": "DPD90 → DPD0 (Recovery, History)",      "col": "dpd_string"},
                {"value": "hist_upgrade_count",     "label": "DPD Band Upgrade Count (History)",       "col": "dpd_string"},
                {"value": "hist_downgrade_count",   "label": "DPD Band Downgrade Count (History)",     "col": "dpd_string"},
                {"value": "hist_net_transition",    "label": "Net Transition Score (Upgrades−Downgrades)","col": "dpd_string"},
            ],
            "vintage_cohort": [
                {"value": "hist_vintage_dpd_rate",   "label": "DPD30+ Rate at MOB (History)",      "col": "dpd_string"},
                {"value": "hist_vintage_npa_rate",   "label": "NPA Rate at MOB (History)",         "col": "dpd_string"},
                {"value": "hist_early_delinquency",  "label": "Early Delinquency MOB 1–3 (History)","col": "dpd_string"},
                {"value": "hist_cohort_avg_balance", "label": "Cohort Avg Balance (History)",       "col": "balance_history"},
                {"value": "hist_cohort_size",        "label": "Cohort Account Count (History)",     "col": "date_opened"},
            ],
            "stability_score": [
                {"value": "hist_psi_score",        "label": "History PSI (Population Stability Index)","col": None},
                {"value": "hist_rank_correlation", "label": "Rank-Order Stability (Spearman ρ)",       "col": None},
                {"value": "hist_gini_stability",   "label": "Gini Coefficient Stability",              "col": None},
                {"value": "hist_feature_drift",    "label": "History Feature Distribution Drift",      "col": None},
            ],
            "payment_behaviour": [
                {"value": "hist_on_time_payment_ratio",   "label": "On-Time Payment Ratio (History)",      "col": "dpd_string"},
                {"value": "hist_late_payment_count",      "label": "Late Payment Count (DPD 1–29)",        "col": "dpd_string"},
                {"value": "hist_missed_payment_count",    "label": "Missed Payment Count (DPD 30+)",       "col": "dpd_string"},
                {"value": "hist_missed_payment_ratio",    "label": "Missed Payment Ratio (History)",       "col": "dpd_string"},
                {"value": "hist_max_consecutive_on_time", "label": "Max Consecutive On-Time Payments",     "col": "dpd_string"},
                {"value": "hist_max_consecutive_missed",  "label": "Max Consecutive Missed Payments",      "col": "dpd_string"},
                {"value": "hist_payment_regularity_score","label": "Payment Regularity Score (0–100)",     "col": "dpd_string"},
                {"value": "hist_payment_recovery_rate",   "label": "Payment Recovery Rate (after missed)", "col": "dpd_string"},
            ],
            "risk_momentum": [
                {"value": "hist_dpd_velocity",        "label": "DPD Velocity (rate of DPD change)",     "col": "dpd_string"},
                {"value": "hist_dpd_acceleration",    "label": "DPD Acceleration (2nd derivative)",     "col": "dpd_string"},
                {"value": "hist_overdue_velocity",    "label": "Overdue Velocity (monthly change rate)","col": "balance_history"},
                {"value": "hist_balance_velocity",    "label": "Balance Velocity (growth rate)",        "col": "balance_history"},
                {"value": "hist_util_velocity",       "label": "Utilization Velocity (change rate)",    "col": "balance_history"},
                {"value": "hist_risk_momentum_score", "label": "Composite Risk Momentum Score",         "col": None},
                {"value": "hist_stress_trajectory",   "label": "Stress Trajectory (improving/deteriorating)","col": None},
            ],
            "delinquency_severity_seq": [
                {"value": "hist_dpd_severity_score",   "label": "DPD Severity Score (weighted)",      "col": "dpd_string"},
                {"value": "hist_max_dpd_streak",       "label": "Max Consecutive DPD 30+ Months",     "col": "dpd_string"},
                {"value": "hist_max_dpd90_streak",     "label": "Max Consecutive DPD 90+ Streak",     "col": "dpd_string"},
                {"value": "hist_dpd_streak_current",   "label": "Current DPD Streak Length",          "col": "dpd_string"},
                {"value": "hist_cure_rate",            "label": "Cure Rate (DPD→0 within window)",    "col": "dpd_string"},
                {"value": "hist_relapse_rate",         "label": "Relapse Rate (DPD0→DPD30+ count)",   "col": "dpd_string"},
                {"value": "hist_delinquency_persistence","label": "Delinquency Persistence Index",    "col": "dpd_string"},
            ],
            "credit_line_dynamics": [
                {"value": "hist_credit_limit_avg",         "label": "Avg Credit Limit (History)",        "col": "balance_history"},
                {"value": "hist_credit_limit_change",      "label": "Credit Limit Change (net change)",  "col": "balance_history"},
                {"value": "hist_credit_limit_change_rate", "label": "Credit Limit Change Rate",          "col": "balance_history"},
                {"value": "hist_limit_increase_count",     "label": "Count of Limit Increases",          "col": "balance_history"},
                {"value": "hist_limit_decrease_count",     "label": "Count of Limit Decreases",          "col": "balance_history"},
                {"value": "hist_util_spike_post_increase", "label": "Utilization Spike after Limit Increase","col": "balance_history"},
            ],
            "account_stability_idx": [
                {"value": "hist_balance_cv",           "label": "Balance CV (Std/Mean — Stability)",    "col": "balance_history"},
                {"value": "hist_utilization_std",      "label": "Utilization Std Dev (Consistency)",    "col": "balance_history"},
                {"value": "hist_dpd_variance",         "label": "DPD Variance (Predictability)",        "col": "dpd_string"},
                {"value": "hist_balance_iqr",          "label": "Balance IQR (Spread Without Outliers)","col": "balance_history"},
                {"value": "hist_delinquency_volatility","label": "Delinquency Volatility (DPD CV)",     "col": "dpd_string"},
                {"value": "hist_behavioral_entropy",   "label": "Behavioral Entropy (unpredictability)","col": None},
            ],
            "streak_features": [
                {"value": "hist_max_consec_clean",  "label": "Max Consecutive Clean Months (DPD=0)",  "col": "dpd_string"},
                {"value": "hist_max_consec_dpd30",  "label": "Max Consecutive DPD 30+ Months",        "col": "dpd_string"},
                {"value": "hist_max_consec_dpd90",  "label": "Max Consecutive DPD 90+ Months",        "col": "dpd_string"},
                {"value": "hist_cur_clean_streak",  "label": "Current Clean Streak (months to date)",  "col": "dpd_string"},
                {"value": "hist_cur_delq_streak",   "label": "Current Delinquency Streak (ongoing)",   "col": "dpd_string"},
                {"value": "hist_delq_streak_count", "label": "Count of Delinquency Streak Episodes",  "col": "dpd_string"},
                {"value": "hist_avg_delq_streak_len","label": "Avg Delinquency Streak Length",         "col": "dpd_string"},
                {"value": "hist_streak_ratio",      "label": "Clean/Delinquent Streak Ratio",         "col": "dpd_string"},
            ],
            "behaviour_trend": [
                {"value": "hist_dpd_trend_3v12",     "label": "DPD Trend: 3m vs 12m (core signal)",  "col": "dpd_string"},
                {"value": "hist_dpd_trend_6v24",     "label": "DPD Trend: 6m vs 24m",               "col": "dpd_string"},
                {"value": "hist_overdue_trend_3v12", "label": "Overdue Trend: 3m vs 12m",           "col": "balance_history"},
                {"value": "hist_balance_trend_3v12", "label": "Balance Trend: 3m vs 12m",           "col": "balance_history"},
                {"value": "hist_util_trend_3v12",    "label": "Utilization Trend: 3m vs 12m",       "col": "balance_history"},
                {"value": "hist_missed_trend_3v12",  "label": "Missed Payment Rate Trend: 3m vs 12m","col": "dpd_string"},
                {"value": "hist_beh_direction",      "label": "Behaviour Direction Flag (+1/0/−1)",  "col": None},
            ],
            "cure_behaviour": [
                {"value": "hist_months_to_cure_dpd30", "label": "Months to Cure After DPD 30+ (avg)","col": "dpd_string"},
                {"value": "hist_months_to_cure_dpd60", "label": "Months to Cure After DPD 60+ (avg)","col": "dpd_string"},
                {"value": "hist_months_to_cure_dpd90", "label": "Months to Cure After DPD 90+ (avg)","col": "dpd_string"},
                {"value": "hist_cure_success_rate",    "label": "Cure Success Rate (% events cured)","col": "dpd_string"},
                {"value": "hist_relapse_after_cure",   "label": "Relapse Rate (DPD30+ within 6m)",  "col": "dpd_string"},
                {"value": "hist_persistent_delq_flag", "label": "Persistent Delinquency Flag",       "col": "dpd_string"},
                {"value": "hist_cure_speed_index",     "label": "Cure Speed Index (1/avg cure time)","col": "dpd_string"},
            ],
            "roll_rate": [
                {"value": "hist_roll_clean_to_dpd30", "label": "Roll Rate: Clean → DPD 30+ (0→30)",  "col": "dpd_string"},
                {"value": "hist_roll_dpd30_to_dpd60", "label": "Roll Rate: DPD30→DPD60 (30→60)",     "col": "dpd_string"},
                {"value": "hist_roll_dpd60_to_dpd90", "label": "Roll Rate: DPD60→DPD90 (60→90)",     "col": "dpd_string"},
                {"value": "hist_roll_dpd30_to_clean", "label": "Cure Roll: DPD30→Clean (30→0)",       "col": "dpd_string"},
                {"value": "hist_net_roll_score",       "label": "Net Roll Score (forward−backward)",  "col": "dpd_string"},
                {"value": "hist_forward_roll_count",   "label": "Total Forward Rolls (worsening)",    "col": "dpd_string"},
                {"value": "hist_stay_rate_clean",      "label": "Stay Rate in Clean Bucket (0→0)",    "col": "dpd_string"},
            ],
            "payment_stability": [
                {"value": "hist_payment_irr_idx",      "label": "Payment Irregularity Index (std/avg DPD)",   "col": "dpd_string"},
                {"value": "hist_dpd_cv",               "label": "DPD Coefficient of Variation (std/mean)",   "col": "dpd_string"},
                {"value": "hist_dpd_std_window",       "label": "DPD Std Dev in Window",                     "col": "dpd_string"},
                {"value": "hist_overdue_irr_idx",      "label": "Overdue Irregularity Index",                "col": "balance_history"},
                {"value": "hist_balance_irr_idx",      "label": "Balance Irregularity Index",                "col": "balance_history"},
                {"value": "hist_payment_swing",        "label": "Payment Swing Index (max minus min DPD)",   "col": "dpd_string"},
                {"value": "hist_composite_stab_score", "label": "Composite Stability Score (0=stable, 100=erratic)","col": None},
            ],
        },
        "aggregations_by_subcat": {
            "exposure":              ["sum", "avg", "max", "min", "count", "median", "std", "variance", "cv", "skew", "kurtosis", "iqr", "outlier_count", "percentile"],
            "volume":                ["count", "sum", "ratio", "flag"],
            "delinquency":           ["count", "max", "avg", "ratio", "flag", "median", "std", "variance", "cv", "skew", "kurtosis"],
            "utilization":           ["avg", "max", "min", "median", "std", "cv", "ratio", "flag", "count"],
            "vintage":               ["avg", "min", "max", "value"],
            "recency":               ["value", "min", "max"],
            "trend":                 ["difference", "growth_rate", "ratio", "slope", "acceleration", "volatility", "regression", "classification"],
            "balance_dynamics":      ["max", "min", "avg", "std", "cv", "value", "ratio", "slope"],
            "writeoff":              ["sum", "count", "flag", "avg"],
            "settlement":            ["sum", "count", "flag", "avg"],
            "portfolio_mix":         ["ratio", "index"],
            "risk_ratio":            ["avg", "max", "min", "std", "cv"],
            "transition_matrix":     ["count", "ratio", "flag", "avg"],
            "vintage_cohort":        ["ratio", "count", "avg", "rate"],
            "stability_score":       ["value", "flag"],
            "payment_behaviour":     ["count", "ratio", "max_streak", "avg", "flag", "trend", "velocity"],
            "risk_momentum":         ["velocity", "acceleration", "trend", "slope", "difference", "classification"],
            "delinquency_severity_seq":["value", "count", "max_streak", "ratio", "entropy", "std", "flag"],
            "credit_line_dynamics":  ["avg", "max", "min", "count", "trend", "slope", "velocity", "ratio"],
            "account_stability_idx": ["cv", "std", "variance", "iqr", "entropy", "lag_corr", "value"],
            "streak_features":       ["value", "max", "count", "avg", "ratio"],
            "behaviour_trend":       ["difference", "ratio", "slope", "flag"],
            "cure_behaviour":        ["value", "avg", "min", "max", "count", "ratio", "flag"],
            "roll_rate":             ["ratio", "count", "difference", "value"],
            "payment_stability":     ["value", "cv", "std", "ratio", "entropy"],
        },
        "scope_fields": ["loan_types", "secured", "account_status"],
        "threshold_by_subcat": {
            "exposure": None, "volume": None,
            "delinquency": {"enabled": True, "type": "dpd", "label": "DPD Threshold", "col": "dpd", "operators": [">=", ">", "="], "placeholder": "e.g. 30, 60, 90"},
            "utilization": None, "vintage": None, "recency": None, "trend": None,
            "balance_dynamics": None, "writeoff": None, "settlement": None,
            "portfolio_mix": None, "risk_ratio": None, "transition_matrix": None,
            "vintage_cohort": None, "stability_score": None,
            "payment_behaviour": None, "risk_momentum": None,
            "delinquency_severity_seq": {"enabled": True, "type": "dpd", "label": "DPD Threshold", "col": "dpd", "operators": [">=", ">"], "placeholder": "e.g. 30"},
            "credit_line_dynamics": None, "account_stability_idx": None,
            "streak_features": None, "behaviour_trend": None,
            "cure_behaviour": None, "roll_rate": None, "payment_stability": None,
        },
    },
}


# ─────────────────────────────────────────────────────────────────────
# CASCADE QUERY FUNCTIONS  (used by /builder/cascade endpoint)
# ─────────────────────────────────────────────────────────────────────

def get_types() -> list:
    return [
        {"value": k, "label": v["label"], "abbr": v["abbr"],
         "description": v["description"], "icon": v["icon"]}
        for k, v in CASCADE.items()
    ]

def get_sub_categories(variable_type: str) -> list:
    return CASCADE.get(variable_type, {}).get("sub_categories", [])

def get_measures(variable_type: str, sub_category: str) -> list:
    return CASCADE.get(variable_type, {}).get("measures_by_subcat", {}).get(sub_category, [])

def get_aggregations(variable_type: str, sub_category: str) -> list:
    agg_vals = CASCADE.get(variable_type, {}).get("aggregations_by_subcat", {}).get(sub_category, [])
    labels   = GLOBAL["aggregation_labels"]
    return [{"value": a, "label": labels.get(a, a.title())} for a in agg_vals]

def get_scope_fields(variable_type: str) -> list:
    return CASCADE.get(variable_type, {}).get("scope_fields", [])

def get_threshold_config(variable_type: str, sub_category: str):
    return CASCADE.get(variable_type, {}).get("threshold_by_subcat", {}).get(sub_category)

def get_full_cascade(variable_type: str, sub_category: str) -> dict:
    return {
        "measures":     get_measures(variable_type, sub_category),
        "aggregations": get_aggregations(variable_type, sub_category),
        "scope_fields": get_scope_fields(variable_type),
        "threshold":    get_threshold_config(variable_type, sub_category),
    }


# ─────────────────────────────────────────────────────────────────────
# CONFIG BUILDER  →  translates UI selections → feature_engine config
# ─────────────────────────────────────────────────────────────────────

def build_feature_config(selections: dict) -> dict:
    vtype  = selections.get("variable_type", "")
    subcat = selections.get("sub_category", "")
    cfg = {
        "variable_type": vtype,
        "sub_category":  subcat,
        "measure":       selections.get("measure", ""),
        "aggregation":   selections.get("aggregation", "count"),
        "time_window":   selections.get("time_window", "12m"),
    }
    loan_types     = selections.get("loan_types") or []
    secured        = selections.get("secured", "all")
    account_status = selections.get("account_status") or []
    ownership      = selections.get("ownership", "all")
    dpd_op  = selections.get("dpd_op")
    dpd_val = selections.get("dpd_val")
    amt_op  = selections.get("amount_op")
    amt_val = selections.get("amount_val")

    if vtype == "Enquiry":
        cfg["filters"] = {"product": loan_types, "secured": secured}
        if amt_op and amt_val is not None:
            cfg["amount_op"] = amt_op; cfg["amount_val"] = float(amt_val)
    elif vtype in ("Trade", "Account", "Trade History"):
        scope_key = "trade_scope" if vtype == "Trade" else ("acc_scope" if vtype == "Account" else "trade_scope")
        cfg[scope_key] = {"loanType": loan_types, "secured": secured, "statusList": account_status, "ownership": ownership}
        if dpd_op and dpd_val is not None:
            cfg["dpd_threshold"] = int(dpd_val)
            cfg["conditions"] = {"dpd_op": dpd_op, "dpd_val": int(dpd_val)}
    return cfg


# ─────────────────────────────────────────────────────────────────────
# AUTO-NAME GENERATOR
# ─────────────────────────────────────────────────────────────────────

def generate_feature_name(selections: dict) -> str:
    type_abbr = CASCADE.get(selections.get("variable_type", ""), {}).get("abbr", "feat")
    subcat    = (selections.get("sub_category") or "")[:4].lower().replace(" ", "_")
    agg       = (selections.get("aggregation") or "cnt")[:3]
    window    = (selections.get("time_window") or "12m").replace("m", "")
    measure   = selections.get("measure", "")

    m_map = {
        "current_balance":"cb", "sanction_amount":"sa", "overdue_amount":"od",
        "credit_limit":"cl", "emi_amount":"emi", "writeoff_amount":"wo",
        "dpd":"dpd", "inquiry_amount":"amt", "count":"",
        "months_since_last":"msl", "months_since_oldest":"mso",
        "utilization_ratio":"ur", "account_age":"age",
        "hist_avg_balance":"hab", "hist_max_balance":"hmb",
        "count_dpd30_months":"d30", "count_dpd60_months":"d60",
        "count_dpd90_months":"d90", "max_dpd_in_history":"mdh",
    }
    m_abbr = m_map.get(measure, measure[:3] if measure else "")

    dpd_suffix = ""
    if selections.get("dpd_val"):
        op = (selections.get("dpd_op") or ">=").replace(">=","gte").replace(">","gt").replace("=","eq")
        dpd_suffix = f"_dpd{op}{selections['dpd_val']}"

    parts = [type_abbr, subcat, agg] + ([m_abbr] if m_abbr else [])
    return "_".join(p for p in parts if p) + dpd_suffix + f"_{window}m"

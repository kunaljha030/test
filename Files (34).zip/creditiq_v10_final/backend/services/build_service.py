"""services/build_service.py — build CRUD logic"""
import json
from sqlalchemy.orm import Session
from db import models
from fastapi import HTTPException
from datetime import datetime


def _serialize_build(build: models.Build) -> dict:
    vars_by_type: dict = {}
    for v in build.variables:
        t = v.variable_type or "other"
        vars_by_type.setdefault(t, []).append({
            "name": v.name,
            "variable_type": v.variable_type,
            "sub_category": v.sub_category,
            "measure": v.measure,
            "aggregation": v.aggregation,
            "time_window": v.time_window,
            "product_scope": v.product_scope,
            "secured_scope": v.secured_scope,
            "lender_scope": v.lender_scope,
            "loan_type_scope": v.loan_type_scope,
            "account_status_scope": v.account_status_scope,
            "ownership_scope": v.ownership_scope,
            "config": json.loads(v.config_json or "{}"),
            "source": v.source or "wizard",
            "created_at": v.created_at.isoformat() if v.created_at else None,
        })
    return {
        "id": build.id,
        "name": build.name,
        "owner": build.owner,
        "bureau": build.bureau,
        "file_type": build.file_type,
        "file_identifier": build.file_identifier,
        "description": build.description,
        "created_at": build.created_at.isoformat() if build.created_at else None,
        "updated_at": build.updated_at.isoformat() if build.updated_at else None,
        "variable_count": len(build.variables),
        "variables_by_type": vars_by_type,
    }


def get_builds(db: Session, owner: str):
    builds = db.query(models.Build).filter(models.Build.owner == owner).order_by(models.Build.updated_at.desc()).all()
    return [_serialize_build(b) for b in builds]


def get_build(db: Session, name: str, owner: str):
    b = db.query(models.Build).filter(models.Build.name == name, models.Build.owner == owner).first()
    if not b:
        raise HTTPException(status_code=404, detail=f"Build '{name}' not found")
    return _serialize_build(b)


def create_or_get_build(db: Session, name: str, owner: str, bureau=None, file_type=None, file_identifier=None, description=None):
    build = db.query(models.Build).filter(models.Build.name == name, models.Build.owner == owner).first()
    if not build:
        build = models.Build(name=name, owner=owner, bureau=bureau,
                             file_type=file_type, file_identifier=file_identifier,
                             description=description)
        db.add(build)
    else:
        if bureau is not None: build.bureau = bureau
        if file_type is not None: build.file_type = file_type
        if file_identifier is not None: build.file_identifier = file_identifier
        if description is not None: build.description = description
        build.updated_at = datetime.utcnow()
    db.commit(); db.refresh(build)
    return build


def delete_build(db: Session, name: str, owner: str):
    build = db.query(models.Build).filter(models.Build.name == name, models.Build.owner == owner).first()
    if not build:
        raise HTTPException(status_code=404, detail=f"Build '{name}' not found")
    db.delete(build); db.commit()

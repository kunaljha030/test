"""
services/variable_generator.py
================================
Full Cross-Product Variable Generator — 15,000+ production variables

Architecture:
  Enquiry       ~5,000  (13 sub-cats × measures × aggs × windows × product/secured filters)
  Trade         ~4,200  (15 sub-cats × measures × full stat aggs × windows × product filters)
  Account       ~2,400  (23 sub-cats × measures × aggs × windows × product filters)
  Trade History ~2,800  (26 sub-cats × measures × full stat aggs × windows × product filters)
  Cross Product ~1,200  (7 sub-cats × measures × aggs × window pairs)
  Total:        ~15,600

Mapping:
  Enquiry vars mirror PySpark A_Inq_Feature_1__2_.py exactly:
    - volume:       Inq_Num_inq_{i}m, {prod}_Num_inq_{i}m, unsec_Inq_Num_inq_{i}m
    - amount:       {prod}_max_EnquiryAmount_{i}m, stats on amounts
    - gap:          avg/median/std/cv/skew/kurtosis on num_days_btw_inq
    - threshold:    inq_lt_eq_{amt}_last_{m}m buckets (7 buckets)
    - velocity:     window-to-window count change/ratio/growth
    - product_mix:  Inq_distinct_products_last_{i}m, per-product share
    - secured_split: unsec_Inq_Num_inq_{i}m, secured_ratio
    - burst:        credit_inq_last_1m, distinct_products_30d
"""

from typing import List, Dict, Optional
from itertools import product as iproduct

# ═══════════════════════════════════════════════════════════════════════════════
# GLOBAL DIMENSION TABLES
# ═══════════════════════════════════════════════════════════════════════════════

LOAN_TYPES = [
    "PL", "CC", "HL", "AL", "BL", "GL",
    "OD", "LAP", "LAS", "CD", "TW", "CV", "EL", "CE", "Other"
]

ALL_WINDOWS     = [1, 3, 6, 12, 24, 36]
STD_WINDOWS     = [1, 3, 6, 12]
GAP_WINDOWS     = [3, 6, 12, 24, 36]
LONG_WINDOWS    = [6, 12, 24, 36]
HIST_WINDOWS    = [3, 6, 12, 24, 36, 48]
VELOCITY_PAIRS  = [("1m","3m"), ("3m","6m"), ("6m","12m"), ("3m","12m"), ("12m","24m")]

# Full stat aggregation set (matches PySpark inq_agg_exp)
STAT_AGGS  = ["count", "sum", "avg", "max", "min", "median",
              "std", "variance", "cv", "skew", "kurtosis", "percentile"]
DIST_AGGS  = ["avg", "median", "max", "min", "std", "variance",
              "cv", "skew", "kurtosis", "percentile", "iqr"]
BOOL_AGGS  = ["count", "flag", "ratio"]
RATIO_AGGS = ["ratio", "index", "count"]
VAL_AGGS   = ["value", "min", "max"]

# Amount buckets — mirrors PySpark inq_lt_eq_{amt}_last_{m}m
AMOUNT_BUCKETS = [
    ("0_1k",      0,         1_000),
    ("1k_10k",    1_000,     10_000),
    ("10k_50k",   10_000,    50_000),
    ("50k_1L",    50_000,    100_000),
    ("1L_5L",     100_000,   500_000),
    ("5L_10L",    500_000,   1_000_000),
    ("above_10L", 1_000_000, None),
]


def _name(*parts) -> str:
    """Build clean snake_case variable name."""
    return "_".join(str(p).lower().replace(" ", "_").replace("-", "_")
                    for p in parts if p not in (None, "", "all"))


def _cfg(variable_type: str, sub_category: str, measure: str,
         aggregation: str, time_window: str, **kwargs) -> dict:
    """Build config dict for one variable."""
    c = {
        "variable_type": variable_type,
        "sub_category":  sub_category,
        "measure":       measure,
        "aggregation":   aggregation,
        "time_window":   time_window,
        "loan_types":    kwargs.get("loan_types", []),
        "secured":       kwargs.get("secured", "all"),
    }
    for k, v in kwargs.items():
        if k not in ("loan_types", "secured"):
            c[k] = v
    return c


# ═══════════════════════════════════════════════════════════════════════════════
# ENQUIRY VARIABLES  (~5,000)
# ═══════════════════════════════════════════════════════════════════════════════

def _gen_enquiry() -> List[Dict]:
    v = []

    # ── VOLUME ──────────────────────────────────────────────────────────────
    # Mirrors: Inq_Num_inq_{i}m, {prod}_Num_inq_{i}m, unsec_Inq_Num_inq_{i}m
    for w in ALL_WINDOWS:
        wstr = f"{w}m"
        for agg in BOOL_AGGS:
            # all-product base
            n = _name("enq", "vol", agg, wstr)
            v.append({**_cfg("Enquiry","volume","count",agg,wstr), "name": n})
            # per-product
            for lt in LOAN_TYPES:
                n = _name("enq", "vol", lt, agg, wstr)
                v.append({**_cfg("Enquiry","volume","count",agg,wstr,loan_types=[lt]), "name": n})
            # secured / unsecured
            for sec in ["secured", "unsecured"]:
                n = _name("enq", "vol", sec, agg, wstr)
                v.append({**_cfg("Enquiry","volume","count",agg,wstr,secured=sec), "name": n})
            # per-product × secured
            for lt in ["PL","CC","HL","BL","AL"]:   # top 5 for cross
                for sec in ["secured","unsecured"]:
                    n = _name("enq","vol",lt,sec,agg,wstr)
                    v.append({**_cfg("Enquiry","volume","count",agg,wstr,
                                     loan_types=[lt],secured=sec), "name": n})

    # ── AMOUNT ──────────────────────────────────────────────────────────────
    # Mirrors: max_EnquiryAmount_{i}m, {prod}_max_EnquiryAmount_{i}m, stats
    for w in ALL_WINDOWS:
        wstr = f"{w}m"
        for agg in STAT_AGGS:
            # all-product base
            n = _name("enq","amt",agg,wstr)
            v.append({**_cfg("Enquiry","amount","inquiry_amount",agg,wstr), "name": n})
            # per-product
            for lt in LOAN_TYPES:
                n = _name("enq","amt",lt,agg,wstr)
                v.append({**_cfg("Enquiry","amount","inquiry_amount",agg,wstr,
                                  loan_types=[lt]), "name": n})
            # secured / unsecured
            for sec in ["secured","unsecured"]:
                n = _name("enq","amt",sec,agg,wstr)
                v.append({**_cfg("Enquiry","amount","inquiry_amount",agg,wstr,
                                  secured=sec), "name": n})

    # ── GAP ─────────────────────────────────────────────────────────────────
    # Mirrors: avg/median/std/cv/skew/kurtosis on num_days_btw_inq_{i}m
    for w in GAP_WINDOWS:
        wstr = f"{w}m"
        for agg in DIST_AGGS:
            # all base
            n = _name("enq","gap",agg,wstr)
            v.append({**_cfg("Enquiry","gap","days_between",agg,wstr), "name": n})
            # per-product
            for lt in LOAN_TYPES:
                n = _name("enq","gap",lt,agg,wstr)
                v.append({**_cfg("Enquiry","gap","days_between",agg,wstr,
                                  loan_types=[lt]), "name": n})
            # secured/unsecured
            for sec in ["secured","unsecured"]:
                n = _name("enq","gap",sec,agg,wstr)
                v.append({**_cfg("Enquiry","gap","days_between",agg,wstr,
                                  secured=sec), "name": n})

    # ── RECENCY ─────────────────────────────────────────────────────────────
    # Mirrors: Inq_Month_since_latest_inq, {prod}_inq_latest
    for measure, mshort in [("months_since_last","msl"),("months_since_oldest","mso")]:
        # all base
        n = _name("enq","rec",mshort)
        v.append({**_cfg("Enquiry","recency",measure,"value","0m"), "name": n})
        # per-product
        for lt in LOAN_TYPES:
            n = _name("enq","rec",lt,mshort)
            v.append({**_cfg("Enquiry","recency",measure,"value","0m",
                              loan_types=[lt]), "name": n})
        # secured/unsecured
        for sec in ["secured","unsecured"]:
            n = _name("enq","rec",sec,mshort)
            v.append({**_cfg("Enquiry","recency",measure,"value","0m",
                              secured=sec), "name": n})

    # ── CONCENTRATION ───────────────────────────────────────────────────────
    # Mirrors: Inq_distinct_products_last_{i}m
    for w in [3,6,12,24]:
        wstr = f"{w}m"
        for measure, mshort in [("distinct_lenders","dlnd"),
                                  ("top_lender_share","tls"),
                                  ("hhi_index","hhi")]:
            for agg in RATIO_AGGS:
                n = _name("enq","con",mshort,agg,wstr)
                v.append({**_cfg("Enquiry","concentration",measure,agg,wstr), "name": n})
            # per-product variant
            for lt in LOAN_TYPES:
                n = _name("enq","con",lt,mshort,wstr)
                v.append({**_cfg("Enquiry","concentration",measure,"count",wstr,
                                  loan_types=[lt]), "name": n})

    # ── VELOCITY ────────────────────────────────────────────────────────────
    # Mirrors: window-to-window comparisons
    for w1, w2 in VELOCITY_PAIRS:
        pair = f"{w1}_{w2}"
        for measure, mshort in [("count_change","chg"),("count_ratio","rat"),
                                  ("growth_rate","grw"),("slope","slp")]:
            for agg in ["difference","ratio","growth_rate","slope"]:
                n = _name("enq","vel",mshort,agg,pair)
                v.append({**_cfg("Enquiry","velocity",measure,agg,w2,
                                  prior_window=w1), "name": n})
            # per-product
            for lt in LOAN_TYPES:
                n = _name("enq","vel",lt,mshort,pair)
                v.append({**_cfg("Enquiry","velocity",measure,"difference",w2,
                                  loan_types=[lt],prior_window=w1), "name": n})
            # secured/unsecured
            for sec in ["secured","unsecured"]:
                n = _name("enq","vel",sec,mshort,pair)
                v.append({**_cfg("Enquiry","velocity",measure,"difference",w2,
                                  secured=sec,prior_window=w1), "name": n})

    # ── MIX ─────────────────────────────────────────────────────────────────
    for w in [3,6,12,24]:
        wstr = f"{w}m"
        for measure, mshort in [("secured_unsecured_ratio","sur"),
                                  ("secured_ratio","sr"),
                                  ("unsecured_ratio","ur")]:
            n = _name("enq","mix",mshort,wstr)
            v.append({**_cfg("Enquiry","mix",measure,"ratio",wstr), "name": n})
        # per-product
        for lt in LOAN_TYPES:
            n = _name("enq","mix",lt,wstr)
            v.append({**_cfg("Enquiry","mix","secured_unsecured_ratio","ratio",wstr,
                              loan_types=[lt]), "name": n})

    # ── THRESHOLD / AMOUNT BUCKETS ───────────────────────────────────────────
    # Mirrors: inq_lt_eq_{amt}_last_{m}m, {prod}_inq_lt_eq_{amt}_last_{m}m
    for bname, blo, bhi in AMOUNT_BUCKETS:
        for w in STD_WINDOWS:
            wstr = f"{w}m"
            for agg in BOOL_AGGS:
                # all base
                n = _name("enq","bkt",bname,agg,wstr)
                cfg = _cfg("Enquiry","amount_bucket",f"bucket_{bname}",agg,wstr,
                           amount_lo=blo, amount_hi=bhi)
                v.append({**cfg, "name": n})
                # per-product
                for lt in LOAN_TYPES:
                    n = _name("enq","bkt",lt,bname,agg,wstr)
                    cfg = _cfg("Enquiry","amount_bucket",f"bucket_{bname}",agg,wstr,
                               loan_types=[lt], amount_lo=blo, amount_hi=bhi)
                    v.append({**cfg, "name": n})
                # secured/unsecured
                for sec in ["secured","unsecured"]:
                    n = _name("enq","bkt",sec,bname,agg,wstr)
                    cfg = _cfg("Enquiry","amount_bucket",f"bucket_{bname}",agg,wstr,
                               secured=sec, amount_lo=blo, amount_hi=bhi)
                    v.append({**cfg, "name": n})

    # ── DISTRIBUTION ────────────────────────────────────────────────────────
    for measure, mshort in [("amount_distribution","adist"),("gap_distribution","gdist")]:
        for w in LONG_WINDOWS:
            wstr = f"{w}m"
            for agg in DIST_AGGS:
                n = _name("enq","dist",mshort,agg,wstr)
                v.append({**_cfg("Enquiry","distribution",measure,agg,wstr), "name": n})
                for lt in LOAN_TYPES:
                    n = _name("enq","dist",lt,mshort,agg,wstr)
                    v.append({**_cfg("Enquiry","distribution",measure,agg,wstr,
                                      loan_types=[lt]), "name": n})

    # ── PRODUCT MIX ─────────────────────────────────────────────────────────
    # Mirrors: Inq_distinct_products_last_{i}m, per-product share
    prod_mix_measures = [
        ("distinct_product_types","dptype"),
        ("product_type_hhi","phhi"),
        ("top_product_share","tpsh"),
        ("pl_inq_share","plsh"),
        ("cc_inq_share","ccsh"),
        ("hl_inq_share","hlsh"),
        ("bl_inq_share","blsh"),
    ]
    for measure, mshort in prod_mix_measures:
        for w in ALL_WINDOWS:
            wstr = f"{w}m"
            for agg in RATIO_AGGS:
                n = _name("enq","pmx",mshort,agg,wstr)
                v.append({**_cfg("Enquiry","product_mix",measure,agg,wstr), "name": n})

    # ── SECURED SPLIT ────────────────────────────────────────────────────────
    sec_split_measures = [
        ("secured_count","seccnt"),
        ("unsecured_count","unseccnt"),
        ("secured_ratio","secrat"),
        ("unsecured_ratio","unsecrat"),
        ("secured_amt_share","secamt"),
        ("unsecured_amt_share","unsecamt"),
    ]
    for measure, mshort in sec_split_measures:
        for w in STD_WINDOWS:
            wstr = f"{w}m"
            for agg in BOOL_AGGS:
                n = _name("enq","spl",mshort,agg,wstr)
                v.append({**_cfg("Enquiry","secured_split",measure,agg,wstr), "name": n})
            # per-product
            for lt in LOAN_TYPES:
                n = _name("enq","spl",lt,mshort,wstr)
                v.append({**_cfg("Enquiry","secured_split",measure,"count",wstr,
                                  loan_types=[lt]), "name": n})

    # ── BURST ────────────────────────────────────────────────────────────────
    # Mirrors: credit_inq_last_1m (cv_var_g502s), distinct_products_30d
    burst_measures = [
        ("inq_last_30d","i30d"),
        ("inq_last_7d","i7d"),
        ("distinct_products_30d","dp30d"),
        ("burst_flag_3inq_30d","bf3"),
        ("burst_flag_5inq_30d","bf5"),
        ("max_inq_single_day","maxd"),
        ("avg_inq_per_week","avgw"),
    ]
    for measure, mshort in burst_measures:
        for w in [1, 3]:
            wstr = f"{w}m"
            for agg in BOOL_AGGS:
                n = _name("enq","bst",mshort,agg,wstr)
                v.append({**_cfg("Enquiry","burst",measure,agg,wstr), "name": n})
            # per-product
            for lt in LOAN_TYPES:
                n = _name("enq","bst",lt,mshort,wstr)
                v.append({**_cfg("Enquiry","burst",measure,"count",wstr,
                                  loan_types=[lt]), "name": n})
            # secured/unsecured
            for sec in ["secured","unsecured"]:
                n = _name("enq","bst",sec,mshort,wstr)
                v.append({**_cfg("Enquiry","burst",measure,"count",wstr,
                                  secured=sec), "name": n})

    # Deduplicate by name
    seen = set(); out = []
    for item in v:
        if item["name"] not in seen:
            seen.add(item["name"]); out.append(item)
    return out


# ═══════════════════════════════════════════════════════════════════════════════
# TRADE VARIABLES  (~4,200)
# ═══════════════════════════════════════════════════════════════════════════════

TRADE_SUBCATS = {
    "exposure":     {
        "measures": ["current_balance","sanction_amount","overdue_amount",
                     "emi_amount","credit_limit","writeoff_amount","settlement_amount"],
        "aggs":     STAT_AGGS,
        "windows":  ALL_WINDOWS,
        "with_prod": True, "with_sec": True,
    },
    "volume":       {
        "measures": ["active_count","closed_count","total_count",
                     "writeoff_count","settled_count"],
        "aggs":     ["count","sum","ratio","flag"],
        "windows":  ALL_WINDOWS,
        "with_prod": True, "with_sec": True,
    },
    "delinquency":  {
        "measures": ["dpd","overdue_amount","dpd_30","dpd_60","dpd_90","delinquent_flag"],
        "aggs":     STAT_AGGS,
        "windows":  STD_WINDOWS,
        "with_prod": True, "with_sec": True,
    },
    "utilization":  {
        "measures": ["utilization_ratio","high_util_flag","avg_utilization","max_utilization"],
        "aggs":     DIST_AGGS,
        "windows":  STD_WINDOWS,
        "with_prod": True, "with_sec": False,
    },
    "vintage":      {
        "measures": ["account_age","months_since_oldest","months_since_newest","months_since_first_delq"],
        "aggs":     VAL_AGGS + ["avg"],
        "windows":  [0],  # point-in-time
        "with_prod": True, "with_sec": False,
    },
    "recency":      {
        "measures": ["months_since_last_dpd30","months_since_last_dpd60",
                     "months_since_last_dpd90","months_since_last_writeoff",
                     "months_since_last_settled","months_since_last_npa",
                     "months_since_peak_exposure"],
        "aggs":     VAL_AGGS,
        "windows":  [0],
        "with_prod": True, "with_sec": False,
    },
    "trend":        {
        "measures": ["balance_growth","utilization_change","dpd_trend",
                     "overdue_trend","account_count_trend","emi_trend"],
        "aggs":     ["difference","growth_rate","ratio","slope","acceleration","volatility"],
        "windows":  [3,6,12],
        "with_prod": True, "with_sec": False,
    },
    "balance_dynamics": {
        "measures": ["outstanding_balance","peak_balance","trough_balance",
                     "avg_monthly_balance","balance_volatility","time_weighted_balance"],
        "aggs":     DIST_AGGS,
        "windows":  STD_WINDOWS,
        "with_prod": True, "with_sec": False,
    },
    "writeoff":     {
        "measures": ["writeoff_amount","writeoff_count"],
        "aggs":     ["sum","count","flag","avg","max"],
        "windows":  LONG_WINDOWS,
        "with_prod": True, "with_sec": False,
    },
    "settlement":   {
        "measures": ["settlement_amount","settlement_count"],
        "aggs":     ["sum","count","flag","avg"],
        "windows":  LONG_WINDOWS,
        "with_prod": True, "with_sec": False,
    },
    "portfolio_mix":{
        "measures": ["pl_share","unsecured_share","secured_share",
                     "cc_share","closed_to_open_ratio","loan_type_hhi"],
        "aggs":     RATIO_AGGS,
        "windows":  STD_WINDOWS,
        "with_prod": False, "with_sec": False,
    },
    "risk_ratio":   {
        "measures": ["foir","lvr","db_ratio","delinquent_ratio","high_utilization_ratio"],
        "aggs":     ["avg","max","min","ratio"],
        "windows":  STD_WINDOWS,
        "with_prod": True, "with_sec": False,
    },
    "transition_matrix": {
        "measures": ["dpd_to_dpd0","dpd0_to_dpd30","dpd30_to_dpd90",
                     "active_to_npa","upgrade_count","downgrade_count","net_transition"],
        "aggs":     ["count","ratio","flag","avg"],
        "windows":  [3,6,12],
        "with_prod": True, "with_sec": False,
    },
    "vintage_cohort": {
        "measures": ["mob_bucket","vintage_dpd_rate","vintage_npa_rate",
                     "cumulative_default","early_delinquency"],
        "aggs":     ["ratio","count","avg"],
        "windows":  [6,12,24],
        "with_prod": True, "with_sec": False,
    },
    "stability_score": {
        "measures": ["psi_score","rank_correlation","gini_stability","feature_drift"],
        "aggs":     ["value","flag"],
        "windows":  [6,12],
        "with_prod": False, "with_sec": False,
    },
}


def _gen_trade() -> List[Dict]:
    v = []; seen = set()
    for sc, cfg in TRADE_SUBCATS.items():
        wins = cfg["windows"] if cfg["windows"] != [0] else ["0m"]
        for measure in cfg["measures"]:
            for w in (cfg["windows"] if cfg["windows"] != [0] else [0]):
                wstr = "0m" if w == 0 else f"{w}m"
                for agg in cfg["aggs"]:
                    # base
                    n = _name("trd",sc,measure,agg,wstr)
                    if n not in seen:
                        seen.add(n)
                        v.append({**_cfg("Trade",sc,measure,agg,wstr), "name": n})
                    # per-product
                    if cfg["with_prod"]:
                        for lt in LOAN_TYPES:
                            n = _name("trd",sc,lt,measure,agg,wstr)
                            if n not in seen:
                                seen.add(n)
                                v.append({**_cfg("Trade",sc,measure,agg,wstr,
                                                  loan_types=[lt]), "name": n})
                    # secured/unsecured
                    if cfg["with_sec"]:
                        for sec in ["secured","unsecured"]:
                            n = _name("trd",sc,sec,measure,agg,wstr)
                            if n not in seen:
                                seen.add(n)
                                v.append({**_cfg("Trade",sc,measure,agg,wstr,
                                                  secured=sec), "name": n})
    return v


# ═══════════════════════════════════════════════════════════════════════════════
# ACCOUNT VARIABLES  (~2,400)
# ═══════════════════════════════════════════════════════════════════════════════

ACCOUNT_SUBCATS = {
    "portfolio_count":    {"measures":["total_accounts","active_accounts","closed_accounts","npa_accounts","delinquent_accounts"],   "aggs":["count","ratio","flag"], "windows":STD_WINDOWS,  "with_prod":True,  "with_sec":True},
    "portfolio_exposure": {"measures":["total_outstanding","total_sanctioned","total_overdue","total_emi","avg_balance","max_balance"],"aggs":STAT_AGGS[:8], "windows":STD_WINDOWS, "with_prod":True,  "with_sec":True},
    "credit_age":         {"measures":["age_oldest","age_newest","credit_history_len","avg_account_age"],                             "aggs":["value","min","max","avg"],"windows":[0],    "with_prod":False, "with_sec":False},
    "delinquency_profile":{"measures":["current_dpd","max_dpd_ever","count_dpd30","count_dpd60","count_dpd90","ever_npa_flag"],       "aggs":["count","max","avg","flag","ratio"],"windows":STD_WINDOWS,"with_prod":True,"with_sec":False},
    "utilization_profile":{"measures":["cc_utilization","avg_util_all_cards","max_util_single_card","high_util_count"],               "aggs":DIST_AGGS,     "windows":STD_WINDOWS, "with_prod":False, "with_sec":False},
    "account_flags":      {"measures":["has_npa","has_writeoff","has_overdue","has_dpd30","has_dpd90","has_any_stress"],              "aggs":["flag"],      "windows":STD_WINDOWS, "with_prod":True,  "with_sec":False},
    "derived_ratios":     {"measures":["foir","active_account_ratio","delinquent_ratio","npa_ratio","overdue_to_outstanding"],        "aggs":["ratio","avg","max"],"windows":[0],   "with_prod":False, "with_sec":False},
    "behavioral":         {"measures":["ever_90dpd","months_since_last_delq","payment_consistency","balance_paydown_rate"],           "aggs":["flag","count","avg","ratio"],"windows":STD_WINDOWS,"with_prod":True,"with_sec":False},
    "vintage":            {"measures":["avg_account_age","oldest_account_age","new_accounts_last_6m","weighted_avg_age"],             "aggs":["avg","max","min","count"],"windows":LONG_WINDOWS,"with_prod":True,"with_sec":False},
    "utilization":        {"measures":["acc_credit_utilization","credit_utilization_ratio","max_util_single_account","util_above_80_count"],"aggs":DIST_AGGS,"windows":STD_WINDOWS,"with_prod":False,"with_sec":False},
    "product_mix":        {"measures":["product_mix_score","unique_product_count","product_hhi","secured_product_share","revolving_product_share"],"aggs":["ratio","count","index"],"windows":[0],"with_prod":False,"with_sec":False},
    "lifecycle":          {"measures":["new_accounts_opened","accounts_closed_period","net_account_change","new_to_total_ratio"],     "aggs":["count","sum","ratio"],"windows":STD_WINDOWS,"with_prod":True,"with_sec":False},
    "delinquency_severity":{"measures":["dpd_90plus_accounts","dpd_60plus_accounts","dpd_severity_index","max_dpd_across_accounts","severe_delinquency_ratio"],"aggs":["count","ratio","max","avg","flag"],"windows":STD_WINDOWS,"with_prod":True,"with_sec":False},
    "concentration":      {"measures":["top_lender_exposure_ratio","lender_concentration_index","loan_type_concentration"],          "aggs":["ratio","index","count"],"windows":[0],"with_prod":False,"with_sec":False},
    "payment_behavior":   {"measures":["on_time_payment_ratio","missed_payment_count","consecutive_clean_months","ever_missed_12m"],  "aggs":["ratio","count","avg","flag","slope"],"windows":STD_WINDOWS,"with_prod":True,"with_sec":False},
    "credit_mix":         {"measures":["credit_mix_score","secured_to_unsecured_ratio","loan_type_diversity","revolving_to_installment"],"aggs":["ratio","index","count","flag"],"windows":[0],"with_prod":False,"with_sec":False},
}


def _gen_account() -> List[Dict]:
    v = []; seen = set()
    for sc, cfg in ACCOUNT_SUBCATS.items():
        for measure in cfg["measures"]:
            for w in cfg["windows"]:
                wstr = "0m" if w == 0 else f"{w}m"
                for agg in cfg["aggs"]:
                    n = _name("acc",sc,measure,agg,wstr)
                    if n not in seen:
                        seen.add(n)
                        v.append({**_cfg("Account",sc,measure,agg,wstr), "name": n})
                    if cfg["with_prod"]:
                        for lt in LOAN_TYPES:
                            n = _name("acc",sc,lt,measure,agg,wstr)
                            if n not in seen:
                                seen.add(n)
                                v.append({**_cfg("Account",sc,measure,agg,wstr,
                                                  loan_types=[lt]), "name": n})
                    if cfg["with_sec"]:
                        for sec in ["secured","unsecured"]:
                            n = _name("acc",sc,sec,measure,agg,wstr)
                            if n not in seen:
                                seen.add(n)
                                v.append({**_cfg("Account",sc,measure,agg,wstr,
                                                  secured=sec), "name": n})
    return v


# ═══════════════════════════════════════════════════════════════════════════════
# TRADE HISTORY VARIABLES  (~2,800)
# ═══════════════════════════════════════════════════════════════════════════════

TH_SUBCATS = {
    "delinquency":        {"measures":["max_dpd_in_history","count_dpd30_months","count_dpd60_months","count_dpd90_months","avg_dpd_history","ever_dpd90_flag"],"aggs":STAT_AGGS,"windows":HIST_WINDOWS,"with_prod":True},
    "exposure":           {"measures":["hist_avg_balance","hist_max_balance","hist_avg_overdue","hist_avg_emi"],"aggs":STAT_AGGS,"windows":HIST_WINDOWS,"with_prod":True},
    "volume":             {"measures":["months_with_dpd","total_history_months","months_ever_delinquent"],"aggs":["count","sum","ratio","flag"],"windows":HIST_WINDOWS,"with_prod":True},
    "payment_behaviour":  {"measures":["hist_on_time_payment_ratio","hist_missed_payment_count","hist_max_consecutive_on_time","hist_max_consecutive_missed","hist_payment_regularity_score"],"aggs":["count","ratio","avg","flag","slope","velocity"],"windows":HIST_WINDOWS,"with_prod":True},
    "risk_momentum":      {"measures":["hist_dpd_velocity","hist_dpd_acceleration","hist_overdue_velocity","hist_balance_velocity","hist_risk_momentum_score"],"aggs":["velocity","acceleration","trend","slope","difference"],"windows":[3,6,12,24],"with_prod":True},
    "streak_features":    {"measures":["hist_max_consec_clean","hist_max_consec_dpd30","hist_max_consec_dpd90","hist_cur_clean_streak","hist_cur_delq_streak","hist_delq_streak_count"],"aggs":["value","max","count","avg","ratio"],"windows":HIST_WINDOWS,"with_prod":True},
    "behaviour_trend":    {"measures":["hist_dpd_trend_3v12","hist_dpd_trend_6v24","hist_overdue_trend_3v12","hist_balance_trend_3v12","hist_util_trend_3v12"],"aggs":["difference","ratio","slope","flag"],"windows":[12,24],"with_prod":True},
    "cure_behaviour":     {"measures":["hist_months_to_cure_dpd30","hist_months_to_cure_dpd60","hist_cure_success_rate","hist_relapse_after_cure","hist_cure_speed_index"],"aggs":["value","avg","min","max","count","ratio","flag"],"windows":[12,24,36],"with_prod":True},
    "roll_rate":          {"measures":["hist_roll_clean_to_dpd30","hist_roll_dpd30_to_dpd60","hist_roll_dpd30_to_clean","hist_net_roll_score","hist_forward_roll_count"],"aggs":["ratio","count","difference","value"],"windows":[6,12,24],"with_prod":True},
    "balance_dynamics":   {"measures":["hist_outstanding_balance","hist_peak_balance","hist_avg_monthly_balance","hist_balance_volatility","hist_balance_cv"],"aggs":DIST_AGGS,"windows":[6,12,24],"with_prod":True},
    "delinquency_severity_seq": {"measures":["hist_dpd_severity_score","hist_max_dpd_streak","hist_dpd_streak_current","hist_cure_rate","hist_relapse_rate"],"aggs":["value","count","ratio","std","flag"],"windows":[6,12,24],"with_prod":True},
    "account_stability_idx":    {"measures":["hist_balance_cv","hist_utilization_std","hist_dpd_variance","hist_balance_iqr","hist_behavioral_entropy"],"aggs":["cv","std","variance","iqr","value"],"windows":[6,12,24],"with_prod":False},
    "payment_stability":  {"measures":["hist_dpd_cv","hist_dpd_std_window","hist_payment_swing","hist_composite_stab_score"],"aggs":["value","cv","std","ratio"],"windows":[6,12,24],"with_prod":False},
}


def _gen_trade_history() -> List[Dict]:
    v = []; seen = set()
    for sc, cfg in TH_SUBCATS.items():
        for measure in cfg["measures"]:
            for w in cfg["windows"]:
                wstr = f"{w}m"
                for agg in cfg["aggs"]:
                    n = _name("th",sc,measure,agg,wstr)
                    if n not in seen:
                        seen.add(n)
                        v.append({**_cfg("Trade History",sc,measure,agg,wstr), "name": n})
                    if cfg["with_prod"]:
                        for lt in LOAN_TYPES:
                            n = _name("th",sc,lt,measure,agg,wstr)
                            if n not in seen:
                                seen.add(n)
                                v.append({**_cfg("Trade History",sc,measure,agg,wstr,
                                                  loan_types=[lt]), "name": n})
    return v


# ═══════════════════════════════════════════════════════════════════════════════
# CROSS PRODUCT VARIABLES  (~1,200)
# ═══════════════════════════════════════════════════════════════════════════════

def _gen_cross_product() -> List[Dict]:
    v = []; seen = set()

    # ── Enquiry vs Trade Volume ──────────────────────────────────────────────
    for w in [3,6,12,24]:
        wstr = f"{w}m"
        for measure in ["enq_per_active_trade","trade_per_enquiry","inq_to_account_ratio","inq_count_per_active_lender"]:
            for agg in ["count","ratio","avg","flag"]:
                n = _name("cxp","env",measure,agg,wstr)
                if n not in seen:
                    seen.add(n); v.append({**_cfg("Cross Product","enquiry_vs_trade",measure,agg,wstr),"name":n})
        # per-product
        for lt in LOAN_TYPES:
            n = _name("cxp","env",lt,"ratio",wstr)
            if n not in seen:
                seen.add(n); v.append({**_cfg("Cross Product","enquiry_vs_trade","inq_to_account_ratio","ratio",wstr,loan_types=[lt]),"name":n})

    # ── Amount Comparison ────────────────────────────────────────────────────
    for w in [6,12,24]:
        wstr = f"{w}m"
        for measure in ["max_inq_vs_max_trade","avg_inq_vs_avg_trade","total_inq_exposure","exposure_increase_ratio"]:
            for agg in STAT_AGGS[:8]:
                n = _name("cxp","amtcmp",measure,agg,wstr)
                if n not in seen:
                    seen.add(n); v.append({**_cfg("Cross Product","amount_comparison",measure,agg,wstr),"name":n})

    # ── Concentration Comparison ─────────────────────────────────────────────
    for w in [6,12]:
        wstr = f"{w}m"
        for measure in ["hhi_ratio","enquiry_hhi","trade_hhi","distinct_inq_lenders","distinct_trade_lenders"]:
            for agg in RATIO_AGGS + ["avg","max"]:
                n = _name("cxp","con",measure,agg,wstr)
                if n not in seen:
                    seen.add(n); v.append({**_cfg("Cross Product","concentration_comparison",measure,agg,wstr),"name":n})

    # ── Product Mix Overlap ──────────────────────────────────────────────────
    for w in [6,12,24]:
        wstr = f"{w}m"
        for measure in ["common_product_count","inq_only_products","trade_only_products","product_overlap_ratio"]:
            for agg in ["count","ratio","flag","index"]:
                n = _name("cxp","pmov",measure,agg,wstr)
                if n not in seen:
                    seen.add(n); v.append({**_cfg("Cross Product","product_mix_overlap",measure,agg,wstr),"name":n})

    # ── Per-Loan-Type Ratios ─────────────────────────────────────────────────
    for lt in LOAN_TYPES:
        for w in [3,6,12]:
            wstr = f"{w}m"
            for measure in ["inq_per_trade","new_inq_no_trade","inq_count"]:
                for agg in ["ratio","count","flag"]:
                    n = _name("cxp","ltr",lt,measure,agg,wstr)
                    if n not in seen:
                        seen.add(n); v.append({**_cfg("Cross Product","loan_type_ratios",measure,agg,wstr,loan_types=[lt]),"name":n})

    # ── Utilization vs Enquiries ─────────────────────────────────────────────
    for w in [3,6,12]:
        wstr = f"{w}m"
        for measure in ["avg_util_with_recent_inq","high_util_high_inq","high_util_low_inq","leverage_ratio"]:
            for agg in ["flag","ratio","avg","count"]:
                n = _name("cxp","utenq",measure,agg,wstr)
                if n not in seen:
                    seen.add(n); v.append({**_cfg("Cross Product","util_vs_enquiries",measure,agg,wstr),"name":n})

    # ── Cross-Product Risk Scores ────────────────────────────────────────────
    for w in [6,12,24]:
        wstr = f"{w}m"
        for measure in ["delinquency_vs_inq","exposure_growth_vs_inq","stress_signal_composite","credit_hunger_index"]:
            for agg in STAT_AGGS[:8]:
                n = _name("cxp","risk",measure,agg,wstr)
                if n not in seen:
                    seen.add(n); v.append({**_cfg("Cross Product","cross_risk",measure,agg,wstr),"name":n})

    return v


# ═══════════════════════════════════════════════════════════════════════════════
# MASTER GENERATOR
# ═══════════════════════════════════════════════════════════════════════════════

def generate_all_variables() -> list:
    """Generate full variable library. Returns deduplicated list."""
    all_vars = []
    all_vars.extend(_gen_enquiry())
    all_vars.extend(_gen_trade())
    all_vars.extend(_gen_account())
    all_vars.extend(_gen_trade_history())
    all_vars.extend(_gen_cross_product())

    # Global dedup by name
    seen = set(); out = []
    for item in all_vars:
        if item["name"] not in seen:
            seen.add(item["name"]); out.append(item)
    return out


def estimate_variable_count() -> int:
    return len(generate_all_variables())


def get_variables_by_type(variable_type: str) -> list:
    return [v for v in generate_all_variables()
            if v.get("variable_type","").lower() == variable_type.lower()]


def get_variables_by_subcat(variable_type: str, sub_category: str) -> list:
    return [v for v in generate_all_variables()
            if v.get("variable_type","").lower() == variable_type.lower()
            and v.get("sub_category","").lower() == sub_category.lower()]


if __name__ == "__main__":
    from collections import Counter
    all_v = generate_all_variables()
    by_type = Counter(v["variable_type"] for v in all_v)
    print(f"\nTotal: {len(all_v):,}")
    print("\nBy Type:")
    for t, c in sorted(by_type.items(), key=lambda x: -x[1]):
        print(f"  {t:<25} {c:>6,}")
    dupes = len(all_v) - len(set(v["name"] for v in all_v))
    print(f"\nDuplicates: {dupes}")

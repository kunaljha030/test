"""
bureau/normalizer.py
Normalization Layer (Step 3 in the 4-Bureau Workflow Diagram)

Maps bureau-specific parsed data → canonical normalized tables:
  - normalized_applicant
  - normalized_accounts
  - normalized_inquiries
"""
from sqlalchemy.orm import Session
from db import models


def normalize_and_store(db: Session, run: models.ExecutionRun, parsed: dict):
    """
    Takes the parsed dict {applicant, accounts, inquiries} from any bureau parser
    and writes normalized rows to the DB.
    """
    customer_id = _resolve_customer_id(parsed, run)

    # ── Applicant ─────────────────────────────────────────────────────
    appl = parsed.get("applicant", {})
    if appl:
        db.add(models.NormalizedApplicant(
            run_id=run.id,
            customer_id=customer_id,
            full_name=appl.get("full_name") or "",
            date_of_birth=appl.get("date_of_birth"),
            pan=appl.get("pan"),
            mobile=appl.get("mobile"),
            bureau_source=run.bureau,
        ))

    # ── Accounts ──────────────────────────────────────────────────────
    for acct in parsed.get("accounts", []):
        db.add(models.NormalizedAccount(
            run_id=run.id,
            customer_id=acct.get("customer_id") or customer_id,
            account_number=acct.get("account_number"),
            lender_name=acct.get("lender_name"),
            loan_type=acct.get("loan_type"),
            account_status=_normalize_status(acct.get("account_status")),
            ownership_type=acct.get("ownership_type"),
            sanction_amount=acct.get("sanction_amount"),
            current_balance=acct.get("current_balance"),
            overdue_amount=acct.get("overdue_amount"),
            emi_amount=acct.get("emi_amount"),
            credit_limit=acct.get("credit_limit"),
            dpd=acct.get("dpd"),
            writeoff_amount=acct.get("writeoff_amount"),
            date_opened=acct.get("date_opened"),
            date_closed=acct.get("date_closed"),
            date_reported=acct.get("date_reported"),
            last_payment_date=acct.get("last_payment_date"),
            is_secured=acct.get("is_secured"),
            bureau_source=run.bureau,
            dpd_string=acct.get("dpd_string"),
            balance_history=acct.get("balance_history"),
        ))

    # ── Inquiries ─────────────────────────────────────────────────────
    for inq in parsed.get("inquiries", []):
        db.add(models.NormalizedInquiry(
            run_id=run.id,
            customer_id=inq.get("customer_id") or customer_id,
            member_id=inq.get("member_id"),
            ownership_type=inq.get("ownership_type"),
            inquiry_date=inq.get("inquiry_date"),
            inquiry_amount=inq.get("inquiry_amount"),
            inquiry_purpose=inq.get("inquiry_purpose"),
            loan_type=inq.get("loan_type"),
            lender_name=inq.get("lender_name"),
            is_secured=inq.get("is_secured"),
            bureau_source=run.bureau,
        ))

    db.commit()


def _resolve_customer_id(parsed: dict, run: models.ExecutionRun) -> str:
    """Generate a stable customer_id from available data"""
    cid = parsed.get("applicant", {}).get("customer_id")
    if cid and str(cid).strip():
        return str(cid).strip()
    pan = parsed.get("applicant", {}).get("pan")
    if pan and str(pan).strip():
        return f"PAN_{pan.strip()}"
    return f"RUN_{run.id}_CUST_1"


STATUS_CANONICAL = {
    # Generic canonical forms
    "active":           "Active",
    "closed":           "Closed",
    "written-off":      "Written-Off",
    "writtenoff":       "Written-Off",
    "settled":          "Settled",
    "suit-filed":       "Suit-Filed",
    "suit filed":       "Suit-Filed",
    "npa":              "NPA",
    "sma":              "SMA",
    "restructured":     "Restructured",
    # Equifax India raw status strings
    "new account":      "Active",
    "current account":  "Active",
    "closed account":   "Closed",
    "written off":      "Written-Off",
    "written-off account": "Written-Off",
    "settled account":  "Settled",
    "suit filed account": "Suit-Filed",
    # CIBIL numeric codes (passed through as strings)
    "00": "Active",   "07": "Active",
    "02": "Closed",   "80": "Closed",
    "03": "Written-Off", "78": "Written-Off",
    "04": "Settled",
    "05": "Suit-Filed",
    "06": "NPA",
    # CRIF raw strings
    "live":        "Active",
    "open":        "Active",
    "inactive":    "Closed",
    "write-off":   "Written-Off",
    "write off":   "Written-Off",
    "doubtful":    "NPA",
    "loss":        "NPA",
    "sub-standard": "NPA",
}


def _normalize_status(status: str) -> str:
    if not status:
        return "Active"
    return STATUS_CANONICAL.get(status.lower().strip(), status)

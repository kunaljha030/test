"""
bureau/feature_engine.py
Feature Engine — Step 4 of the 4-Bureau Workflow Diagram

Uses ONLY:
  - Standard Feature Objects (Variable records from builds)
  - Normalized Data (NormalizedAccount / NormalizedInquiry tables)

Checks required_columns → applies time windows & filters → executes feature logic
Outputs: FeatureOutput rows (customer_id, feature_name, feature_value, status)

Enquiry Sub-Categories (fully implemented, mapped from PySpark pipeline):
  volume        → count / ratio / flag
  amount        → sum, avg, max, min, median, std, variance, cv, skew, kurtosis, percentile
  gap           → avg, median, min, max, std, cv, skew (days between consecutive enquiries)
  recency       → months_since_last / months_since_oldest
  concentration → distinct_lenders, top_lender_share, hhi_index
  velocity      → count_change, count_ratio, growth_rate, slope (window vs prior window)
  mix           → secured/unsecured ratio
  threshold     → count/flag above/below an amount threshold
  distribution  → std, cv, skew, kurtosis, percentile on amounts or gaps
"""
import json
import math
import statistics
from datetime import datetime, date
from typing import List, Optional
from sqlalchemy.orm import Session
from db import models


REF_DATE = date.today()


def run_features(db: Session, run: models.ExecutionRun, variables: List[models.Variable]):
    """Main entry point: execute all variables for a run"""
    accounts   = db.query(models.NormalizedAccount).filter_by(run_id=run.id).all()
    inquiries  = db.query(models.NormalizedInquiry).filter_by(run_id=run.id).all()
    applicants = db.query(models.NormalizedApplicant).filter_by(run_id=run.id).all()

    cust_accounts  = _group(accounts,  "customer_id")
    cust_inquiries = _group(inquiries, "customer_id")
    all_customers  = set(cust_accounts.keys()) | set(cust_inquiries.keys())
    if not all_customers:
        all_customers = {a.customer_id for a in applicants} or {"UNKNOWN"}

    outputs = []
    for customer_id in all_customers:
        cust_accts = cust_accounts.get(customer_id, [])
        cust_inqs  = cust_inquiries.get(customer_id, [])
        for var in variables:
            cfg    = json.loads(var.config_json or "{}")
            result = _execute_variable(cfg, cust_accts, cust_inqs, customer_id)
            outputs.append(models.FeatureOutput(
                run_id        = run.id,
                customer_id   = customer_id,
                feature_name  = var.name,
                feature_value = str(result["value"]) if result["value"] is not None else None,
                status        = result["status"],
                skip_reason   = result.get("skip_reason"),
            ))

    db.bulk_save_objects(outputs)
    db.commit()
    return outputs


def _execute_variable(cfg: dict, accounts: list, inquiries: list, customer_id: str) -> dict:
    var_type      = (cfg.get("variable_type") or cfg.get("type") or "").lower()
    sub_cat       = (cfg.get("sub_category") or "").lower()
    agg           = (cfg.get("aggregation") or "count").lower()
    window_str    = cfg.get("time_window") or cfg.get("window") or "12m"
    window_months = _parse_window(window_str)

    if "enquiry" in var_type:
        return _compute_enquiry(cfg, inquiries, agg, window_months, sub_cat)
    elif "trade history" in var_type or "trade_history" in var_type:
        return _compute_trade_history(cfg, accounts, inquiries, agg, window_months, sub_cat)
    elif "trade" in var_type:
        return _compute_trade(cfg, accounts, agg, window_months, sub_cat)
    elif "account" in var_type:
        return _compute_account(cfg, accounts, agg, window_months, sub_cat)
    elif "cross_product" in var_type or "cross-product" in var_type:
        return _compute_cross_product(cfg, accounts, inquiries, agg, window_months, sub_cat)
    else:
        return {"value": None, "status": "skipped",
                "skip_reason": f"Unknown variable type: {var_type}"}


# ═══════════════════════════════════════════════════════════════════════════════
# ENQUIRY ENGINE  —  full sub-category dispatch
# Mirrors the PySpark logic in A_Inq_Feature_1__2_.py:
#   inq_exp0       → SECURED flag, PRODUCT_DESC mapping, credit_inq flag
#   inq_base_exp   → count by window / product / amount-bucket / secured flag
#   inq_exp2       → days-between-consecutive-enquiry distributions
#   inq_agg_exp    → sum/avg/max/min/stddev/median/skewness/kurtosis
#   inq_ratio_exp  → ratios / CV
# ═══════════════════════════════════════════════════════════════════════════════

def _compute_enquiry(cfg, inquiries, agg, window_months, sub_cat):
    loan_types = cfg.get("filters", {}).get("product") or cfg.get("loan_types") or []
    is_secured = cfg.get("filters", {}).get("secured")
    inquiry_purposes = (
        cfg.get("filters", {}).get("inquiry_purpose")
        or cfg.get("filters", {}).get("product_subtype")
        or []
    )
    if isinstance(inquiry_purposes, str):
        inquiry_purposes = [inquiry_purposes]

    filtered = _filter_inquiries(
        inquiries,
        window_months,
        loan_types,
        is_secured,
        inquiry_purposes,
        amount_op=None,
        amount_val=None,
    )

    if sub_cat == "volume":
        return _enq_volume(cfg, filtered, agg, window_months, inquiries, loan_types, is_secured)
    elif sub_cat == "amount":
        return _enq_amount(cfg, filtered, agg)
    elif sub_cat == "gap":
        return _enq_gap(cfg, filtered, agg)
    elif sub_cat == "recency":
        return _enq_recency(cfg, filtered)
    elif sub_cat == "concentration":
        return _enq_concentration(cfg, filtered, agg)
    elif sub_cat == "velocity":
        return _enq_velocity(cfg, inquiries, loan_types, is_secured, agg, window_months)
    elif sub_cat == "mix":
        return _enq_mix(filtered)
    elif sub_cat == "threshold":
        return _enq_threshold(cfg, filtered, agg)
    elif sub_cat == "distribution":
        return _enq_distribution(cfg, filtered, agg)
    elif sub_cat == "product_diversity":
        return _enq_product_diversity(cfg, filtered, agg)
    elif sub_cat == "secured_split":
        return _enq_secured_split(cfg, filtered, agg)
    elif sub_cat == "amount_bucket":
        return _enq_amount_bucket(cfg, filtered, agg)
    elif sub_cat == "inter_enquiry_timing":
        return _enq_inter_enquiry_timing(cfg, filtered, agg)
    else:
        # fallback: basic aggregation (original behaviour preserved)
        amount_op  = cfg.get("amount_op")
        amount_val = _f(cfg.get("amount_val"))
        filtered2  = _filter_inquiries(
            inquiries,
            window_months,
            loan_types,
            is_secured,
            inquiry_purposes,
            amount_op,
            amount_val,
        )
        required = _check_required_cols_inquiries(filtered2, agg)
        if required:
            return {"value": None, "status": "skipped",
                    "skip_reason": f"Missing required columns: {required}"}
        if agg == "count":   return _ok(len(filtered2))
        if agg == "sum":     return _ok(sum(i.inquiry_amount or 0 for i in filtered2))
        if agg == "avg":
            vals = [i.inquiry_amount or 0 for i in filtered2]
            return _ok(sum(vals) / len(vals) if vals else 0)
        if agg == "max":     return _ok(max((i.inquiry_amount or 0 for i in filtered2), default=0))
        if agg == "flag":    return _ok(1 if filtered2 else 0)
        if agg == "recency": return _compute_recency(filtered2, "inquiry_date")
        return _ok(len(filtered2))


# ── VOLUME ──────────────────────────────────────────────────────────────────
# Mirrors: Inq_Num_inq_{i}m, {prod}_Num_inq_{i}m, unsec_Inq_Num_inq_{month}m
#          {prod}_inq_flag, Inq (binary flag per row)
#          {flag}_Perc_Total_Inq_{month}m  (ratio expression)

def _enq_volume(cfg, filtered, agg, window_months, all_inqs, loan_types, is_secured):
    count = len(filtered)
    if agg == "count":
        return _ok(count)
    if agg == "flag":
        return _ok(1 if count > 0 else 0)
    if agg == "ratio":
        # total credit enquiries ever (mirrors Num_Total_Inq denominator)
        total = sum(1 for i in all_inqs if _is_credit_inq(i))
        if total == 0:
            return _ok(-3)   # PySpark convention: -3 = zero denominator
        return _ok(round(count / total, 6))
    return _ok(count)


# ── AMOUNT ──────────────────────────────────────────────────────────────────
# Mirrors: {prod}_max_EnquiryAmount_{i}m, max_EnquiryAmount_{i}m,
#          unsec_max_EnquiryAmount_{i}m, {prod}_latest_EnquiryAmount,
#          inq_lt_eq_{amt}_last_{m}m (amount bucket variables)

def _enq_amount(cfg, filtered, agg):
    amounts = [_f(i.inquiry_amount) for i in filtered if i.inquiry_amount is not None]
    if not amounts:
        return _ok(0)

    if agg == "sum":      return _ok(round(sum(amounts), 4))
    if agg == "avg":      return _ok(round(sum(amounts) / len(amounts), 4))
    if agg == "max":      return _ok(max(amounts))
    if agg == "min":      return _ok(min(amounts))
    if agg == "count":    return _ok(len(amounts))
    if agg == "flag":     return _ok(1 if amounts else 0)
    if agg == "median":   return _ok(round(statistics.median(amounts), 4))
    if agg == "std":
        return _ok(round(statistics.pstdev(amounts), 4) if len(amounts) > 1 else 0)
    if agg == "variance":
        return _ok(round(statistics.pvariance(amounts), 4) if len(amounts) > 1 else 0)
    if agg == "cv":
        mean = sum(amounts) / len(amounts)
        std  = statistics.pstdev(amounts) if len(amounts) > 1 else 0
        return _ok(round(std / mean, 4) if mean != 0 else None)
    if agg == "skew":     return _ok(round(_skewness(amounts), 4))
    if agg == "kurtosis": return _ok(round(_kurtosis(amounts), 4))
    if agg == "percentile":
        pct = cfg.get("percentile_value", 75)
        return _ok(round(_percentile(amounts, pct), 4))
    return _ok(round(sum(amounts) / len(amounts), 4))


# ── GAP ─────────────────────────────────────────────────────────────────────
# Mirrors: num_days_btw_inq, {prod}_num_days_btw_inq_{i}m,
#          unsec_num_days_btw_inq_{i}m
#          avg/median/max/min/stddev/skewness/kurtosis  (inq_agg_exp)
#          cv_{prod}_num_days_btw_inq_{i}m  (inq_ratio_exp)

def _enq_gap(cfg, filtered, agg):
    dated = sorted(
        [i for i in filtered if i.inquiry_date],
        key=lambda x: _parse_date(x.inquiry_date) or date.min
    )
    gaps = []
    for idx in range(1, len(dated)):
        d0 = _parse_date(dated[idx - 1].inquiry_date)
        d1 = _parse_date(dated[idx].inquiry_date)
        if d0 and d1:
            gaps.append((d1 - d0).days)

    if not gaps:
        return _ok(None)

    if agg == "avg":      return _ok(round(sum(gaps) / len(gaps), 4))
    if agg == "median":   return _ok(round(statistics.median(gaps), 4))
    if agg == "max":      return _ok(max(gaps))
    if agg == "min":      return _ok(min(gaps))
    if agg == "std":
        return _ok(round(statistics.pstdev(gaps), 4) if len(gaps) > 1 else 0)
    if agg == "cv":
        mean = sum(gaps) / len(gaps)
        std  = statistics.pstdev(gaps) if len(gaps) > 1 else 0
        return _ok(round(std / mean, 4) if mean != 0 else None)
    if agg == "skew":     return _ok(round(_skewness(gaps), 4))
    if agg == "percentile":
        pct = cfg.get("percentile_value", 75)
        return _ok(round(_percentile(gaps, pct), 4))
    return _ok(round(sum(gaps) / len(gaps), 4))


# ── RECENCY ─────────────────────────────────────────────────────────────────
# Mirrors: Inq_Month_since_latest_inq  (min mn_diff_retro_inq)
#          Inq_Month_since_oldest_inq  (max mn_diff_retro_inq)
#          {prod}_inq_latest, {prod}_inq_oldest

def _enq_recency(cfg, filtered):
    measure = cfg.get("measure", "months_since_last")
    ages    = [_months_ago(i.inquiry_date) for i in filtered if i.inquiry_date]
    ages    = [a for a in ages if a is not None]

    if not ages:
        return _ok(None)

    if measure == "months_since_last":    return _ok(min(ages))
    if measure == "months_since_oldest":  return _ok(max(ages))
    return _ok(min(ages))


# ── CONCENTRATION ────────────────────────────────────────────────────────────
# Mirrors: Inq_distinct_products_last_{i}m  (using lender_name as grouping key)
#          cv_var_inq_vel_5  (distinct EnquiryPurpose in last 30 days)

def _enq_concentration(cfg, filtered, agg):
    measure = cfg.get("measure", "distinct_lenders")
    lender_names = [getattr(i, "lender_name", None) or "UNKNOWN" for i in filtered]

    if not lender_names:
        return _ok(0)

    from collections import Counter
    counts = Counter(lender_names)
    total  = len(lender_names)

    if measure == "distinct_lenders" or agg == "count":
        return _ok(len(counts))
    if measure == "top_lender_share" or agg == "ratio":
        top_count = counts.most_common(1)[0][1]
        return _ok(round(top_count / total, 6) if total > 0 else 0)
    if measure == "hhi_index" or agg == "index":
        shares = [(c / total) ** 2 for c in counts.values()]
        return _ok(round(sum(shares), 6))
    return _ok(len(counts))


# ── VELOCITY ─────────────────────────────────────────────────────────────────
# Mirrors: window-to-window comparison of Inq_Num_inq_{i}m columns
#          e.g. count in last 3m vs prior 3m (months 3–6)
#          Corresponds to: growth_rate, count_change, count_ratio logic
#          Also mirrors: cv_var_inq_vel_5 (distinct products last 30d)

def _enq_velocity(cfg, all_inqs, loan_types, is_secured, agg, window_months):
    measure      = cfg.get("measure", "count_change")
    prior_months = cfg.get("prior_window_months") or (window_months * 2)
    inquiry_purposes = (
        cfg.get("filters", {}).get("inquiry_purpose")
        or cfg.get("filters", {}).get("product_subtype")
        or []
    )
    if isinstance(inquiry_purposes, str):
        inquiry_purposes = [inquiry_purposes]

    current = _filter_inquiries(all_inqs, window_months, loan_types, is_secured, inquiry_purposes, None, None)
    prior_full = _filter_inquiries(all_inqs, prior_months, loan_types, is_secured, inquiry_purposes, None, None)
    prior_only = [i for i in prior_full if i not in current]

    curr_cnt  = len(current)
    prior_cnt = len(prior_only)

    if measure == "count_change"  or agg == "difference":
        return _ok(curr_cnt - prior_cnt)
    if measure == "count_ratio"   or agg == "ratio":
        return _ok(round(curr_cnt / prior_cnt, 4) if prior_cnt > 0 else None)
    if measure == "growth_rate"   or agg == "growth_rate":
        if prior_cnt == 0:
            return _ok(None)
        return _ok(round((curr_cnt - prior_cnt) / prior_cnt * 100, 4))
    if measure == "slope"         or agg == "slope":
        return _ok(round((curr_cnt - prior_cnt) / max(window_months, 1), 4))
    return _ok(curr_cnt - prior_cnt)


# ── MIX ──────────────────────────────────────────────────────────────────────
# Mirrors: SECURED flag per row, unsec_Inq_Num_inq_{i}m / Inq_Num_inq_{i}m,
#          non_secured_flag (last 3m), unsec_Perc_Total_Inq_{i}m

def _enq_mix(filtered):
    if not filtered:
        return _ok(None)
    secured_cnt = sum(1 for i in filtered if getattr(i, "is_secured", False))
    return _ok(round(secured_cnt / len(filtered), 6))


# ── THRESHOLD ────────────────────────────────────────────────────────────────
# Mirrors: inq_lt_eq_{amt}_last_{m}m  (all 5 amount buckets × 4 windows)
#          unsec_inq_lt_eq_{amt}_last_{m}m
#          {prod}_inq_lt_eq_{amt}_last_{m}m  (PL / CD / CC / Other)
#          credit_inq_last_1m  (cv_var_g502s)

def _enq_threshold(cfg, filtered, agg):
    amount_op  = cfg.get("amount_op", ">=")
    amount_val = _f(cfg.get("amount_val"))

    matched = [
        i for i in filtered
        if i.inquiry_amount is not None
        and _compare(_f(i.inquiry_amount), amount_op, amount_val)
    ]

    if agg == "flag":  return _ok(1 if matched else 0)
    return _ok(len(matched))


# ── DISTRIBUTION ─────────────────────────────────────────────────────────────
# Mirrors: stddev/skewness/kurtosis/median on EnquiryAmount in inq_agg_exp
#          avg/median/max/min/stddev/cv/skewness/kurtosis on gap arrays

def _enq_distribution(cfg, filtered, agg):
    measure = cfg.get("measure", "amount_distribution")

    if "gap" in measure:
        dated = sorted(
            [i for i in filtered if i.inquiry_date],
            key=lambda x: _parse_date(x.inquiry_date) or date.min
        )
        vals = []
        for idx in range(1, len(dated)):
            d0 = _parse_date(dated[idx - 1].inquiry_date)
            d1 = _parse_date(dated[idx].inquiry_date)
            if d0 and d1:
                vals.append((d1 - d0).days)
    else:
        vals = [_f(i.inquiry_amount) for i in filtered if i.inquiry_amount is not None]

    if not vals or len(vals) < 2:
        return _ok(None)

    if agg == "std":      return _ok(round(statistics.pstdev(vals), 4))
    if agg == "variance": return _ok(round(statistics.pvariance(vals), 4))
    if agg == "cv":
        mean = sum(vals) / len(vals)
        return _ok(round(statistics.pstdev(vals) / mean, 4) if mean != 0 else None)
    if agg == "skew":     return _ok(round(_skewness(vals), 4))
    if agg == "kurtosis": return _ok(round(_kurtosis(vals), 4))
    if agg == "percentile":
        pct = cfg.get("percentile_value", 75)
        return _ok(round(_percentile(vals, pct), 4))
    if agg == "iqr":
        return _ok(round(_percentile(vals, 75) - _percentile(vals, 25), 4))
    return _ok(round(statistics.pstdev(vals), 4))


# ── PRODUCT DIVERSITY ──────────────────────────────────────────────────────────
# Maps to: Inq_distinct_products_last_{i}m  (distinct loan_type count per window)
#          product_hhi = Σ(share_i²)  — mirrors PySpark inq_ratio_exp HHI logic
#          dominant_product_share = max single product share

def _enq_product_diversity(cfg, filtered, agg):
    measure = cfg.get("measure", "distinct_products")
    loan_types = [str(i.loan_type).upper() for i in filtered if i.loan_type]

    if measure == "distinct_products":
        return _ok(len(set(loan_types)))

    if measure == "product_hhi":
        if not loan_types:
            return _ok(None)
        total = len(loan_types)
        from collections import Counter
        counts = Counter(loan_types)
        hhi = round(sum((c / total) ** 2 for c in counts.values()), 4)
        return _ok(hhi)

    if measure == "dominant_product_share":
        if not loan_types:
            return _ok(None)
        from collections import Counter
        counts = Counter(loan_types)
        return _ok(round(counts.most_common(1)[0][1] / len(loan_types), 4))

    return _ok(None)


# ── SECURED SPLIT ──────────────────────────────────────────────────────────────
# Maps to: unsec_Inq_Num_inq_{i}m / sec_Inq_Num_inq_{i}m in inq_base_exp
#          secured_flag derived from PRODUCT_DESC secured-product list

def _enq_secured_split(cfg, filtered, agg):
    measure = cfg.get("measure", "secured_ratio")
    secured   = [i for i in filtered if getattr(i, "is_secured", None) is True
                 or str(getattr(i, "is_secured", "")).lower() in ("true", "1", "yes", "y", "secured")]
    unsecured = [i for i in filtered if i not in secured]
    total     = len(filtered)

    if measure == "secured_count":   return _ok(len(secured))
    if measure == "unsecured_count": return _ok(len(unsecured))
    if measure == "secured_ratio":
        return _ok(round(len(secured) / total, 4) if total else None)
    if measure == "secured_flag":
        return _ok(1 if len(secured) > 0 else 0)
    return _ok(None)


# ── AMOUNT BUCKET ──────────────────────────────────────────────────────────────
# Maps to: inq_lt_eq_{amt}_last_{m}m family in inq_base_exp
# Buckets: <25K | 25K–1L | 1L–5L | >5L  (INR, aligned with CRIF PySpark pipeline)

def _enq_amount_bucket(cfg, filtered, agg):
    """
    Count/flag/ratio enquiries in a fixed amount bucket.
    Mode 1: amount_lo + amount_hi in cfg (from new generator).
    Mode 2: named measure like bucket_0_1k, bucket_1k_10k, etc.
    """
    amounts = [_f(i.inquiry_amount) for i in filtered if i.inquiry_amount is not None]
    if not amounts:
        return _ok(0)

    if "amount_lo" in cfg or "amount_hi" in cfg:
        lo = _f(cfg.get("amount_lo", 0))
        hi = cfg.get("amount_hi")
        matched = [a for a in amounts if a >= lo and (hi is None or a < hi)]
    else:
        BUCKET_MAP = {
            "bucket_0_1k":      (0,           1_000),
            "bucket_1k_10k":    (1_000,       10_000),
            "bucket_10k_50k":   (10_000,      50_000),
            "bucket_50k_1l":    (50_000,      100_000),
            "bucket_1l_5l":     (100_000,     500_000),
            "bucket_5l_10l":    (500_000,     1_000_000),
            "bucket_above_10l": (1_000_000,   None),
            "bucket_lt_25k":    (0,           25_000),
            "bucket_25k_1l":    (25_000,      100_000),
            "bucket_gt_5l":     (500_000,     None),
        }
        measure = (cfg.get("measure") or "").lower()
        rng = BUCKET_MAP.get(measure)
        if rng is None:
            return _ok(None)
        lo, hi = rng
        matched = [a for a in amounts if a >= lo and (hi is None or a < hi)]

    if agg == "flag":   return _ok(1 if matched else 0)
    if agg == "ratio":  return _ok(round(len(matched) / len(amounts), 6))
    return _ok(len(matched))


# ── INTER-ENQUIRY TIMING ──────────────────────────────────────────────────────
# Maps to: cv_var_g502s (span), cv_var_inq_vel_5 (burst velocity) in PySpark
# enquiry_span_months: months between first and last inquiry in window
# burst_count_30d:     count of inquiries within 30 days of any other inquiry
# burst_flag:          1 if 3+ inquiries within any 30-day window

def _enq_inter_enquiry_timing(cfg, filtered, agg):
    measure = cfg.get("measure", "enquiry_span_months")
    dated = sorted(
        [i for i in filtered if i.inquiry_date],
        key=lambda x: _parse_date(x.inquiry_date) or date.min
    )
    dates = [_parse_date(i.inquiry_date) for i in dated]
    dates = [d for d in dates if d]

    if not dates:
        return _ok(None)

    if measure == "enquiry_span_months":
        span_days = (dates[-1] - dates[0]).days
        return _ok(round(span_days / 30.44, 2))

    if measure == "burst_count_30d":
        # count inquiries that have at least one other inquiry within 30 days
        burst = 0
        for idx, d in enumerate(dates):
            for j in range(len(dates)):
                if j != idx and abs((d - dates[j]).days) <= 30:
                    burst += 1
                    break
        return _ok(burst)

    if measure == "burst_flag":
        # 1 if any 30-day window contains 3+ inquiries
        for idx, d in enumerate(dates):
            window = [x for x in dates if 0 <= (x - d).days <= 30]
            if len(window) >= 3:
                return _ok(1)
        return _ok(0)

    return _ok(None)


# ═══════════════════════════════════════════════════════════════════════════════
# TRADE ENGINE
# ═══════════════════════════════════════════════════════════════════════════════

def _compute_trade(cfg, accounts, agg, window_months, sub_cat):
    loan_types     = cfg.get("trade_scope", {}).get("loanType") or []
    secured_filter = cfg.get("trade_scope", {}).get("secured")
    status_filter  = cfg.get("trade_scope", {}).get("status") or "all"
    own_filter     = cfg.get("trade_scope", {}).get("ownership") or "all"
    measure        = (cfg.get("measure") or "current_balance").lower()

    filtered = _filter_accounts(accounts, window_months, loan_types, secured_filter,
                                status_filter, own_filter)

    dpd_threshold = _i(cfg.get("dpd_threshold") or cfg.get("conditions", {}).get("dpd_val"))
    dpd_op        = cfg.get("conditions", {}).get("dpd_op") or ">="
    if dpd_threshold:
        filtered = [a for a in filtered if _compare(a.dpd or 0, dpd_op, dpd_threshold)]

    vals = _extract_measure(filtered, measure)
    return _aggregate(vals, agg)


# ═══════════════════════════════════════════════════════════════════════════════
# ACCOUNT ENGINE
# ═══════════════════════════════════════════════════════════════════════════════

def _compute_account(cfg, accounts, agg, window_months, sub_cat):
    loan_types     = cfg.get("acc_scope", {}).get("loanType") or []
    secured_filter = cfg.get("acc_scope", {}).get("secured") or "all"
    status_list    = cfg.get("acc_scope", {}).get("statusList") or []
    measure        = (cfg.get("measure") or "current_balance").lower()

    def status_ok(a):
        if not status_list: return True
        return a.account_status in status_list

    filtered = _filter_accounts(accounts, window_months, loan_types, secured_filter, "all", "all")
    filtered = [a for a in filtered if status_ok(a)]

    if sub_cat == "utilization":
        num_field = cfg.get("util_numerator", "current_balance")
        den_field = cfg.get("util_denominator", "credit_limit")
        return _compute_utilization(filtered, num_field, den_field, agg)

    if sub_cat == "credit_mix":
        return _compute_credit_mix(filtered)

    vals = _extract_measure(filtered, measure)
    return _aggregate(vals, agg)


def _compute_utilization(accounts, num_field, den_field, agg):
    ratios = []
    for a in accounts:
        num = _get_field(a, num_field) or 0
        den = _get_field(a, den_field) or 0
        if den and den > 0:
            ratios.append(num / den)
    return _aggregate(ratios, agg)


def _compute_credit_mix(accounts):
    has_secured     = any(a.is_secured for a in accounts)
    has_unsecured   = any(not a.is_secured for a in accounts)
    has_revolving   = any(a.loan_type in ("CC", "OD") for a in accounts)
    has_installment = any(a.loan_type in ("PL", "HL", "AL", "BL", "GL", "LAP") for a in accounts)
    score = sum([has_secured, has_unsecured, has_revolving, has_installment]) * 25
    return _ok(score)


# ═══════════════════════════════════════════════════════════════════════════════
# TRADE HISTORY ENGINE  (FULLY IMPLEMENTED)
# ═══════════════════════════════════════════════════════════════════════════════
# Supports: DPD analysis, payment patterns, balance trends, behavioral scoring
# Data sources: dpd_string (monthly DPD: "XX-YY-ZZ..."), balance_history (JSON)

def _compute_trade_history(cfg, accounts, inquiries, agg, window_months, sub_cat):
    """Execute trade history features with full DPD & balance history support"""
    measure  = (cfg.get("measure") or "dpd").lower()
    filtered = [a for a in accounts if a.dpd_string or a.balance_history]
    
    if not filtered:
        return _ok(None)

    # Parse DPD histories for all filtered accounts
    dpd_histories = []
    for a in filtered:
        dpd_str = a.dpd_string or ""
        dpd_seq = _parse_dpd_string(dpd_str)[:window_months] if dpd_str else []
        if dpd_seq:
            dpd_histories.append(dpd_seq)

    # ─── DPD History Sub-Categories ───────────────────────────────────────
    if sub_cat == "dpd_history":
        if measure == "dpd_delinquent_flag":
            # 1 if any DPD >= 30 in window
            flags = [1 if any(d >= 30 for d in hist) else 0 for hist in dpd_histories]
            return _aggregate(flags, agg)
        
        elif measure == "dpd_severity_count":
            # Count months with DPD >= threshold
            dpd_thresh = _i(cfg.get("dpd_threshold", 30))
            counts = [sum(1 for d in hist if d >= dpd_thresh) for hist in dpd_histories]
            return _aggregate(counts, agg)
        
        elif measure == "dpd_bucket_0":
            # Count months with DPD 0-30
            counts = [sum(1 for d in hist if 0 <= d < 30) for hist in dpd_histories]
            return _aggregate(counts, agg)
        
        elif measure == "dpd_bucket_30":
            # Count months with DPD 30-60
            counts = [sum(1 for d in hist if 30 <= d < 60) for hist in dpd_histories]
            return _aggregate(counts, agg)
        
        elif measure == "dpd_bucket_60":
            # Count months with DPD 60-90
            counts = [sum(1 for d in hist if 60 <= d < 90) for hist in dpd_histories]
            return _aggregate(counts, agg)
        
        elif measure == "dpd_bucket_90":
            # Count months with DPD >= 90
            counts = [sum(1 for d in hist if d >= 90) for hist in dpd_histories]
            return _aggregate(counts, agg)
        
        elif measure == "dpd_max":
            # Maximum DPD in window
            maxes = [max(hist) if hist else 0 for hist in dpd_histories]
            return _aggregate(maxes, agg)
        
        elif measure == "dpd_recent":
            # Most recent DPD (first element of reversed history)
            recents = [hist[-1] if hist else 0 for hist in dpd_histories]
            return _aggregate(recents, agg)
        
        elif measure == "dpd_trend":
            # Trend: most recent - oldest (negative = improvement)
            trends = [hist[-1] - hist[0] if len(hist) > 1 else 0 for hist in dpd_histories]
            return _aggregate(trends, agg)
        
        elif measure == "dpd_volatility":
            # Std dev of DPD across months (payment consistency)
            vols = []
            for hist in dpd_histories:
                if len(hist) > 1:
                    mean = sum(hist) / len(hist)
                    vol = math.sqrt(sum((d - mean) ** 2 for d in hist) / len(hist))
                    vols.append(vol)
            return _aggregate(vols, agg) if vols else _ok(0)
        
        elif measure == "dpd_transitions":
            # Count transitions from normal (DPD<30) to delinquent (DPD>=30)
            trans = []
            for hist in dpd_histories:
                count = 0
                for i in range(1, len(hist)):
                    if hist[i-1] < 30 and hist[i] >= 30:
                        count += 1
                trans.append(count)
            return _aggregate(trans, agg) if trans else _ok(0)

    # ─── Payment Pattern Sub-Categories ────────────────────────────────────
    if sub_cat == "payment_pattern":
        if measure == "payment_consistency":
            # Score 0-100: lower variance in DPD = higher consistency
            scores = []
            for hist in dpd_histories:
                if not hist:
                    scores.append(0)
                    continue
                mean = sum(hist) / len(hist)
                std = math.sqrt(sum((d - mean) ** 2 for d in hist) / len(hist))
                # 100 - (std/100) bounded to [0, 100]
                score = max(0, min(100, 100 - (std / 2)))
                scores.append(score)
            return _aggregate(scores, agg) if scores else _ok(0)
        
        elif measure == "payment_regularity":
            # Ratio of months in DPD0 vs total months
            ratios = []
            for hist in dpd_histories:
                if hist:
                    on_time = sum(1 for d in hist if d < 30)
                    ratios.append(round(on_time / len(hist), 4))
            return _aggregate(ratios, agg) if ratios else _ok(0)

    # ─── Balance History Sub-Categories ───────────────────────────────────
    if sub_cat == "balance_history":
        all_balances = []
        for a in accounts:
            hist = _parse_balance_history(a.balance_history)
            if hist:
                all_balances.extend(hist[:window_months])
        
        if measure == "balance_trend":
            # Avg balance in window
            return _aggregate(all_balances, agg) if all_balances else _ok(0)
        
        elif measure == "balance_decline_rate":
            # Rate of balance reduction month-over-month
            declines = []
            for a in accounts:
                hist = _parse_balance_history(a.balance_history)
                if hist and len(hist) > 1:
                    hist = hist[:window_months]
                    for i in range(1, len(hist)):
                        if hist[i-1] > 0:
                            decline = (hist[i-1] - hist[i]) / hist[i-1]
                            declines.append(decline)
            return _aggregate(declines, agg) if declines else _ok(0)

    # ─── Behavioral Composites ───────────────────────────────────────────
    if sub_cat == "behavioral_score":
        if measure == "delinquency_recovery_rate":
            # Accounts recovered from DPD90+ / total delinquent
            recovery_rates = []
            for hist in dpd_histories:
                if not hist or len(hist) < 2:
                    continue
                delinq_90 = sum(1 for d in hist if d >= 90)
                if delinq_90 > 0:
                    # Check if recovered (last DPD < 30)
                    recovered = 1 if hist[-1] < 30 else 0
                    recovery_rates.append(recovered)
            return _aggregate(recovery_rates, agg) if recovery_rates else _ok(0)
        
        elif measure == "account_stability":
            # Score: 0-100 based on consistency + recovery + trend
            scores = []
            for hist in dpd_histories:
                if not hist:
                    scores.append(0)
                    continue
                # consistency (normal payments): 40 points
                consistency = (sum(1 for d in hist if d < 30) / len(hist)) * 40
                # recovery (improving trend): 40 points
                trend = hist[-1] - hist[0]  # negative = improving
                recovery = max(0, (1 - (trend / 100)) * 40)
                # recency (recent status): 20 points
                recency = max(0, (1 - (hist[-1] / 90)) * 20) if hist[-1] < 90 else 0
                score = consistency + recovery + recency
                scores.append(min(100, max(0, score)))
            return _aggregate(scores, agg) if scores else _ok(0)

    # ─── Writeoff/Charge-off Sub-Categories ──────────────────────────────
    if sub_cat == "writeoff_trajectory":
        writeoff_vals = [_f(a.writeoff_amount) for a in filtered if a.writeoff_amount]
        if measure == "writeoff_flag":
            return _ok(1 if writeoff_vals else 0)
        elif measure == "writeoff_count":
            return _ok(len([a for a in filtered if a.writeoff_amount and a.writeoff_amount > 0]))
        elif measure == "writeoff_sum":
            return _aggregate(writeoff_vals, agg) if writeoff_vals else _ok(0)
        elif measure == "writeoff_risk_score":
            # Combined risk: delinquency + writeoff presence
            risk_score = 0
            if any(d >= 90 for hist in dpd_histories for d in hist):
                risk_score += 50
            if writeoff_vals:
                risk_score += 50
            return _ok(risk_score)

    # Fallback
    vals = _extract_measure(filtered, measure)
    return _aggregate(vals, agg)


# ═══════════════════════════════════════════════════════════════════════════════
# CROSS-PRODUCT ENGINE    (Enquiry ↔ Trade interactions)
# ═══════════════════════════════════════════════════════════════════════════════
# Maps Enquiries to Accounts on loan_type to compute ratios & relationships

def _compute_cross_product(cfg, accounts, inquiries, agg, window_months, sub_cat):
    """Cross-entity features: Enquiry vs Trade relationships"""
    
    # Filter based on windows
    inq_window_months = cfg.get("enquiry_window", window_months)
    trade_window_months = cfg.get("trade_window", window_months)
    
    filtered_inq = _filter_inquiries(inquiries, inq_window_months, [], None, [], None, None)
    filtered_accounts = _filter_accounts(accounts, trade_window_months, [], None, "all", "all")
    
    # ─── Enquiry to Trade Volume Ratios ──────────────────────────────────
    if sub_cat == "enquiry_vs_trade_volume":
        if not filtered_inq or not filtered_accounts:
            return _ok(None)
        
        measure = cfg.get("measure", "enq_per_active_trade")
        inq_count = len(filtered_inq)
        active_accounts = len([a for a in filtered_accounts if a.account_status and "active" in a.account_status.lower()])
        
        if measure == "enq_per_active_trade":
            return _ok(round(inq_count / active_accounts, 4) if active_accounts > 0 else None)
        
        elif measure == "trade_per_enquiry":
            return _ok(round(active_accounts / inq_count, 4) if inq_count > 0 else None)
        
        elif measure == "enq_count":
            return _ok(inq_count)
        
        elif measure == "active_trade_count":
            return _ok(active_accounts)

    # ─── Amount Comparison ───────────────────────────────────────────────
    elif sub_cat == "amount_comparison":
        measure = cfg.get("measure", "max_inq_vs_max_trade")
        inq_amounts = [_f(i.inquiry_amount) for i in filtered_inq if i.inquiry_amount]
        trade_amounts = [_f(a.current_balance) for a in filtered_accounts if a.current_balance]
        
        max_inq = max(inq_amounts) if inq_amounts else 0
        max_trade = max(trade_amounts) if trade_amounts else 0
        avg_inq = sum(inq_amounts) / len(inq_amounts) if inq_amounts else 0
        avg_trade = sum(trade_amounts) / len(trade_amounts) if trade_amounts else 0
        
        if measure == "max_inq_vs_max_trade":
            return _ok(round(max_inq / max_trade, 4) if max_trade > 0 else None)
        elif measure == "avg_inq_vs_avg_trade":
            return _ok(round(avg_inq / avg_trade, 4) if avg_trade > 0 else None)
        elif measure == "total_inq_exposure":
            return _ok(round(sum(inq_amounts), 4) if inq_amounts else 0)
        elif measure == "total_trade_exposure":
            return _ok(round(sum(trade_amounts), 4) if trade_amounts else 0)

    # ─── Concentration Comparison ───────────────────────────────────────
    elif sub_cat == "concentration_comparison":
        measure = cfg.get("measure", "hhi_ratio")
        
        # Enquiry concentration (by lender)
        inq_lenders = [i.lender_name for i in filtered_inq if i.lender_name]
        from collections import Counter
        inq_counts = Counter(inq_lenders)
        inq_total = len(inq_lenders)
        inq_hhi = sum((c / inq_total) ** 2 for c in inq_counts.values()) if inq_total > 0 else 0
        
        # Trade concentration (by lender)
        tr_lenders = [a.lender_name for a in filtered_accounts if a.lender_name]
        tr_counts = Counter(tr_lenders)
        tr_total = len(tr_lenders)
        tr_hhi = sum((c / tr_total) ** 2 for c in tr_counts.values()) if tr_total > 0 else 0
        
        if measure == "hhi_ratio":
            return _ok(round(inq_hhi / tr_hhi, 4) if tr_hhi > 0 else None)
        elif measure == "enquiry_hhi":
            return _ok(round(inq_hhi, 4))
        elif measure == "trade_hhi":
            return _ok(round(tr_hhi, 4))
        elif measure == "distinct_inq_lenders":
            return _ok(len(inq_counts))
        elif measure == "distinct_trade_lenders":
            return _ok(len(tr_counts))

    # ─── Product Mix Overlap ────────────────────────────────────────────
    elif sub_cat == "product_mix_overlap":
        measure = cfg.get("measure", "common_product_count")
        inq_products = set([i.loan_type for i in filtered_inq if i.loan_type])
        trade_products = set([a.loan_type for a in filtered_accounts if a.loan_type])
        
        common = inq_products & trade_products
        inq_only = inq_products - trade_products
        trade_only = trade_products - inq_products
        
        if measure == "common_product_count":
            return _ok(len(common))
        elif measure == "inq_only_products":
            return _ok(len(inq_only))
        elif measure == "trade_only_products":
            return _ok(len(trade_only))
        elif measure == "product_overlap_ratio":
            total_unique = len(inq_products | trade_products)
            return _ok(round(len(common) / total_unique, 4) if total_unique > 0 else None)

    # ─── Loan Type Specific Ratios ──────────────────────────────────────
    elif sub_cat == "loan_type_ratios":
        measure = cfg.get("measure", "pl_inq_per_pl_trade")
        product = cfg.get("loan_type", "PL")
        
        inq_prod = [i for i in filtered_inq if i.loan_type == product]
        trade_prod = [a for a in filtered_accounts if a.loan_type == product]
        
        if measure == f"{product.lower()}_inq_per_trade":
            trade_count = len(trade_prod)
            return _ok(round(len(inq_prod) / trade_count, 4) if trade_count > 0 else None)
        elif measure == f"{product.lower()}_inq_count":
            return _ok(len(inq_prod))
        elif measure == f"{product.lower()}_active_count":
            return _ok(len([a for a in trade_prod if a.account_status and "active" in a.account_status.lower()]))

    # ─── Utilization vs Recent Enquiries ────────────────────────────────
    elif sub_cat == "utilization_vs_enquiries":
        measure = cfg.get("measure", "avg_utilization_with_recent_inq")
        
        # Recent inquiries (less than 3 months)
        recent_inq = [i for i in filtered_inq if _months_ago(i.inquiry_date) is not None and _months_ago(i.inquiry_date) <= 3]
        
        # Credit accounts with utilization
        cc_accounts = [a for a in filtered_accounts if a.loan_type in ("CC", "OD")]
        utilizations = []
        for a in cc_accounts:
            if a.credit_limit and a.credit_limit > 0:
                util = min(100, (a.current_balance or 0) / a.credit_limit * 100)
                utilizations.append(util)
        
        if measure == "avg_utilization_with_recent_inq":
            if recent_inq and utilizations:
                return _ok(round(sum(utilizations) / len(utilizations), 2))
            return _ok(0)
        elif measure == "recent_inq_flag":
            return _ok(1 if recent_inq else 0)
        elif measure == "high_util_low_inq":
            # High util (>70%) but no recent enquiries
            high_util = len([u for u in utilizations if u > 70])
            return _ok(1 if high_util > 0 and not recent_inq else 0)

    # ─── Risk Indicators from Cross-Product ────────────────────────────
    elif sub_cat == "cross_product_risk":
        measure = cfg.get("measure", "leverage_ratio")
        
        total_inq = sum(_f(i.inquiry_amount) for i in filtered_inq if i.inquiry_amount)
        total_exposure = sum(_f(a.current_balance) for a in filtered_accounts if a.current_balance)
        total_overdue = sum(_f(a.overdue_amount) for a in filtered_accounts if a.overdue_amount)
        
        if measure == "leverage_ratio":
            # Requested amount vs existing exposure
            total_sanction = sum(_f(a.sanction_amount) for a in filtered_accounts if a.sanction_amount)
            return _ok(round(total_inq / (total_sanction + total_inq), 4) if (total_sanction + total_inq) > 0 else None)
        
        elif measure == "delinquency_vs_inq":
            # Delinquent amount vs recent inquiries
            return _ok(round(total_overdue / total_inq, 4) if total_inq > 0 else None)
        
        elif measure == "exposure_increase":
            # Are inquiries larger than current exposure?
            return _ok(1 if total_inq > total_exposure else 0)

    return _ok(None)


# ═══════════════════════════════════════════════════════════════════════════════
# FILTER HELPERS
# ═══════════════════════════════════════════════════════════════════════════════

def _filter_inquiries(inquiries, window_months, loan_types, is_secured,
                      inquiry_purposes, amount_op, amount_val):
    result = []
    normalized_purposes = {str(p).strip().lower() for p in (inquiry_purposes or []) if str(p).strip()}
    for inq in inquiries:
        if window_months and inq.inquiry_date:
            age = _months_ago(inq.inquiry_date)
            if age is not None and age > window_months:
                continue
        if loan_types and inq.loan_type not in loan_types:
            continue
        if normalized_purposes and str(getattr(inq, "inquiry_purpose", "") or "").strip().lower() not in normalized_purposes:
            continue
        if is_secured not in (None, "all"):
            if is_secured == "secured"   and not inq.is_secured: continue
            if is_secured == "unsecured" and inq.is_secured:     continue
        if amount_op and amount_val is not None:
            if not _compare(inq.inquiry_amount or 0, amount_op, amount_val): continue
        result.append(inq)
    return result


def _filter_accounts(accounts, window_months, loan_types, secured_filter,
                     status_filter, own_filter):
    result = []
    for a in accounts:
        if window_months and a.date_reported:
            age = _months_ago(a.date_reported)
            if age is not None and age > window_months: continue
        if loan_types and a.loan_type not in loan_types: continue
        if secured_filter and secured_filter not in ("all", None):
            if secured_filter == "secured"   and not a.is_secured: continue
            if secured_filter == "unsecured" and a.is_secured:     continue
        if status_filter and status_filter != "all":
            if a.account_status != status_filter: continue
        if own_filter and own_filter != "all":
            if (a.ownership_type or "").lower() != own_filter: continue
        result.append(a)
    return result


def _extract_measure(accounts, measure):
    field_map = {
        "current_balance":     "current_balance",
        "outstanding_balance": "current_balance",
        "sanction_amount":     "sanction_amount",
        "overdue_amount":      "overdue_amount",
        "emi_amount":          "emi_amount",
        "credit_limit":        "credit_limit",
        "dpd":                 "dpd",
        "writeoff_amount":     "writeoff_amount",
    }
    field = field_map.get(measure, "current_balance")
    return [getattr(a, field) or 0 for a in accounts if getattr(a, field) is not None]


# ═══════════════════════════════════════════════════════════════════════════════
# AGGREGATION
# ═══════════════════════════════════════════════════════════════════════════════

def _aggregate(vals, agg):
    if not vals:
        if agg == "flag": return _ok(0)
        return {"value": 0, "status": "ready"}
    if agg == "count":    return _ok(len(vals))
    if agg == "sum":      return _ok(sum(vals))
    if agg == "avg":      return _ok(sum(vals) / len(vals))
    if agg == "max":      return _ok(max(vals))
    if agg == "min":      return _ok(min(vals))
    if agg == "median":   return _ok(statistics.median(vals))
    if agg == "std":
        mean     = sum(vals) / len(vals)
        variance = sum((v - mean) ** 2 for v in vals) / len(vals)
        return _ok(math.sqrt(variance))
    if agg == "variance":
        mean = sum(vals) / len(vals)
        return _ok(sum((v - mean) ** 2 for v in vals) / len(vals))
    if agg == "cv":
        mean = sum(vals) / len(vals)
        std  = math.sqrt(sum((v - mean) ** 2 for v in vals) / len(vals))
        return _ok(round(std / mean, 4) if mean != 0 else None)
    if agg == "skew":     return _ok(round(_skewness(vals), 4))
    if agg == "kurtosis": return _ok(round(_kurtosis(vals), 4))
    if agg == "flag":     return _ok(1 if any(v > 0 for v in vals) else 0)
    if agg == "recency":  return _ok(min(vals))
    if agg == "percentile":
        return _ok(round(_percentile(vals, 75), 4))
    if agg == "iqr":
        return _ok(round(_percentile(vals, 75) - _percentile(vals, 25), 4))
    return _ok(sum(vals))


def _compute_recency(items, date_field):
    min_months = None
    for item in items:
        val = getattr(item, date_field, None)
        if val:
            age = _months_ago(val)
            if age is not None:
                min_months = age if min_months is None else min(min_months, age)
    return _ok(min_months)


# ═══════════════════════════════════════════════════════════════════════════════
# STATISTICS HELPERS  (match PySpark built-ins)
# ═══════════════════════════════════════════════════════════════════════════════

def _skewness(vals: list) -> float:
    """Population skewness — matches PySpark skewness()."""
    n = len(vals)
    if n < 3: return 0.0
    mean = sum(vals) / n
    std  = math.sqrt(sum((v - mean) ** 2 for v in vals) / n)
    if std == 0: return 0.0
    return (sum((v - mean) ** 3 for v in vals) / n) / (std ** 3)


def _kurtosis(vals: list) -> float:
    """Excess kurtosis — matches PySpark kurtosis()."""
    n = len(vals)
    if n < 4: return 0.0
    mean = sum(vals) / n
    std  = math.sqrt(sum((v - mean) ** 2 for v in vals) / n)
    if std == 0: return 0.0
    return (sum((v - mean) ** 4 for v in vals) / n) / (std ** 4) - 3


def _percentile(vals: list, pct: float) -> float:
    """Linear-interpolation percentile — matches numpy default."""
    sv = sorted(vals)
    n  = len(sv)
    if n == 1: return sv[0]
    idx  = (pct / 100) * (n - 1)
    lo   = int(idx)
    hi   = lo + 1
    frac = idx - lo
    if hi >= n: return sv[-1]
    return sv[lo] + frac * (sv[hi] - sv[lo])


# ═══════════════════════════════════════════════════════════════════════════════
# DATE HELPERS
# ═══════════════════════════════════════════════════════════════════════════════

def _parse_window(window_str) -> int:
    if not window_str: return 12
    w = str(window_str).lower().replace("m", "").strip()
    try:    return int(w)
    except: return 12


def _months_ago(date_str) -> Optional[int]:
    if not date_str: return None
    d = _parse_date(date_str)
    if d is None: return None
    diff = (REF_DATE.year - d.year) * 12 + (REF_DATE.month - d.month)
    return max(0, diff)


def _parse_date(date_str) -> Optional[date]:
    if not date_str: return None
    fmts = ["%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y", "%Y%m%d", "%m/%Y"]
    for fmt in fmts:
        try:    return datetime.strptime(str(date_str)[:10], fmt).date()
        except: continue
    return None


# ═══════════════════════════════════════════════════════════════════════════════
# DPD BUCKETING HELPERS  (systematic DPD categorization)
# ═══════════════════════════════════════════════════════════════════════════════

def _bucket_dpd(dpd_value: int) -> str:
    """Categorize DPD into buckets: 0, 30, 60, 90, WO"""
    if dpd_value is None or dpd_value < 0:
        return "0"
    elif dpd_value < 30:
        return "0"
    elif dpd_value < 60:
        return "30"
    elif dpd_value < 90:
        return "60"
    else:
        return "90"


def _get_dpd_bucket_counts(accounts: list, window_months: int) -> dict:
    """
    Returns count of accounts in each DPD bucket for given window.
    Returns: {'dpd_0': count, 'dpd_30': count, 'dpd_60': count, 'dpd_90': count}
    """
    buckets = {"dpd_0": 0, "dpd_30": 0, "dpd_60": 0, "dpd_90": 0}
    
    for account in accounts:
        if not account.dpd_string:
            buckets["dpd_0"] += 1
            continue
        
        dpd_seq = _parse_dpd_string(account.dpd_string)[:window_months]
        if dpd_seq:
            # Use most recent DPD (last element)
            latest_dpd = dpd_seq[-1]
            bucket = _bucket_dpd(latest_dpd)
            key = f"dpd_{bucket}"
            buckets[key] += 1
    
    return buckets


def _get_dpd_bucket_exposures(accounts: list, window_months: int) -> dict:
    """
    Returns total exposure (current_balance) by DPD bucket.
    Returns: {'dpd_0': exposure, 'dpd_30': exposure, 'dpd_60': exposure, 'dpd_90': exposure}
    """
    buckets = {"dpd_0": 0.0, "dpd_30": 0.0, "dpd_60": 0.0, "dpd_90": 0.0}
    
    for account in accounts:
        amount = _f(account.current_balance)
        if not account.dpd_string:
            buckets["dpd_0"] += amount
            continue
        
        dpd_seq = _parse_dpd_string(account.dpd_string)[:window_months]
        if dpd_seq:
            latest_dpd = dpd_seq[-1]
            bucket = _bucket_dpd(latest_dpd)
            key = f"dpd_{bucket}"
            buckets[key] += amount
    
    return buckets


def _get_dpd_transitions(accounts: list, window_months: int) -> dict:
    """
    Count transitions between DPD buckets.
    Returns transitions: 0→30, 30→60, 60→90, 90→recovery (90+→0), etc.
    """
    transitions = {
        "0_to_30": 0, "30_to_60": 0, "60_to_90": 0, "90_to_0": 0,
        "improved": 0, "deteriorated": 0
    }
    
    for account in accounts:
        if not account.dpd_string:
            continue
        
        dpd_seq = _parse_dpd_string(account.dpd_string)[:window_months]
        if len(dpd_seq) < 2:
            continue
        
        for i in range(1, len(dpd_seq)):
            from_bucket = _bucket_dpd(dpd_seq[i-1])
            to_bucket = _bucket_dpd(dpd_seq[i])
            
            if from_bucket == "0" and to_bucket == "30":
                transitions["0_to_30"] += 1
            elif from_bucket == "30" and to_bucket == "60":
                transitions["30_to_60"] += 1
            elif from_bucket == "60" and to_bucket == "90":
                transitions["60_to_90"] += 1
            elif from_bucket == "90" and to_bucket == "0":
                transitions["90_to_0"] += 1
            
            # Track improvement vs deterioration
            if to_bucket < from_bucket:
                transitions["improved"] += 1
            elif to_bucket > from_bucket:
                transitions["deteriorated"] += 1
    
    return transitions


def _get_dpd_velocity(accounts: list, window_months: int) -> float:
    """
    Calculate average velocity of DPD changes (slope).
    Positive = worsening, negative = improving
    """
    velocities = []
    
    for account in accounts:
        if not account.dpd_string:
            continue
        
        dpd_seq = _parse_dpd_string(account.dpd_string)[:window_months]
        if len(dpd_seq) < 2:
            continue
        
        # Linear regression slope
        n = len(dpd_seq)
        x_mean = sum(range(n)) / n
        y_mean = sum(dpd_seq) / n
        
        numerator = sum((i - x_mean) * (dpd_seq[i] - y_mean) for i in range(n))
        denominator = sum((i - x_mean) ** 2 for i in range(n))
        
        if denominator != 0:
            slope = numerator / denominator
            velocities.append(slope)
    
    if velocities:
        return sum(velocities) / len(velocities)
    return 0.0


def _parse_date(date_str) -> Optional[date]:
    if not date_str: return None
    fmts = ["%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y", "%Y%m%d", "%m/%Y"]
    for fmt in fmts:
        try:    return datetime.strptime(str(date_str)[:10], fmt).date()
        except: continue
    return None


def _parse_dpd_string(dpd_str: str) -> List[int]:
    result = []
    for i in range(0, len(dpd_str), 3):
        chunk = dpd_str[i:i+3]
        try:    result.append(int(chunk))
        except: result.append(0)
    return result


def _parse_balance_history(history_json) -> List[float]:
    if not history_json: return []
    try:
        data = json.loads(history_json)
        if isinstance(data, list):
            return [_f(v) for v in data]
        return []
    except:
        return []


def _is_credit_inq(inq) -> bool:
    """Mirrors the credit_inq flag: excludes 'Auto Lease', null, and 'Other'."""
    purpose = getattr(inq, "inquiry_purpose", None) or ""
    return bool(purpose) and purpose not in ("Auto Lease", "Other")


# ═══════════════════════════════════════════════════════════════════════════════
# MISC
# ═══════════════════════════════════════════════════════════════════════════════

def _check_required_cols_inquiries(inqs, agg):
    if agg in ("sum", "avg", "max") and not any(i.inquiry_amount for i in inqs):
        return ["inquiry_amount"]
    return []


def _get_field(obj, field_name):
    field_map = {
        "current_balance":     "current_balance",
        "outstanding_balance": "current_balance",
        "sanction_amount":     "sanction_amount",
        "overdue_amount":      "overdue_amount",
        "emi_amount":          "emi_amount",
        "credit_limit":        "credit_limit",
    }
    return getattr(obj, field_map.get(field_name, field_name), None)


def _compare(val, op, threshold):
    ops = {">": val > threshold, ">=": val >= threshold,
           "<": val < threshold, "<=": val <= threshold, "=": val == threshold}
    return ops.get(op, False)


def _group(items, key_field):
    result = {}
    for item in items:
        k = getattr(item, key_field, "UNKNOWN")
        result.setdefault(k, []).append(item)
    return result


def _ok(val): return {"value": val, "status": "ready"}

def _f(v, d=0.0):
    try:    return float(v or 0)
    except: return d

def _i(v, d=0):
    try:    return int(v or 0)
    except: return d

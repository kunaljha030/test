"""
bureau/behavioral_engine.py
Behavioral Composite Functions — Advanced scoring & risk indicators

Computes behavioral features that combine multiple underlying signals:
  - Payment Consistency Score: deviation in payment-on-time patterns
  - Credit Stress Index: weighted combination of delinquency + utilization + writeoff
  - Delinquency Recovery Rate: fraction of customers recovering from 90+ DPD
  - Account Stability: multi-factor score (consistency + recovery + recency)
  - Credit Limit Utilization Trend: change in utilization over time windows
  - Inquiry Velocity: acceleration of inquiries (volume_3m - volume_6m) / volume_6m
"""

import json
import math
import statistics
from datetime import datetime, date
from typing import List, Optional, Dict, Tuple


def payment_consistency_score(dpd_histories: List[List[int]]) -> float:
    """
    Score 0-100: Higher = more consistent payments
    Based on: - stddev of DPD values (lower = consistent)
              - frequency of DPD=0 months (higher = consistent)
    
    Formula: (% months on-time * 0.6) + (1 - normalized_std) * 40
    """
    if not dpd_histories:
        return 0.0
    
    scores = []
    for dpd_seq in dpd_histories:
        if not dpd_seq:
            scores.append(0.0)
            continue
        
        # Frequency of on-time payments (DPD < 30)
        on_time = sum(1 for d in dpd_seq if d < 30)
        on_time_pct = (on_time / len(dpd_seq)) * 100
        
        # Std dev of DPD (lower = more consistent)
        mean = sum(dpd_seq) / len(dpd_seq)
        std = math.sqrt(sum((d - mean) ** 2 for d in dpd_seq) / len(dpd_seq))
        
        # Normalize std to 0-1 (clipped at 100 DPD)
        normalized_std = min(1.0, std / 100.0)
        
        # Composite score
        score = (on_time_pct * 0.006) + ((1 - normalized_std) * 40)
        scores.append(min(100, max(0, score)))
    
    return sum(scores) / len(scores) if scores else 0.0


def credit_stress_index(
    dpd_accounts: List[int],
    utilization_ratio: float,
    writeoff_amount: float,
    total_credit_limit: float = None
) -> float:
    """
    Score 0-100: Higher = more financial stress
    Weighted combination of:
      - Delinquency severity (DPD levels): 40 points
      - Utilization (high usage = stress): 35 points
      - Writeoff presence: 25 points
    """
    stress = 0.0
    
    # Delinquency: max DPD in portfolio (40 points)
    if dpd_accounts:
        max_dpd = max(dpd_accounts) if dpd_accounts else 0
        if max_dpd >= 90:
            stress += 40
        elif max_dpd >= 60:
            stress += 30
        elif max_dpd >= 30:
            stress += 15
        else:
            stress += 0
    
    # Utilization: (35 points)
    if utilization_ratio is not None:
        if utilization_ratio > 0.80:
            stress += 35
        elif utilization_ratio > 0.60:
            stress += 20
        elif utilization_ratio > 0.40:
            stress += 10
    
    # Writeoff indicator: (25 points)
    if writeoff_amount and writeoff_amount > 0:
        stress += 25
    
    return min(100, max(0, stress))


def delinquency_recovery_rate(
    dpd_histories: List[List[int]],
    threshold_dpd: int = 90
) -> float:
    """
    Ratio: Recovered accounts / Total delinquent accounts
    Resolved = last DPD < 30 after being >= threshold_dpd
    
    Returns: 0.0 - 1.0 (or 0 if no delinquent accounts)
    """
    recovered = 0
    total_delinq = 0
    
    for dpd_seq in dpd_histories:
        if not dpd_seq:
            continue
        
        # Was ever delinquent?
        was_delinq = any(d >= threshold_dpd for d in dpd_seq)
        if not was_delinq:
            continue
        
        total_delinq += 1
        
        # Is now recovered? (last month < 30)
        if dpd_seq[-1] < 30:
            recovered += 1
    
    if total_delinq == 0:
        return 0.0  # No delinquent accounts in portfolio
    
    return round(recovered / total_delinq, 4)


def account_stability_score(
    dpd_histories: List[List[int]],
    weighted: bool = True
) -> float:
    """
    Composite stability score 0-100.
    Components (equal weight unless weighted=True):
      - Consistency (40): % on-time payments
      - Recovery Trend (40): improvement in DPD over time
      - Recency (20): how stable is the most recent DPD
    
    Weighted version: Recency gets higher weight if user is recent delinquent
    """
    if not dpd_histories:
        return 0.0
    
    scores = []
    
    for dpd_seq in dpd_histories:
        if not dpd_seq:
            scores.append(0.0)
            continue
        
        # Component 1: Consistency (% on-time, max 40 points)
        on_time = sum(1 for d in dpd_seq if d < 30)
        consistency_score = (on_time / len(dpd_seq)) * 40
        
        # Component 2: Recovery Trend (improvement = positive, max 40 points)
        if len(dpd_seq) > 1:
            trend = dpd_seq[-1] - dpd_seq[0]  # negative = improving
            # Map -100 to +100 range to 0-40 points
            trend_score = max(0, 40 - (trend / 5))  # Each +5 DPD = -1 point
        else:
            trend_score = 30 if dpd_seq[0] < 30 else 10
        
        # Component 3: Recency (current status, max 20 points)
        current_dpd = dpd_seq[-1]
        if current_dpd < 30:
            recency_score = 20
        elif current_dpd < 60:
            recency_score = 12
        elif current_dpd < 90:
            recency_score = 6
        else:
            recency_score = 0
        
        # Combine
        total_score = consistency_score + trend_score + recency_score
        scores.append(min(100, max(0, total_score)))
    
    return sum(scores) / len(scores) if scores else 0.0


def credit_limit_utilization_trend(
    current_balance: float,
    credit_limit: float,
    hist_3m_balance: float = None,
    hist_6m_balance: float = None,
    hist_12m_balance: float = None
) -> Dict[str, float]:
    """
    Track utilization changes across windows.
    Returns: {
        'current_util': current_util%,
        'util_trend_3m': (current - 3m) / 3m,
        'util_trend_6m': (current - 6m) / 6m,
        'util_trend_12m': (current - 12m) / 12m,
        'max_util': max observed in history
    }
    """
    if not credit_limit or credit_limit == 0:
        return {
            "current_util": None,
            "util_trend_3m": None,
            "util_trend_6m": None,
            "util_trend_12m": None,
            "max_util": None
        }
    
    current_util = min(100, (current_balance or 0) / credit_limit * 100)
    
    result = {"current_util": round(current_util, 2)}
    
    if hist_3m_balance is not None and hist_3m_balance > 0:
        hist_3m_util = min(100, hist_3m_balance / credit_limit * 100)
        result["util_trend_3m"] = round((current_util - hist_3m_util) / hist_3m_util, 4) if hist_3m_util > 0 else None
    
    if hist_6m_balance is not None and hist_6m_balance > 0:
        hist_6m_util = min(100, hist_6m_balance / credit_limit * 100)
        result["util_trend_6m"] = round((current_util - hist_6m_util) / hist_6m_util, 4) if hist_6m_util > 0 else None
    
    if hist_12m_balance is not None and hist_12m_balance > 0:
        hist_12m_util = min(100, hist_12m_balance / credit_limit * 100)
        result["util_trend_12m"] = round((current_util - hist_12m_util) / hist_12m_util, 4) if hist_12m_util > 0 else None
    
    # Track max utilization historically
    all_utils = [current_util]
    if hist_3m_balance: all_utils.append(min(100, hist_3m_balance / credit_limit * 100))
    if hist_6m_balance: all_utils.append(min(100, hist_6m_balance / credit_limit * 100))
    if hist_12m_balance: all_utils.append(min(100, hist_12m_balance / credit_limit * 100))
    
    result["max_util"] = round(max(all_utils), 2) if all_utils else None
    
    return result


def inquiry_velocity_score(
    inq_count_1m: int,
    inq_count_3m: int,
    inq_count_6m: int,
    inq_count_12m: int
) -> Dict[str, float]:
    """
    Track acceleration of inquiries over time windows.
    Returns: {
        'velocity_3m_1m': (1m - avg 3m prior) / avg,
        'velocity_6m_3m': (avg 3m - avg 6m prior) / avg,
        'velocity_12m_6m': (avg 6m - avg 12m prior) / avg,
        'risk_flag': 1 if sharp increase (>100%)
    }
    """
    result = {}
    
    # 3m to 1m acceleration
    if inq_count_3m > 0:
        # Average monthly in 3m window
        avg_3m_monthly = inq_count_3m / 3
        if avg_3m_monthly > 0:
            velocity_3m_1m = (inq_count_1m - avg_3m_monthly) / avg_3m_monthly
            result["velocity_3m_1m"] = round(velocity_3m_1m, 4)
    
    # 6m to 3m acceleration
    if inq_count_6m > 0 and inq_count_3m > 0:
        # Inquiries 3-6m ago
        inq_3m_to_6m = inq_count_6m - inq_count_3m
        if inq_3m_to_6m > 0:
            velocity_6m_3m = (inq_count_3m - inq_3m_to_6m) / inq_3m_to_6m
            result["velocity_6m_3m"] = round(velocity_6m_3m, 4)
    
    # 12m to 6m acceleration
    if inq_count_12m > 0 and inq_count_6m > 0:
        # Inquiries 6-12m ago
        inq_6m_to_12m = inq_count_12m - inq_count_6m
        if inq_6m_to_12m > 0:
            velocity_12m_6m = (inq_count_6m - inq_6m_to_12m) / inq_6m_to_12m
            result["velocity_12m_6m"] = round(velocity_12m_6m, 4)
    
    # Risk flag: sharp increase
    risk_flag = 0
    if "velocity_3m_1m" in result and result["velocity_3m_1m"] > 1.0:  # >100% increase
        risk_flag = 1
    if "velocity_6m_3m" in result and result["velocity_6m_3m"] > 1.0:
        risk_flag = 1
    
    result["inquiry_velocity_risk_flag"] = risk_flag
    
    return result


def portfolio_concentration_score(
    lender_counts: Dict[str, int],
    loan_type_counts: Dict[str, int]
) -> Dict[str, float]:
    """
    Calculate concentration indices for diversification.
    Returns:
      {
        'lender_hhi': Herfindahl index (0-1, 1=monopoly),
        'lender_top_share': top lender % of portfolio,
        'loan_type_hhi': HHI for loan types,
        'diversification_score': 0-100 (100=well diversified)
      }
    """
    result = {}
    
    # Lender concentration (HHI)
    if lender_counts and sum(lender_counts.values()) > 0:
        total = sum(lender_counts.values())
        hhi = sum((count / total) ** 2 for count in lender_counts.values())
        result["lender_hhi"] = round(hhi, 4)
        result["lender_top_share"] = round(max(lender_counts.values()) / total, 4)
    
    # Loan type concentration (HHI)
    if loan_type_counts and sum(loan_type_counts.values()) > 0:
        total = sum(loan_type_counts.values())
        hhi = sum((count / total) ** 2 for count in loan_type_counts.values())
        result["loan_type_hhi"] = round(hhi, 4)
    
    # Overall diversification score (0-100)
    # Lower HHI = better diversification
    avg_hhi = (result.get("lender_hhi", 0) + result.get("loan_type_hhi", 0)) / 2
    diversity_score = max(0, min(100, (1 - avg_hhi) * 100))
    result["diversification_score"] = round(diversity_score, 2)
    
    return result


def payment_pattern_regularity(dpd_histories: List[List[int]]) -> float:
    """
    Score 0-100: Regularity of payment patterns (inverse of volatility)
    Higher = more predictable pattern
    
    Uses entropy + temporal autocorrelation
    """
    if not dpd_histories:
        return 0.0
    
    regularities = []
    
    for dpd_seq in dpd_histories:
        if len(dpd_seq) < 2:
            regularities.append(0.0)
            continue
        
        # Categorize into states
        states = []
        for d in dpd_seq:
            if d < 30:
                states.append("ON_TIME")
            elif d < 60:
                states.append("30DPD")
            elif d < 90:
                states.append("60DPD")
            else:
                states.append("90+DPD")
        
        # Count transitions
        transitions = 0
        for i in range(1, len(states)):
            if states[i] != states[i-1]:
                transitions += 1
        
        # Regularity = 1 - (transitions / max_possible_transitions)
        max_transitions = len(states) - 1
        if max_transitions > 0:
            regularity = 1 - (transitions / max_transitions)
            regularities.append(max(0, min(100, regularity * 100)))
        else:
            regularities.append(100)
    
    return sum(regularities) / len(regularities) if regularities else 0.0


def credit_age_profile(
    open_dates: List[str],
    close_dates: List[str],
    reference_date: date = None
) -> Dict[str, float]:
    """
    Analyze age profile of accounts.
    Returns:
      {
        'avg_account_age': months,
        'max_account_age': months,
        'min_account_age': months,
        'closed_account_count': count,
        'closed_account_age': avg months at closure
      }
    """
    from datetime import datetime
    
    if reference_date is None:
        reference_date = date.today()
    
    result = {}
    
    # Active account ages
    ages = []
    for open_date_str in open_dates:
        if open_date_str:
            try:
                open_d = datetime.strptime(str(open_date_str)[:10], "%Y-%m-%d").date()
                age_months = (reference_date.year - open_d.year) * 12 + (reference_date.month - open_d.month)
                ages.append(age_months)
            except:
                pass
    
    if ages:
        result["avg_account_age"] = round(sum(ages) / len(ages), 2)
        result["max_account_age"] = max(ages)
        result["min_account_age"] = min(ages)
    
    # Closed account analysis
    closed_ages = []
    for i, open_date_str in enumerate(open_dates):
        if i < len(close_dates) and close_dates[i]:
            try:
                open_d = datetime.strptime(str(open_date_str)[:10], "%Y-%m-%d").date()
                close_d = datetime.strptime(str(close_dates[i])[:10], "%Y-%m-%d").date()
                age_months = (close_d.year - open_d.year) * 12 + (close_d.month - open_d.month)
                closed_ages.append(age_months)
            except:
                pass
    
    result["closed_account_count"] = len(closed_ages)
    if closed_ages:
        result["closed_account_avg_age"] = round(sum(closed_ages) / len(closed_ages), 2)
    
    return result

"""
Bureau Parser — CIBIL (XML format)
Supports both formats:
  Format A: AccountSegment / InquirySegment / Consumer (newer sample format)
  Format B: CAIS_Account / CAPS_Application_Details / Name (older format)
"""
import xml.etree.ElementTree as ET
from typing import Dict, Any, List

CIBIL_ACCOUNT_STATUS_MAP = {
    "00": "Active", "02": "Closed", "03": "Written-Off",
    "04": "Settled", "05": "Suit-Filed", "06": "NPA",
    "07": "Active", "78": "Written-Off", "80": "Closed",
}
CIBIL_LOAN_TYPE_MAP = {
    "01": "HL", "02": "AL", "03": "BL", "04": "LAP",
    "05": "PL", "06": "CC", "07": "CD", "08": "OD",
    "09": "Consumer", "10": "GL", "13": "CD",
}


def parse(content: bytes) -> Dict[str, Any]:
    try:
        root = ET.fromstring(content)
    except ET.ParseError as e:
        return {"error": str(e), "applicant": {}, "accounts": [], "inquiries": []}

    ns = root.tag.split("}")[0] + "}" if root.tag.startswith("{") else ""

    def ftext(el, path, default=""):
        found = el.find(f"{ns}{path}") if ns else el.find(path)
        return (found.text or default).strip() if found is not None else default

    def fall(el, path):
        return el.findall(f"{ns}{path}") or el.findall(path)

    secured_types = {"HL", "AL", "GL", "LAP"}

    # ── Detect format ─────────────────────────────────────────────────
    has_new_format = root.find("Accounts/AccountSegment") is not None or \
                     root.find("ApplicantDetails/Consumer") is not None

    if has_new_format:
        return _parse_new_format(root, ftext, fall, secured_types)
    else:
        return _parse_old_format(root, ftext, fall, secured_types, ns)


def _parse_new_format(root, ftext, fall, secured_types):
    """Format: AccountSegment / InquirySegment / Consumer"""
    accounts: List[dict] = []
    inquiries: List[dict] = []

    # Multi-customer: one applicant per consumer
    # We return all accounts/inquiries with their ConsumerNumber as customer_id
    for acct in root.findall("Accounts/AccountSegment"):
        cid = _t(acct, "ConsumerNumber")
        raw_type = _t(acct, "AccountType")
        lt = CIBIL_LOAN_TYPE_MAP.get(raw_type, raw_type or "Unknown")
        dpd_str = _t(acct, "PaymentRating") or "000"
        dpd = _parse_dpd_from_rating(dpd_str)

        accounts.append({
            "customer_id":    cid,
            "account_number": _t(acct, "AccountNumber"),
            "lender_name":    _t(acct, "MemberShortName"),
            "loan_type":      lt,
            "account_status": _status_from_dpd(dpd),
            "ownership_type": {"1": "Individual", "2": "Joint", "3": "Guarantor"}.get(_t(acct, "OwnershipIndicator"), "Individual"),
            "sanction_amount":  _f(_t(acct, "HighCreditOrSanctionedAmount")),
            "current_balance":  _f(_t(acct, "CurrentBalance")),
            "overdue_amount":   _f(_t(acct, "AmtOverdue")),
            "emi_amount":       0.0,
            "credit_limit":     None,
            "dpd":              dpd,
            "writeoff_amount":  0.0,
            "date_opened":      _t(acct, "DateOpened"),
            "date_closed":      None,
            "date_reported":    _t(acct, "DateReported"),
            "last_payment_date": None,
            "is_secured":       lt in secured_types,
            "ownership_type":   "Individual",
            "dpd_string":       None,
            "balance_history":  None,
            "bureau_source":    "CIBIL",
        })

    for inq in root.findall("Inquiries/InquirySegment"):
        cid = _t(inq, "ConsumerNumber")
        raw_type = _t(inq, "InquiryPurpose")
        lt = CIBIL_LOAN_TYPE_MAP.get(raw_type, raw_type or "Unknown")
        inquiries.append({
            "customer_id":    cid,
            "member_id":      _t(inq, "MemberId") or _t(inq, "MemberShortName"),
            "ownership_type": _t(inq, "OwnershipIndicator"),
            "inquiry_date":   _t(inq, "InquiryDate"),
            "inquiry_amount": _f(_t(inq, "Amount")),
            "inquiry_purpose": raw_type,
            "loan_type":      lt,
            "lender_name":    _t(inq, "MemberShortName"),
            "is_secured":     lt in secured_types,
            "bureau_source":  "CIBIL",
        })

    # Use first consumer as primary applicant
    applicant = {}
    cons = root.find("ApplicantDetails/Consumer")
    if cons is not None:
        ns_el = cons.find("NameSegment")
        applicant = {
            "customer_id":   _t(cons, "ConsumerNumber"),
            "full_name":     ((_t(ns_el, "FirstName") if ns_el is not None else "") + " " +
                              (_t(ns_el, "LastName")  if ns_el is not None else "")).strip(),
            "date_of_birth": _t(cons, "DateOfBirth"),
            "pan":           _t(cons, "PAN"),
            "mobile":        _t(cons, "MobilePhoneNumber"),
        }

    return {"applicant": applicant, "accounts": accounts, "inquiries": inquiries}


def _parse_old_format(root, ftext, fall, secured_types, ns):
    """Format: CAIS_Account / CAPS_Application_Details / Name"""
    applicant = {}
    for tag in ["Name", "ApplicantName", "CAIS_Account_HOLDER"]:
        name_el = root.find(f"{ns}{tag}") or root.find(tag)
        if name_el is not None:
            applicant = {
                "full_name":     (ftext(name_el, "First_Name") + " " + ftext(name_el, "Last_Name")).strip(),
                "date_of_birth": ftext(name_el, "Date_Of_Birth"),
                "pan":           ftext(name_el, "Income_Tax_Pan"),
                "mobile":        ftext(name_el, "MobilePhoneNumber"),
                "customer_id":   ftext(name_el, "EFX_ID") or ftext(root, "MemberId"),
            }
            break

    accounts: List[dict] = []
    for el in fall(root, "CAIS_Account") + fall(root, "Account"):
        lt = CIBIL_LOAN_TYPE_MAP.get(ftext(el, "Account_Type"), ftext(el, "Account_Type") or "Unknown")
        st = CIBIL_ACCOUNT_STATUS_MAP.get(ftext(el, "Account_Status"), ftext(el, "Account_Status") or "Unknown")
        accounts.append({
            "account_number":  ftext(el, "Account_Number"),
            "lender_name":     ftext(el, "Subscriber_Name"),
            "loan_type":       lt,
            "account_status":  st,
            "ownership_type":  {"1": "Individual", "2": "Joint", "3": "Guarantor"}.get(ftext(el, "Ownership_Indicator"), "Individual"),
            "sanction_amount": _f(ftext(el, "Sanctioned_Amount")),
            "current_balance": _f(ftext(el, "Current_Balance")),
            "overdue_amount":  _f(ftext(el, "Amount_Overdue")),
            "emi_amount":      _f(ftext(el, "EMI_Amount")),
            "credit_limit":    _f(ftext(el, "Credit_Limit")) or None,
            "dpd":             _i(ftext(el, "Days_Past_Due")),
            "writeoff_amount": _f(ftext(el, "Written_Off_Amount_Total")),
            "date_opened":     ftext(el, "Open_Date"),
            "date_closed":     ftext(el, "Closed_Date"),
            "date_reported":   ftext(el, "Date_Reported"),
            "last_payment_date": ftext(el, "Date_of_Last_Payment"),
            "is_secured":      lt in secured_types,
            "dpd_string":      ftext(el, "CAIS_Account_HOLDER/Combined_Payment_String"),
            "balance_history": None,
            "bureau_source":   "CIBIL",
        })

    inquiries: List[dict] = []
    for el in fall(root, "CAPS_Application_Details") + fall(root, "Inquiry"):
        lt = CIBIL_LOAN_TYPE_MAP.get(ftext(el, "CAPS_Account_Type"), ftext(el, "CAPS_Account_Type") or "Unknown")
        inquiries.append({
            "customer_id":    ftext(el, "CustomerId") or applicant.get("customer_id"),
            "member_id":      ftext(el, "MemberId") or ftext(el, "CAPS_Subscriber_Name"),
            "ownership_type": ftext(el, "Ownership_Indicator"),
            "inquiry_date":   ftext(el, "CAPS_Application_Date"),
            "inquiry_amount": _f(ftext(el, "CAPS_Applied_Amount")),
            "inquiry_purpose": ftext(el, "CAPS_Account_Type"),
            "loan_type":      lt,
            "lender_name":    ftext(el, "CAPS_Subscriber_Name"),
            "is_secured":     lt in secured_types,
            "bureau_source":  "CIBIL",
        })

    return {"applicant": applicant, "accounts": accounts, "inquiries": inquiries}


def _t(el, tag, default=""):
    found = el.find(tag)
    return (found.text or default).strip() if found is not None else default

def _parse_dpd_from_rating(rating_str):
    """PaymentRating '030' → 30 DPD"""
    try: return int(rating_str.strip())
    except: return 0

def _status_from_dpd(dpd):
    if dpd >= 90: return "NPA"
    if dpd >= 60: return "Active"
    if dpd >= 30: return "Active"
    return "Active"

def _f(v, default=0.0):
    try: return float(v or 0)
    except: return default

def _i(v, default=0):
    try: return int(v or 0)
    except: return default

"""Bureau Parser — Equifax India (XML format)
Supports both formats:
  Format A: TradeLines/TradeLine / Inquiries/Inquiry / ApplicantDetails/Applicant (sample)
  Format B: Account/Tradeline / Inquiry / PersonalInfo (old format)
"""
import xml.etree.ElementTree as ET
from typing import Dict, Any

SECURED_TYPES = {"HL", "AL", "GL", "LAP"}

EFX_LOAN_MAP = {
    "I001": "PL", "I002": "CC", "I003": "HL", "I004": "AL",
    "I005": "BL", "I006": "GL", "I007": "OD", "I008": "LAP", "I009": "CD",
    "HOME_LOAN": "HL", "PERSONAL_LOAN": "PL", "AUTO_LOAN": "AL",
    "CREDIT_CARD": "CC", "BUSINESS_LOAN": "BL", "GOLD_LOAN": "GL",
    "OVERDRAFT": "OD", "LAP": "LAP", "CONSUMER_DURABLE": "CD",
}
EFX_STATUS_MAP = {
    "11": "Active", "21": "Closed", "23": "Written-Off",
    "22": "Settled", "71": "NPA", "97": "Suit-Filed",
}


def parse(content: bytes) -> Dict[str, Any]:
    try:
        root = ET.fromstring(content)
    except ET.ParseError as e:
        return {"error": str(e), "applicant": {}, "accounts": [], "inquiries": []}

    # Detect format by checking for TradeLine vs Account tag
    has_new = root.find("TradeLines") is not None or root.find("ApplicantDetails") is not None
    if has_new:
        return _parse_new_format(root)
    return _parse_old_format(root)


def _parse_new_format(root) -> Dict[str, Any]:
    """Format: TradeLines/TradeLine, Inquiries/Inquiry, ApplicantDetails/Applicant"""
    def t(el, tag, default=""):
        found = el.find(tag)
        return (found.text or default).strip() if found is not None else default

    secured_types = SECURED_TYPES

    applicant = {}
    appl_el = root.find("ApplicantDetails/Applicant")
    if appl_el is not None:
        name_el = appl_el.find("Name")
        full_name = ""
        if name_el is not None:
            full_name = (t(name_el, "First") + " " + t(name_el, "Last")).strip()
        applicant = {
            "customer_id":   t(appl_el, "CustomerId"),
            "full_name":     full_name,
            "date_of_birth": t(appl_el, "DOB"),
            "pan":           t(appl_el, "PANNo"),
            "mobile":        t(appl_el, "PhoneNumber"),
        }

    accounts = []
    for tl in root.findall("TradeLines/TradeLine"):
        raw_type = t(tl, "AccountTypeCode")
        lt = EFX_LOAN_MAP.get(raw_type, raw_type or "Unknown")
        dpd = _parse_dpd(t(tl, "DaysPastDue") or "0")
        accounts.append({
            "customer_id":    t(tl, "CustomerId"),
            "account_number": t(tl, "AccountNo"),
            "lender_name":    t(tl, "SubscriberName") or t(tl, "MemberName"),
            "loan_type":      lt,
            "account_status": _status_from_dpd(dpd),
            "ownership_type": {"IND": "Individual", "JNT": "Joint", "I": "Individual", "J": "Joint"}.get(t(tl, "OwnershipCode"), "Individual"),
            "sanction_amount":  _f(t(tl, "SanctionAmount")),
            "current_balance":  _f(t(tl, "CurrentBalance")),
            "overdue_amount":   _f(t(tl, "PastDueAmount") or "0"),
            "emi_amount":       _f(t(tl, "EMIAmount") or "0"),
            "credit_limit":     None,
            "dpd":              dpd,
            "writeoff_amount":  0.0,
            "date_opened":      t(tl, "OpenDate"),
            "date_closed":      None,
            "date_reported":    t(tl, "DateReported"),
            "last_payment_date": None,
            "is_secured":       lt in secured_types,
            "dpd_string":       None,
            "balance_history":  None,
            "bureau_source":    "Equifax",
        })

    inquiries = []
    for inq in root.findall("Inquiries/Inquiry"):
        raw_type = t(inq, "Purpose")
        lt = EFX_LOAN_MAP.get(raw_type, raw_type or "Unknown")
        inquiries.append({
            "customer_id":    t(inq, "CustomerId"),
            "member_id":      t(inq, "SubscriberId") or t(inq, "MemberId"),
            "ownership_type": t(inq, "OwnershipCode") or t(inq, "OwnershipType"),
            "inquiry_date":   t(inq, "InquiryDate"),
            "inquiry_amount": _f(t(inq, "InquiryAmount") or "0"),
            "inquiry_purpose": raw_type,
            "loan_type":      lt,
            "lender_name":    t(inq, "MemberName") or t(inq, "SubscriberName"),
            "is_secured":     lt in secured_types,
            "bureau_source":  "Equifax",
        })

    return {"applicant": applicant, "accounts": accounts, "inquiries": inquiries}


def _parse_old_format(root) -> Dict[str, Any]:
    """Format: Account/Tradeline, Inquiry, PersonalInfo"""
    ns = root.tag.split("}")[0] + "}" if root.tag.startswith("{") else ""

    def ftext(el, path, default=""):
        found = el.find(f"{ns}{path}") or el.find(path)
        return (found.text or default).strip() if found is not None else default

    def fall(el, path):
        return el.findall(f"{ns}{path}") or el.findall(path)

    personal = root.find(f"{ns}PersonalInfo") or root.find("PersonalInfo") or root
    applicant = {
        "full_name":     ftext(personal, "FirstName") + " " + ftext(personal, "LastName"),
        "date_of_birth": ftext(personal, "DateOfBirth") or ftext(personal, "DOB"),
        "pan":           ftext(personal, "PAN") or ftext(personal, "IncomeTaxId"),
        "mobile":        ftext(personal, "PhoneNumber") or ftext(personal, "Mobile"),
        "customer_id":   ftext(personal, "CustomerId") or ftext(root, "EFX_ID"),
    }

    accounts = []
    for el in fall(root, "Account") + fall(root, "Tradeline"):
        raw_type   = ftext(el, "AccountType")
        raw_status = ftext(el, "AccountStatus")
        lt = EFX_LOAN_MAP.get(raw_type, raw_type or "Unknown")
        st = EFX_STATUS_MAP.get(raw_status, raw_status or "Active")
        accounts.append({
            "account_number":  ftext(el, "AccountNumber"),
            "lender_name":     ftext(el, "SubscriberName") or ftext(el, "Lender"),
            "loan_type":       lt, "account_status": st,
            "ownership_type":  {"I": "Individual", "J": "Joint", "G": "Guarantor"}.get(ftext(el, "OwnershipType"), "Individual"),
            "sanction_amount": _f(ftext(el, "SanctionedAmount") or ftext(el, "HighCredit")),
            "current_balance": _f(ftext(el, "CurrentBalance")),
            "overdue_amount":  _f(ftext(el, "AmountOverdue")),
            "emi_amount":      _f(ftext(el, "EMIAmount")),
            "credit_limit":    _f(ftext(el, "CreditLimit")) or None,
            "dpd":             _i(ftext(el, "DPD") or ftext(el, "DaysPastDue")),
            "writeoff_amount": _f(ftext(el, "WriteOffAmount")),
            "date_opened":     ftext(el, "DateOpened"), "date_closed": ftext(el, "DateClosed"),
            "date_reported":   ftext(el, "DateReported"), "last_payment_date": ftext(el, "LastPaymentDate"),
            "is_secured":      lt in SECURED_TYPES, "dpd_string": ftext(el, "PaymentHistory"),
            "balance_history": None, "bureau_source": "Equifax",
        })

    inquiries = []
    for el in fall(root, "Inquiry") + fall(root, "Enquiry"):
        raw_type = ftext(el, "AccountType") or ftext(el, "Purpose")
        lt = EFX_LOAN_MAP.get(raw_type, raw_type or "Unknown")
        inquiries.append({
            "customer_id":    ftext(el, "CustomerId") or ftext(root, "EFX_ID"),
            "member_id":      ftext(el, "SubscriberId") or ftext(el, "MemberId"),
            "ownership_type": ftext(el, "OwnershipType"),
            "inquiry_date":   ftext(el, "InquiryDate") or ftext(el, "Date"),
            "inquiry_amount": _f(ftext(el, "InquiryAmount") or ftext(el, "Amount")),
            "inquiry_purpose": raw_type,
            "loan_type":      lt, "lender_name": ftext(el, "SubscriberName") or ftext(el, "Lender"),
            "is_secured":     lt in SECURED_TYPES, "bureau_source": "Equifax",
        })

    return {"applicant": applicant, "accounts": accounts, "inquiries": inquiries}


def _parse_dpd(val):
    try: return int(str(val).strip().lstrip("0") or "0")
    except: return 0

def _status_from_dpd(dpd):
    if dpd >= 90: return "NPA"
    return "Active"

def _f(v, default=0.0):
    try: return float(v or 0)
    except: return default

def _i(v, default=0):
    try: return int(v or 0)
    except: return default

"""Bureau Parser — CRIF High Mark (JSON format)
Supports both formats:
  Format A: {applicantDetails:[], tradeLines:[], inquiries:[]} (sample format)
  Format B: {CreditReport: {Accounts:[], Inquiries:[]}} (old format)
"""
import json
from typing import Dict, Any

SECURED_TYPES = {"HL", "AL", "GL", "LAP"}

CRIF_LOAN_MAP = {
    "Personal Loan": "PL", "Credit Card": "CC", "Housing Loan": "HL", "Home Loan": "HL",
    "Auto Loan": "AL", "Vehicle Loan": "AL", "Business Loan": "BL",
    "Gold Loan": "GL", "Overdraft": "OD", "LAP": "LAP", "CD": "CD",
    "HOME_LOAN": "HL", "PERSONAL_LOAN": "PL", "AUTO_LOAN": "AL",
    "CREDIT_CARD": "CC", "BUSINESS_LOAN": "BL", "GOLD_LOAN": "GL",
    "OVERDRAFT": "OD", "CONSUMER_DURABLE": "CD",
    "Kisan Credit Card": "CC", "Microfinance": "BL",
}


def parse(content: bytes) -> Dict[str, Any]:
    try:
        data = json.loads(content)
    except json.JSONDecodeError as e:
        return {"error": str(e), "applicant": {}, "accounts": [], "inquiries": []}

    # Detect format A
    if isinstance(data.get("tradeLines"), list) or isinstance(data.get("applicantDetails"), list):
        return _parse_new_format(data)

    return _parse_old_format(data)


def _parse_new_format(data: dict) -> Dict[str, Any]:
    """Format: {applicantDetails:[], tradeLines:[], inquiries:[]}"""
    appls = data.get("applicantDetails", [])
    tls   = data.get("tradeLines", [])
    inqs  = data.get("inquiries", [])

    applicant = {}
    if appls:
        a = appls[0]
        applicant = {
            "customer_id":   a.get("borrowerId") or a.get("customerId"),
            "full_name":     a.get("fullName") or a.get("name", ""),
            "date_of_birth": a.get("dob") or a.get("dateOfBirth"),
            "pan":           a.get("panId") or a.get("pan"),
            "mobile":        a.get("mobileNumber") or a.get("mobile"),
        }

    accounts = []
    for tl in tls:
        raw_type = tl.get("loanType") or tl.get("facilityType") or ""
        lt = CRIF_LOAN_MAP.get(raw_type, raw_type or "Unknown")
        dpd = _parse_dpd(tl.get("dpd") or "0")
        accounts.append({
            "customer_id":    tl.get("borrowerId") or tl.get("customerId"),
            "account_number": tl.get("loanAccountNumber") or tl.get("accountNumber"),
            "lender_name":    tl.get("memberName") or tl.get("lender"),
            "loan_type":      lt,
            "account_status": _status_from_dpd(dpd),
            "ownership_type": {"IND": "Individual", "JNT": "Joint"}.get(tl.get("ownership", ""), "Individual"),
            "sanction_amount":  _f(tl.get("disbursedAmount") or tl.get("sanctionedAmount") or 0),
            "current_balance":  _f(tl.get("currentBalance") or tl.get("outstandingBalance") or 0),
            "overdue_amount":   _f(tl.get("overdueAmount") or 0),
            "emi_amount":       _f(tl.get("installmentAmount") or tl.get("emi") or 0),
            "credit_limit":     None,
            "dpd":              dpd,
            "writeoff_amount":  _f(tl.get("writeOffAmount") or 0),
            "date_opened":      tl.get("dateDisbursed") or tl.get("dateOpened"),
            "date_closed":      tl.get("dateClosed"),
            "date_reported":    tl.get("reportedDate") or tl.get("dateReported"),
            "last_payment_date": tl.get("lastPaymentDate"),
            "is_secured":       lt in SECURED_TYPES,
            "dpd_string":       tl.get("dpd"),
            "balance_history":  None,
            "bureau_source":    "CRIF",
        })

    inquiries = []
    for inq in inqs:
        raw_type = inq.get("loanPurpose") or inq.get("purpose") or inq.get("loanType") or ""
        lt = CRIF_LOAN_MAP.get(raw_type, raw_type or "Unknown")
        inquiries.append({
            "customer_id":    inq.get("borrowerId") or inq.get("customerId"),
            "member_id":      inq.get("memberId") or inq.get("memberCode"),
            "ownership_type": inq.get("ownershipType") or inq.get("ownership"),
            "inquiry_date":   inq.get("inquiryDate") or inq.get("date"),
            "inquiry_amount": _f(inq.get("inquiryAmount") or inq.get("amount") or 0),
            "inquiry_purpose": raw_type,
            "loan_type":      lt,
            "lender_name":    inq.get("memberName") or inq.get("lender"),
            "is_secured":     lt in SECURED_TYPES,
            "bureau_source":  "CRIF",
        })

    return {"applicant": applicant, "accounts": accounts, "inquiries": inquiries}


def _parse_old_format(data: dict) -> Dict[str, Any]:
    """Format: {CreditReport: {Accounts:[], Inquiries:[]}}"""
    root = data.get("CreditReport", data.get("CRIFReport", data))
    applicant_raw = root.get("Applicant", root.get("PersonalDetails", {}))
    applicant = {
        "full_name":     applicant_raw.get("FullName") or applicant_raw.get("Name"),
        "date_of_birth": applicant_raw.get("DateOfBirth") or applicant_raw.get("DOB"),
        "pan":           applicant_raw.get("PAN") or applicant_raw.get("IncomeTaxId"),
        "mobile":        applicant_raw.get("Mobile") or applicant_raw.get("PhoneNumber"),
        "customer_id":   applicant_raw.get("CustomerId") or applicant_raw.get("ID"),
    }

    accounts = []
    for acct in (root.get("Accounts", []) or root.get("Tradelines", [])):
        raw_type = acct.get("FacilityType") or acct.get("LoanType") or ""
        lt = CRIF_LOAN_MAP.get(raw_type, raw_type or "Unknown")
        accounts.append({
            "account_number":  acct.get("AccountNumber"),
            "lender_name":     acct.get("Lender") or acct.get("MemberName"),
            "loan_type":       lt,
            "account_status":  acct.get("AccountStatus") or acct.get("Status") or "Active",
            "ownership_type":  acct.get("OwnershipType") or "Individual",
            "sanction_amount": _f(acct.get("SanctionedAmount")),
            "current_balance": _f(acct.get("CurrentBalance") or acct.get("OutstandingBalance")),
            "overdue_amount":  _f(acct.get("OverdueAmount") or acct.get("Overdue")),
            "emi_amount":      _f(acct.get("EMI")),
            "credit_limit":    _f(acct.get("CreditLimit")) or None,
            "dpd":             _i(acct.get("DPD") or acct.get("DaysOverdue")),
            "writeoff_amount": _f(acct.get("WriteOffAmount")),
            "date_opened":     acct.get("DateOpened"),
            "date_closed":     acct.get("DateClosed"),
            "date_reported":   acct.get("DateReported") or acct.get("AsOfDate"),
            "last_payment_date": acct.get("LastPaymentDate"),
            "is_secured":      lt in SECURED_TYPES,
            "dpd_string":      acct.get("DPDHistory") or acct.get("PaymentHistory"),
            "balance_history": json.dumps(acct.get("BalanceHistory")) if acct.get("BalanceHistory") else None,
            "bureau_source":   "CRIF",
        })

    inquiries = []
    for inq in (root.get("Inquiries", []) or root.get("Enquiries", [])):
        raw_type = inq.get("Purpose") or inq.get("LoanType") or ""
        lt = CRIF_LOAN_MAP.get(raw_type, raw_type or "Unknown")
        inquiries.append({
            "customer_id":    inq.get("CustomerId") or inq.get("BorrowerId"),
            "member_id":      inq.get("MemberId") or inq.get("MemberCode"),
            "ownership_type": inq.get("OwnershipType") or inq.get("Ownership"),
            "inquiry_date":   inq.get("InquiryDate") or inq.get("Date"),
            "inquiry_amount": _f(inq.get("Amount")),
            "inquiry_purpose": raw_type,
            "loan_type":      lt,
            "lender_name":    inq.get("Lender") or inq.get("MemberName"),
            "is_secured":     lt in SECURED_TYPES,
            "bureau_source":  "CRIF",
        })

    return {"applicant": applicant, "accounts": accounts, "inquiries": inquiries}


def _parse_dpd(val):
    try: return int(str(val).strip().lstrip("0") or "0")
    except: return 0

def _status_from_dpd(dpd):
    if dpd >= 90: return "NPA"
    return "Active"

def _f(v, default=0.0):
    try: return float(v or 0)
    except: return default

def _i(v, default=0):
    try: return int(v or 0)
    except: return default

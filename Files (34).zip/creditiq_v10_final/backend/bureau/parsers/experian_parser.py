"""Bureau Parser — Experian India (JSON format)
Supports both formats:
  Format A: {applicantDetails:[], tradeLines:[], inquiries:[]} (sample format)
  Format B: {INProfileResponse: {Accounts:{Account:[]}, Enquiries:{Enquiry:[]}}} (old format)
"""
import json
from typing import Dict, Any

SECURED_TYPES = {"HL", "AL", "GL", "LAP"}

EXPERIAN_LOAN_MAP = {
    "Personal Loan": "PL", "Credit Card": "CC", "Home Loan": "HL",
    "Auto Loan": "AL", "Business Loan": "BL", "Gold Loan": "GL",
    "Overdraft": "OD", "Loan Against Property": "LAP", "Consumer Durable": "CD",
    "HOME_LOAN": "HL", "PERSONAL_LOAN": "PL", "AUTO_LOAN": "AL",
    "CREDIT_CARD": "CC", "BUSINESS_LOAN": "BL", "GOLD_LOAN": "GL",
    "OVERDRAFT": "OD", "LAP": "LAP", "CONSUMER_DURABLE": "CD",
    "PL": "PL", "CC": "CC", "HL": "HL", "AL": "AL", "BL": "BL",
    "GL": "GL", "OD": "OD", "CD": "CD",
}


def parse(content: bytes) -> Dict[str, Any]:
    try:
        data = json.loads(content)
    except json.JSONDecodeError as e:
        return {"error": str(e), "applicant": {}, "accounts": [], "inquiries": []}

    # Detect format A (flat lists at top level)
    if isinstance(data.get("tradeLines"), list) or isinstance(data.get("applicantDetails"), list):
        return _parse_new_format(data)

    # Format B — old nested format
    return _parse_old_format(data)


def _parse_new_format(data: dict) -> Dict[str, Any]:
    """Format: {applicantDetails:[], tradeLines:[], inquiries:[]}"""
    appls = data.get("applicantDetails", [])
    tls   = data.get("tradeLines", [])
    inqs  = data.get("inquiries", [])

    applicant = {}
    if appls:
        a = appls[0]
        name_parts = a.get("name", "").split(" ", 1)
        applicant = {
            "customer_id":   a.get("consumerId") or a.get("customerId"),
            "full_name":     a.get("name", ""),
            "date_of_birth": a.get("dateOfBirth") or a.get("dob"),
            "pan":           a.get("pan") or a.get("panNumber"),
            "mobile":        a.get("mobile") or a.get("mobileNumber") or a.get("phone"),
        }

    accounts = []
    for tl in tls:
        raw_type = tl.get("accountType") or tl.get("loanType") or ""
        lt = EXPERIAN_LOAN_MAP.get(raw_type, raw_type or "Unknown")
        dpd = _parse_dpd(tl.get("paymentHistoryProfile") or tl.get("dpd") or "0")
        accounts.append({
            "customer_id":    tl.get("consumerId") or tl.get("customerId"),
            "account_number": tl.get("accountNumber"),
            "lender_name":    tl.get("subscriberName") or tl.get("institution"),
            "loan_type":      lt,
            "account_status": _status_from_dpd(dpd),
            "ownership_type": tl.get("ownershipType", "Individual"),
            "sanction_amount":  _f(tl.get("sanctionAmount") or tl.get("sanctionedAmount")),
            "current_balance":  _f(tl.get("currentBalance") or tl.get("balance")),
            "overdue_amount":   _f(tl.get("amountPastDue") or tl.get("overdueAmount") or 0),
            "emi_amount":       _f(tl.get("emiAmount") or tl.get("installmentAmount") or 0),
            "credit_limit":     _f(tl.get("creditLimit")) or None,
            "dpd":              dpd,
            "writeoff_amount":  _f(tl.get("writeOffAmount") or 0),
            "date_opened":      tl.get("dateOpened") or tl.get("dateDisbursed"),
            "date_closed":      tl.get("dateClosed"),
            "date_reported":    tl.get("dateReported") or tl.get("reportedDate"),
            "last_payment_date": tl.get("lastPaymentDate"),
            "is_secured":       lt in SECURED_TYPES,
            "dpd_string":       tl.get("paymentHistoryProfile"),
            "balance_history":  None,
            "bureau_source":    "Experian",
        })

    inquiries = []
    for inq in inqs:
        raw_type = inq.get("inquiryType") or inq.get("loanType") or inq.get("purpose") or ""
        lt = EXPERIAN_LOAN_MAP.get(raw_type, raw_type or "Unknown")
        inquiries.append({
            "customer_id":    inq.get("consumerId") or inq.get("customerId"),
            "member_id":      inq.get("subscriberId") or inq.get("memberId"),
            "ownership_type": inq.get("ownershipType"),
            "inquiry_date":   inq.get("inquiryDate") or inq.get("date"),
            "inquiry_amount": _f(inq.get("amount") or inq.get("inquiryAmount") or 0),
            "inquiry_purpose": raw_type,
            "loan_type":      lt,
            "lender_name":    inq.get("subscriberName") or inq.get("institution"),
            "is_secured":     lt in SECURED_TYPES,
            "bureau_source":  "Experian",
        })

    return {"applicant": applicant, "accounts": accounts, "inquiries": inquiries}


def _parse_old_format(data: dict) -> Dict[str, Any]:
    """Format: {INProfileResponse: {Accounts:{Account:[]}, Enquiries:{Enquiry:[]}}}"""
    root = data.get("INProfileResponse", data.get("CreditReport", data))
    personal = root.get("Current_Application", {}).get("Current_Application_Details", {}) or root.get("PersonalInfo", {})
    applicant = {
        "full_name":      personal.get("First_Name", "") + " " + personal.get("Last_Name", ""),
        "date_of_birth":  personal.get("Date_Of_Birth") or personal.get("DOB"),
        "pan":            personal.get("Income_TAX_PAN") or personal.get("PAN"),
        "mobile":         personal.get("MobileNumber") or personal.get("Mobile"),
        "customer_id":    personal.get("CustomerId") or personal.get("UniqueID"),
    }

    accounts = []
    raw_accounts = root.get("Accounts", {}).get("Account", root.get("Tradelines", []))
    if isinstance(raw_accounts, dict): raw_accounts = [raw_accounts]
    for acct in (raw_accounts or []):
        raw_type = acct.get("AccountType") or acct.get("LoanType") or ""
        lt = EXPERIAN_LOAN_MAP.get(raw_type, raw_type or "Unknown")
        accounts.append({
            "account_number":  acct.get("AccountNumber") or acct.get("Account_Number"),
            "lender_name":     acct.get("Institution") or acct.get("Lender"),
            "loan_type":       lt,
            "account_status":  acct.get("AccountStatus") or acct.get("Status") or "Active",
            "ownership_type":  acct.get("OwnershipType") or "Individual",
            "sanction_amount": _f(acct.get("SanctionedAmount") or acct.get("Sanctioned_Amount")),
            "current_balance": _f(acct.get("currentBalance") or acct.get("Balance")),
            "overdue_amount":  _f(acct.get("OverdueAmount") or acct.get("Overdue")),
            "emi_amount":      _f(acct.get("EMIAmount") or acct.get("EMI")),
            "credit_limit":    _f(acct.get("CreditLimit") or acct.get("Limit")) or None,
            "dpd":             _i(acct.get("DPD") or acct.get("Days_Past_Due")),
            "writeoff_amount": _f(acct.get("WriteOffAmount")),
            "date_opened":     acct.get("DateOpened") or acct.get("Open_Date"),
            "date_closed":     acct.get("DateClosed") or acct.get("Close_Date"),
            "date_reported":   acct.get("dateReported") or acct.get("ReportedDate"),
            "last_payment_date": acct.get("LastPaymentDate"),
            "is_secured":      lt in SECURED_TYPES,
            "dpd_string":      acct.get("PaymentHistory") or acct.get("DPD_String"),
            "balance_history": json.dumps(acct.get("BalanceHistory")) if acct.get("BalanceHistory") else None,
            "bureau_source":   "Experian",
        })

    inquiries = []
    raw_inq = root.get("Enquiries", {}).get("Enquiry", root.get("Inquiries", []))
    if isinstance(raw_inq, dict): raw_inq = [raw_inq]
    for inq in (raw_inq or []):
        raw_type = inq.get("InquiryPurpose") or inq.get("LoanType") or ""
        lt = EXPERIAN_LOAN_MAP.get(raw_type, raw_type or "Unknown")
        inquiries.append({
            "customer_id":    inq.get("CustomerId") or inq.get("UniqueID"),
            "member_id":      inq.get("SubscriberId") or inq.get("MemberId"),
            "ownership_type": inq.get("OwnershipType"),
            "inquiry_date":   inq.get("InquiryDate") or inq.get("Date"),
            "inquiry_amount": _f(inq.get("InquiryAmount") or inq.get("Amount")),
            "inquiry_purpose": raw_type,
            "loan_type":      lt,
            "lender_name":    inq.get("Institution") or inq.get("Lender"),
            "is_secured":     lt in SECURED_TYPES,
            "bureau_source":  "Experian",
        })

    return {"applicant": applicant, "accounts": accounts, "inquiries": inquiries}


def _parse_dpd(val):
    try: return int(str(val).strip().lstrip("0") or "0")
    except: return 0

def _status_from_dpd(dpd):
    if dpd >= 90: return "NPA"
    return "Active"

def _f(v, default=0.0):
    try: return float(v or 0)
    except: return default

def _i(v, default=0):
    try: return int(v or 0)
    except: return default

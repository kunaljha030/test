#!/usr/bin/env python3
"""
Integration Test for Phase 3: Frontend & Backend Integration
Tests that all components work together properly
"""

import sys
import json

def test_imports():
    """Test that all modules import correctly."""
    print("🧪 Testing imports...")
    try:
        from services.variable_generator import generate_all_variables, estimate_variable_count
        print("  ✓ variable_generator imports")
        
        from bureau.feature_engine import run_features
        print("  ✓ feature_engine imports")
        
        from bureau.behavioral_engine import payment_consistency_score
        print("  ✓ behavioral_engine imports")
        
        return True
    except Exception as e:
        print(f"  ✗ Import error: {e}")
        return False


def test_variable_generation():
    """Test that variables generate correctly."""
    print("\n🧪 Testing variable generation...")
    try:
        from services.variable_generator import generate_all_variables, estimate_variable_count
        
        # Test full generation
        all_vars = generate_all_variables()
        print(f"  ✓ Generated {len(all_vars)} total variables")
        
        # Test estimate
        estimate = estimate_variable_count()
        print(f"  ✓ Estimated {estimate} variables")
        
        # Test sample variable structure
        if all_vars:
            sample = all_vars[0]
            required_keys = ["name", "variable_type", "sub_category", "measure", "aggregation"]
            missing_keys = [k for k in required_keys if k not in sample]
            
            if missing_keys:
                print(f"  ✗ Sample variable missing keys: {missing_keys}")
                return False
            
            print(f"  ✓ Sample variable structure: {sample['name']}")
        
        # Test subset filtering
        enquiry_vars = [v for v in all_vars if "Enquiry" in v.get("variable_type", "")]
        if enquiry_vars:
            print(f"  ✓ Enquiry subset: {len(enquiry_vars)} variables")
        
        return True
    except Exception as e:
        print(f"  ✗ Generation error: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_types():
    """Test variable type distribution."""
    print("\n🧪 Testing variable type distribution...")
    try:
        from services.variable_generator import generate_all_variables
        
        all_vars = generate_all_variables()
        
        # Count by type
        type_counts = {}
        for v in all_vars:
            vtype = v.get("variable_type", "Other")
            type_counts[vtype] = type_counts.get(vtype, 0) + 1
        
        total = sum(type_counts.values())
        print(f"  Total: {total}")
        
        for vtype, count in sorted(type_counts.items(), key=lambda x: x[1], reverse=True):
            pct = (count / total * 100) if total > 0 else 0
            print(f"    {vtype}: {count:,} ({pct:.1f}%)")
        
        # Expected distribution
        expected_types = {
            "Enquiry": 1800,
            "Trade": 3200,
            "Account": 2400,
            "Trade History": 600,
            "Cross-Product": 128,
        }
        
        for vtype, expected in expected_types.items():
            actual = type_counts.get(vtype, 0)
            status = "✓" if actual == expected else "⚠" if actual > expected * 0.8 else "✗"
            print(f"  {status} {vtype}: expected {expected}, got {actual}")
        
        return True
    except Exception as e:
        print(f"  ✗ Type distribution error: {e}")
        return False


def test_production_subset():
    """Test production subset generation."""
    print("\n🧪 Testing production subset...")
    try:
        from services.variable_generator import generate_all_variables
        
        all_vars = generate_all_variables()
        
        # Simulate production curation
        var_by_type = {}
        for v in all_vars:
            vtype = v.get("variable_type", "Other")
            if vtype not in var_by_type:
                var_by_type[vtype] = []
            var_by_type[vtype].append(v)
        
        per_type = 1200 // len(var_by_type) if var_by_type else 1200
        production_vars = []
        for vtype, vars_list in var_by_type.items():
            production_vars.extend(vars_list[:per_type])
        
        production_vars = production_vars[:1200]
        
        print(f"  ✓ Production subset: {len(production_vars)} variables")
        
        # Breakdown
        type_dist = {}
        for v in production_vars:
            vtype = v.get("variable_type", "Other")
            type_dist[vtype] = type_dist.get(vtype, 0) + 1
        
        print(f"    Breakdown by type:")
        for vtype, count in sorted(type_dist.items()):
            print(f"      {vtype}: {count}")
        
        return True
    except Exception as e:
        print(f"  ✗ Production subset error: {e}")
        return False


def test_api_structure():
    """Test that API endpoints are properly structured."""
    print("\n🧪 Testing API structure...")
    try:
        # Check that router file exists and has correct structure
        with open("routers/variable_management.py", "r", encoding="utf-8") as f:
            content = f.read()
        
        endpoints = [
            "GET /api/variables/generate",
            "GET /api/variables/list",
            "GET /api/variables/production",
            "GET /api/variables/{id}/details",
            "POST /api/variables/bulk-create",
            "POST /api/variables/execute",
            "GET /api/variables/batch/{batch_id}",
            "GET /api/variables/batch/{batch_id}/results",
            "POST /api/variables/compare",
        ]
        
        checks = {
            "/generate": "@router.get(\"/generate\")" in content,
            "/list": "@router.get(\"/list\")" in content,
            "/production": "@router.get(\"/production\")" in content,
            "/bulk-create": "@router.post(\"/bulk-create\")" in content,
            "/execute": "@router.post(\"/execute\")" in content,
            "/batch/": "@router.get(\"/batch/{batch_id}\")" in content or "@router.get(\"/batch/" in content,
            "compare": "@router.post(\"/compare\")" in content,
        }
        
        for endpoint, exists in checks.items():
            status = "✓" if exists else "✗"
            print(f"  {status} {endpoint}")
            if not exists:
                return False
        
        print(f"  ✓ All {len(checks)} endpoint handlers present")
        return True
    except Exception as e:
        print(f"  ✗ API structure error: {e}")
        return False


def test_frontend_structure():
    """Test that frontend dashboard is properly structured."""
    print("\n🧪 Testing frontend structure...")
    try:
        with open("../frontend/dashboard.html", "r", encoding="utf-8") as f:
            content = f.read()
        
        required_elements = [
            ("Header", "<h1>🚀 Variable Studio</h1>"),
            ("Stats Cards", "id=\"total-vars\""),
            ("Tabs", "class=\"tabs\""),
            ("Variable Browser Tab", "id=\"browser\""),
            ("Generator Tab", "id=\"generator\""),
            ("Execution Tab", "id=\"execution\""),
            ("Results Tab", "id=\"results\""),
            ("Comparison Tab", "id=\"comparison\""),
            ("Table Structure", "<table>"),
            ("API Calls", "fetch('/api/variables"),
            ("Modal", "id=\"generateModal\""),
            ("Styling", "body {"),
        ]
        
        for element_name, search_str in required_elements:
            if search_str in content:
                print(f"  ✓ {element_name}")
            else:
                print(f"  ✗ {element_name} NOT FOUND")
                return False
        
        # Count features
        api_calls = content.count("fetch('/api/variables")
        print(f"  ✓ Found {api_calls} API calls")
        
        return True
    except FileNotFoundError:
        print(f"  ✗ dashboard.html not found")
        return False
    except Exception as e:
        print(f"  ✗ Frontend structure error: {e}")
        return False


def test_main_py_integration():
    """Test that main.py properly includes new router."""
    print("\n🧪 Testing main.py integration...")
    try:
        with open("main.py", "r", encoding="utf-8") as f:
            content = f.read()
        
        checks = {
            "Router Import": "from routers.variable_management import" in content,
            "Router Registration": "app.include_router(var_mgmt_router" in content,
            "API Prefix": "prefix=\"/api/variables\"" in content,
            "Dashboard Endpoint": "@app.get(\"/dashboard.html\"" in content or "app.mount" in content,
        }
        
        for check_name, result in checks.items():
            status = "✓" if result else "✗"
            print(f"  {status} {check_name}")
            if not result:
                return False
        
        return True
    except Exception as e:
        print(f"  ✗ main.py integration error: {e}")
        return False


def main():
    """Run all integration tests."""
    print("\n" + "="*60)
    print("  PHASE 3 INTEGRATION TEST SUITE")
    print("="*60)
    
    results = []
    
    # Run tests
    results.append(("Imports", test_imports()))
    results.append(("Variable Generation", test_variable_generation()))
    results.append(("Type Distribution", test_types()))
    results.append(("Production Subset", test_production_subset()))
    results.append(("API Structure", test_api_structure()))
    results.append(("Frontend Structure", test_frontend_structure()))
    results.append(("Main.py Integration", test_main_py_integration()))
    
    # Summary
    print("\n" + "="*60)
    print("  TEST SUMMARY")
    print("="*60)
    
    passed = sum(1 for _, result in results if result)
    total = len(results)
    
    for test_name, result in results:
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"  {status}: {test_name}")
    
    print(f"\n  Total: {passed}/{total} tests passed")
    
    if passed == total:
        print("\n  🎉 ALL TESTS PASSED - PHASE 3 COMPLETE!")
        return 0
    else:
        print(f"\n  ⚠️  {total - passed} test(s) failed")
        return 1


if __name__ == "__main__":
    sys.exit(main())

"""
routers/bureau.py
Bureau Workflow Endpoints:
  POST /bureau/upload          — Upload bureau file (CIBIL/Experian/CRIF/Equifax)
  GET  /bureau/runs/{build_id} — List execution runs for a build
  GET  /bureau/runs/{run_id}/outputs — Get feature outputs
  GET  /bureau/runs/{run_id}/export  — Export Python/PySpark code
  GET  /bureau/runs/{run_id}/summary — Execution summary
"""
import os
import shutil
from datetime import datetime
from fastapi import APIRouter, Depends, UploadFile, File, Form, Query, HTTPException
from sqlalchemy.orm import Session

from db.database import get_db
from db import models
from core.config import settings
from bureau import normalizer
from bureau.parsers import cibil_parser, experian_parser, crif_parser, equifax_parser
from bureau.code_exporter import export_python, export_pyspark
from fastapi.responses import PlainTextResponse

router = APIRouter(prefix="/bureau")

PARSERS = {
    "CIBIL":   cibil_parser,
    "Experian": experian_parser,
    "CRIF":    crif_parser,
    "Equifax": equifax_parser,
}


@router.post("/upload")
async def upload_bureau_file(
    build_name: str  = Form(...),
    owner: str       = Form(...),
    bureau: str      = Form(...),
    file: UploadFile = File(...),
    db: Session      = Depends(get_db),
):
    """
    Step 1-3 of Bureau Workflow:
    Upload → Parse → Normalize → Store in normalized tables
    """
    if bureau not in PARSERS:
        raise HTTPException(status_code=400, detail=f"Bureau must be one of: {list(PARSERS.keys())}")

    # ── Find build ─────────────────────────────────────────────────────
    build = db.query(models.Build).filter(
        models.Build.name == build_name,
        models.Build.owner == owner
    ).first()
    if not build:
        raise HTTPException(status_code=404, detail=f"Build '{build_name}' not found")

    # ── Save uploaded file ─────────────────────────────────────────────
    os.makedirs(settings.UPLOAD_DIR, exist_ok=True)
    safe_name = f"{build.id}_{bureau}_{file.filename}"
    file_path = os.path.join(settings.UPLOAD_DIR, safe_name)
    with open(file_path, "wb") as f:
        shutil.copyfileobj(file.file, f)

    # ── Create execution run ───────────────────────────────────────────
    run = models.ExecutionRun(
        build_id=build.id,
        bureau=bureau,
        file_name=file.filename,
        parse_status="parsing",
    )
    db.add(run); db.commit(); db.refresh(run)

    # ── Step 2: Parse ──────────────────────────────────────────────────
    try:
        with open(file_path, "rb") as f:
            content = f.read()
        parsed = PARSERS[bureau].parse(content)

        if parsed.get("error"):
            run.parse_status = "error"
            run.error_message = parsed["error"]
            db.commit()
            raise HTTPException(status_code=422, detail=f"Parse error: {parsed['error']}")

    except HTTPException:
        raise
    except Exception as e:
        run.parse_status = "error"
        run.error_message = str(e)
        db.commit()
        raise HTTPException(status_code=500, detail=f"Failed to parse file: {str(e)}")

    # ── Step 3: Normalize → store ──────────────────────────────────────
    try:
        normalizer.normalize_and_store(db, run, parsed)
        run.parse_status = "normalized"
        run.finished_at  = datetime.utcnow()
        db.commit()
    except Exception as e:
        run.parse_status = "error"
        run.error_message = str(e)
        db.commit()
        raise HTTPException(status_code=500, detail=f"Normalization failed: {str(e)}")

    # ── Summary ────────────────────────────────────────────────────────
    n_accounts  = db.query(models.NormalizedAccount).filter_by(run_id=run.id).count()
    n_inquiries = db.query(models.NormalizedInquiry).filter_by(run_id=run.id).count()
    n_applicants = db.query(models.NormalizedApplicant).filter_by(run_id=run.id).count()

    return {
        "message": f"{bureau} file parsed and normalized successfully",
        "run_id": run.id,
        "bureau": bureau,
        "file_name": file.filename,
        "parse_status": "normalized",
        "normalized_applicants": n_applicants,
        "normalized_accounts": n_accounts,
        "normalized_inquiries": n_inquiries,
        "next_step": f"Call POST /runBatch with build_name='{build_name}' to execute features",
    }


@router.get("/runs")
def list_runs(build_id: int = Query(...), db: Session = Depends(get_db)):
    """List all execution runs for a build"""
    runs = db.query(models.ExecutionRun).filter_by(build_id=build_id)\
              .order_by(models.ExecutionRun.started_at.desc()).all()
    return {
        "runs": [
            {
                "id": r.id,
                "bureau": r.bureau,
                "file_name": r.file_name,
                "parse_status": r.parse_status,
                "error_message": r.error_message,
                "started_at": r.started_at.isoformat() if r.started_at else None,
                "finished_at": r.finished_at.isoformat() if r.finished_at else None,
                "output_count": db.query(models.FeatureOutput).filter_by(run_id=r.id).count(),
            }
            for r in runs
        ]
    }


@router.get("/runs/{run_id}/outputs")
def get_outputs(run_id: int, customer_id: str = Query(None),
                feature_name: str = Query(None),
                status: str = Query(None),
                skip: int = 0, limit: int = 500,
                db: Session = Depends(get_db)):
    """Feature Output Table: customer_id + feature_name + feature_value"""
    q = db.query(models.FeatureOutput).filter_by(run_id=run_id)
    if customer_id:  q = q.filter_by(customer_id=customer_id)
    if feature_name: q = q.filter_by(feature_name=feature_name)
    if status:       q = q.filter_by(status=status)

    total  = q.count()
    items  = q.offset(skip).limit(limit).all()
    ready   = db.query(models.FeatureOutput).filter_by(run_id=run_id, status="ready").count()
    skipped = db.query(models.FeatureOutput).filter_by(run_id=run_id, status="skipped").count()

    return {
        "run_id": run_id,
        "total": total,
        "ready": ready,
        "skipped": skipped,
        "items": [
            {
                "customer_id":   o.customer_id,
                "feature_name":  o.feature_name,
                "feature_value": o.feature_value,
                "status":        o.status,
                "skip_reason":   o.skip_reason,
            }
            for o in items
        ],
    }


@router.get("/runs/{run_id}/summary")
def get_run_summary(run_id: int, db: Session = Depends(get_db)):
    """Execution Summary: ready / skipped / invalid + required column checks"""
    run = db.query(models.ExecutionRun).filter_by(id=run_id).first()
    if not run:
        raise HTTPException(status_code=404, detail="Run not found")

    outputs  = db.query(models.FeatureOutput).filter_by(run_id=run_id).all()
    ready    = [o for o in outputs if o.status == "ready"]
    skipped  = [o for o in outputs if o.status == "skipped"]
    invalid  = [o for o in outputs if o.status == "invalid"]
    customers = {o.customer_id for o in outputs}

    # Group skipped by reason
    skip_reasons: dict = {}
    for o in skipped:
        r = o.skip_reason or "unknown"
        skip_reasons[r] = skip_reasons.get(r, 0) + 1

    return {
        "run_id": run_id,
        "bureau": run.bureau,
        "file_name": run.file_name,
        "parse_status": run.parse_status,
        "started_at": run.started_at.isoformat() if run.started_at else None,
        "finished_at": run.finished_at.isoformat() if run.finished_at else None,
        "unique_customers": len(customers),
        "ready_count": len(ready),
        "skipped_count": len(skipped),
        "invalid_count": len(invalid),
        "skip_reasons": skip_reasons,
        "normalized_accounts":  db.query(models.NormalizedAccount).filter_by(run_id=run_id).count(),
        "normalized_inquiries": db.query(models.NormalizedInquiry).filter_by(run_id=run_id).count(),
    }


@router.get("/runs/{run_id}/export/python", response_class=PlainTextResponse)
def export_python_code(run_id: int, db: Session = Depends(get_db)):
    """Code Export — Python/Pandas"""
    run = db.query(models.ExecutionRun).filter_by(id=run_id).first()
    if not run:
        raise HTTPException(status_code=404, detail="Run not found")
    variables = db.query(models.Variable).filter_by(build_id=run.build_id).all()
    return export_python(variables)


@router.get("/runs/{run_id}/export/pyspark", response_class=PlainTextResponse)
def export_pyspark_code(run_id: int, db: Session = Depends(get_db)):
    """Code Export — PySpark"""
    run = db.query(models.ExecutionRun).filter_by(id=run_id).first()
    if not run:
        raise HTTPException(status_code=404, detail="Run not found")
    variables = db.query(models.Variable).filter_by(build_id=run.build_id).all()
    return export_pyspark(variables)


@router.get("/normalized/{run_id}/accounts")
def get_normalized_accounts(run_id: int, customer_id: str = Query(None),
                             skip: int = 0, limit: int = 200,
                             db: Session = Depends(get_db)):
    """View normalized_accounts table for a run"""
    q = db.query(models.NormalizedAccount).filter_by(run_id=run_id)
    if customer_id: q = q.filter_by(customer_id=customer_id)
    items = q.offset(skip).limit(limit).all()
    return {
        "total": q.count(),
        "accounts": [
            {
                "customer_id":    a.customer_id,
                "account_number": a.account_number,
                "lender_name":    a.lender_name,
                "loan_type":      a.loan_type,
                "account_status": a.account_status,
                "ownership_type": a.ownership_type,
                "sanction_amount": a.sanction_amount,
                "current_balance": a.current_balance,
                "overdue_amount":  a.overdue_amount,
                "emi_amount":      a.emi_amount,
                "credit_limit":    a.credit_limit,
                "dpd":             a.dpd,
                "date_reported":   a.date_reported,
                "is_secured":      a.is_secured,
                "bureau_source":   a.bureau_source,
            }
            for a in items
        ],
    }


@router.get("/normalized/{run_id}/inquiries")
def get_normalized_inquiries(
    run_id: int,
    customer_id: str = Query(None),
    loan_type: str = Query(None, description="Example: PL, CC, HL"),
    months: int = Query(None, ge=1, le=120, description="Filter enquiries in last N months"),
    distinct_customers: bool = Query(False, description="Return unique customers instead of raw inquiry rows"),
    skip: int = 0,
    limit: int = 200,
    db: Session = Depends(get_db),
):
    """View normalized_inquiries table for a run, with optional loan-type and month filters."""
    q = db.query(models.NormalizedInquiry).filter_by(run_id=run_id)
    if customer_id:
        q = q.filter_by(customer_id=customer_id)

    items = q.all()

    if loan_type:
        requested_loan_type = loan_type.strip().upper()
        items = [i for i in items if (i.loan_type or "").upper() == requested_loan_type]

    if months is not None:
        items = [i for i in items if _months_ago(i.inquiry_date) is not None and _months_ago(i.inquiry_date) <= months]

    total = len(items)

    if distinct_customers:
        grouped = {}
        for i in items:
            cid = i.customer_id or "UNKNOWN"
            bucket = grouped.setdefault(cid, {
                "customer_id": cid,
                "loan_type": i.loan_type,
                "bureau_source": i.bureau_source,
                "enquiry_count": 0,
                "latest_inquiry_date": i.inquiry_date,
            })
            bucket["enquiry_count"] += 1
            if (i.inquiry_date or "") > (bucket["latest_inquiry_date"] or ""):
                bucket["latest_inquiry_date"] = i.inquiry_date

        customer_rows = list(grouped.values())
        customer_rows = customer_rows[skip: skip + limit]
        return {
            "run_id": run_id,
            "filters": {
                "customer_id": customer_id,
                "loan_type": loan_type,
                "months": months,
                "distinct_customers": True,
            },
            "total_customers": len(grouped),
            "customers": customer_rows,
        }

    items = items[skip: skip + limit]
    return {
        "run_id": run_id,
        "filters": {
            "customer_id": customer_id,
            "loan_type": loan_type,
            "months": months,
            "distinct_customers": False,
        },
        "total": total,
        "inquiries": [
            {
                "customer_id":    i.customer_id,
                "member_id":      i.member_id,
                "ownership_type": i.ownership_type,
                "inquiry_date":   i.inquiry_date,
                "inquiry_amount": i.inquiry_amount,
                "inquiry_purpose": i.inquiry_purpose,
                "loan_type":      i.loan_type,
                "lender_name":    i.lender_name,
                "is_secured":     i.is_secured,
                "bureau_source":  i.bureau_source,
            }
            for i in items
        ],
    }


def _parse_date(date_str):
    if not date_str:
        return None
    for fmt in ("%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y", "%Y%m%d", "%m/%Y"):
        try:
            return datetime.strptime(str(date_str)[:10], fmt).date()
        except Exception:
            continue
    return None


def _months_ago(date_str):
    parsed = _parse_date(date_str)
    if parsed is None:
        return None
    now = datetime.utcnow().date()
    diff = (now.year - parsed.year) * 12 + (now.month - parsed.month)
    return max(0, diff)

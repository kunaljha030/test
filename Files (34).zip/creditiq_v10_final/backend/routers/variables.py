"""routers/variables.py — /addVariable, /runBatch, /variableMetadata"""
from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from db.database import get_db
from models.variable import VariableCreate
from services.variable_service import add_variable, delete_variable, get_variable_metadata
from services.batch_service import run_batch

router = APIRouter()


@router.get("/variableMetadata")
def variable_metadata():
    return get_variable_metadata()


@router.post("/addVariable")
def add_var(req: VariableCreate, db: Session = Depends(get_db)):
    return add_variable(db, req.build_name, req.owner, req.bureau,
                        req.file_type, req.file_identifier, req.variable)


@router.delete("/builds/{build_name}/variable/{variable_name}")
def del_var(build_name: str, variable_name: str, owner: str = Query(...), db: Session = Depends(get_db)):
    return delete_variable(db, build_name, variable_name, owner)


@router.post("/runBatch")
def run_batch_endpoint(payload: dict, db: Session = Depends(get_db)):
    build_name = payload.get("build_name")
    owner      = payload.get("owner", "guest")
    if not build_name:
        from fastapi import HTTPException
        raise HTTPException(status_code=400, detail="build_name is required")
    return run_batch(db, build_name, owner)

"""routers/auth.py — /login, /signup, /logout"""
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from db.database import get_db
from models.auth import LoginRequest, SignupRequest, TokenResponse, UserResponse
from services.auth_service import login, signup

router = APIRouter()


@router.post("/signup", response_model=dict)
def do_signup(req: SignupRequest, db: Session = Depends(get_db)):
    user = signup(db, req.email, req.username, req.password)
    return {"message": "Account created successfully", "user": {"id": user.id, "username": user.username, "email": user.email}}


@router.post("/login", response_model=dict)
def do_login(req: LoginRequest, db: Session = Depends(get_db)):
    token, user = login(db, req.username, req.password)
    return {
        "access_token": token,
        "token_type": "bearer",
        "user": {"id": user.id, "username": user.username, "email": user.email},
    }


@router.post("/logout")
def do_logout():
    # JWT is stateless; client drops the token
    return {"message": "Logged out successfully"}

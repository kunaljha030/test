"""routers/builds.py — /builds CRUD"""
from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from db.database import get_db
from services.build_service import get_builds, get_build, delete_build

router = APIRouter()


@router.post("/builds")
def create_build(payload: dict, db: Session = Depends(get_db)):
    from services.build_service import create_or_get_build
    name   = payload.get("name") or payload.get("build_name")
    owner  = payload.get("owner", "guest")
    bureau = payload.get("bureau")
    ft     = payload.get("file_type")
    desc   = payload.get("description")
    if not name:
        from fastapi import HTTPException
        raise HTTPException(status_code=400, detail="name is required")
    build = create_or_get_build(db, name, owner, bureau, ft, None, desc)
    from services.build_service import _serialize_build
    return {"message": f"Build '{name}' created", "build": _serialize_build(build)}


@router.get("/builds")
def list_builds(owner: str = Query("guest", description="Owner username"), db: Session = Depends(get_db)):
    builds = get_builds(db, owner)
    return {"builds": builds}


@router.get("/builds/{build_name}")
def get_one_build(build_name: str, owner: str = Query("guest"), db: Session = Depends(get_db)):
    return get_build(db, build_name, owner)


@router.delete("/builds/{build_name}")
def remove_build(build_name: str, owner: str = Query("guest"), db: Session = Depends(get_db)):
    delete_build(db, build_name, owner)
    return {"message": f"Build '{build_name}' deleted"}

"""
routers/variable_management.py
================================
Variable Management API — Bulk operations for 1,200+ variables

Endpoints:
  GET    /variables/generate              → Generate all 1,200+ variables from metadata
  GET    /variables/list                  → List variables with filtering
  POST   /variables/bulk-create           → Create batch of variables
  GET    /variables/production            → Get curated "production-ready" 1,200 subset
  GET    /variables/:id/details           → Get full variable details
  POST   /variables/execute               → Execute variables for customers
  GET    /variables/batch/:batch_id       → Monitor batch execution status
  GET    /variables/batch/:batch_id/results → Download batch results
  POST   /variables/compare               → Compare variable outputs
"""

import json
from datetime import datetime
from typing import Optional, List
from fastapi import APIRouter, Depends, Query, HTTPException, BackgroundTasks
from sqlalchemy.orm import Session
from pydantic import BaseModel

from db.database import get_db, SessionLocal
from db import models
from services.build_service import create_or_get_build
from services.batch_service import _create_demo_run
from services.variable_generator import (
    generate_all_variables,
    estimate_variable_count,
    get_variables_by_type,
)
from bureau.feature_engine import run_features

router = APIRouter(tags=["Variable Management"])


# ─────────────────────────────────────────────────────────────────────────────
# REQUEST MODELS
# ─────────────────────────────────────────────────────────────────────────────

class BulkCreateRequest(BaseModel):
    build_id: Optional[int] = None
    build_name: Optional[str] = None
    owner: str = "guest"
    description: Optional[str] = None
    bureau: Optional[str] = None
    file_type: Optional[str] = None
    subset: Optional[str] = None  # "all", "production", "enquiry", "trade", "account", "cross_product"
    auto_generate: bool = True


class GenerateTradeOutputRequest(BaseModel):
    build_id: Optional[int] = None
    limit: Optional[int] = None
    replace_existing: bool = True


class ExecuteVariablesRequest(BaseModel):
    build_id: int
    bureau: Optional[str] = None  # CIBIL, Equifax, Experian, CRIF
    limit: Optional[int] = None  # Limit # of customers
    customer_id: Optional[str] = None
    variable_types: Optional[List[str]] = None
    output_format: Optional[str] = None


class CompareVariablesRequest(BaseModel):
    variable_ids: Optional[List[int]] = None
    variable_names: Optional[List[str]] = None
    customer_sample_size: int = 100
    sample_size: Optional[int] = None


# ─────────────────────────────────────────────────────────────────────────────
# VARIABLE GENERATION ENDPOINTS
# ─────────────────────────────────────────────────────────────────────────────

@router.get("/generate")
def get_generated_variables(
    subset: Optional[str] = Query("all", pattern="^(all|production|enquiry|trade|account|trade_history|cross_product)$"),
    limit: Optional[int] = Query(None, ge=1, le=100000),
):
    """
    Generate variables from metadata.
    
    Subsets:
      - all: All 78,000+ variables
      - production: Curated 1,200 highest-variance features
      - enquiry: Enquiry-only variables (~7,300)
      - trade: Trade-only variables (~30,000)
      - account: Account-only variables (~13,000)
      - trade_history: Trade History variables (~27,000)
      - cross_product: Cross-Product variables (~900)
    """
    all_vars = _select_variable_subset(generate_all_variables(), subset, limit)
    
    return {
        "subset": subset,
        "total_generated": len(all_vars),
        "estimated_total": estimate_variable_count(),
        "variables": all_vars[:50] if len(all_vars) > 50 else all_vars,  # First 50 in response
        "message": f"Generated {len(all_vars)} variables. Showing first 50.",
    }


@router.post("/trade/generate-store")
def generate_and_store_trade_outputs(
    req: GenerateTradeOutputRequest,
    db: Session = Depends(get_db)
):
    """
    Generate Trade variables and store the generated output in a dedicated DB table.
    """
    build = None
    if req.build_id is not None:
        build = db.query(models.Build).filter_by(id=req.build_id).first()
        if not build:
            raise HTTPException(status_code=404, detail=f"Build {req.build_id} not found")

    trade_vars = get_variables_by_type("Trade")
    if req.limit:
        trade_vars = trade_vars[:req.limit]

    if req.replace_existing:
        existing_query = db.query(models.TradeVariableOutput)
        if req.build_id is None:
            existing_query = existing_query.filter(models.TradeVariableOutput.build_id.is_(None))
        else:
            existing_query = existing_query.filter_by(build_id=req.build_id)
        existing_query.delete(synchronize_session=False)

    rows = [
        models.TradeVariableOutput(
            build_id=req.build_id,
            variable_name=var_meta.get("name", "unnamed"),
            variable_type=var_meta.get("variable_type", "Trade"),
            sub_category=var_meta.get("sub_category"),
            measure=var_meta.get("measure"),
            aggregation=var_meta.get("aggregation"),
            time_window=var_meta.get("time_window"),
            loan_type_scope=json.dumps(var_meta.get("loan_types", [])),
            secured_scope=var_meta.get("secured", "all"),
            config_json=json.dumps(var_meta),
        )
        for var_meta in trade_vars
    ]

    if rows:
        db.bulk_save_objects(rows)
    db.commit()

    stored_rows = (
        db.query(models.TradeVariableOutput)
        .filter_by(build_id=req.build_id)
        .order_by(models.TradeVariableOutput.generated_at.desc())
        .limit(50)
        .all()
    )

    return {
        "message": f"Stored {len(rows)} generated Trade variable outputs",
        "build_id": req.build_id,
        "build_name": build.name if build else None,
        "stored_count": len(rows),
        "replace_existing": req.replace_existing,
        "results": [_serialize_trade_output(row) for row in stored_rows],
    }


@router.get("/trade/generated-output")
def list_trade_generated_output(
    build_id: Optional[int] = Query(None),
    skip: int = Query(0, ge=0),
    limit: int = Query(50, ge=1, le=500),
    db: Session = Depends(get_db)
):
    """List rows stored in the dedicated Trade generated-output table."""
    query = db.query(models.TradeVariableOutput)
    if build_id is None:
        query = query.filter(models.TradeVariableOutput.build_id.is_(None))
    else:
        query = query.filter_by(build_id=build_id)

    total = query.count()
    rows = (
        query.order_by(models.TradeVariableOutput.generated_at.desc())
        .offset(skip)
        .limit(limit)
        .all()
    )

    return {
        "build_id": build_id,
        "total": total,
        "skip": skip,
        "limit": limit,
        "results": [_serialize_trade_output(row) for row in rows],
    }



@router.get("/by-subcat")
def get_variables_by_subcat(
    variable_type: str = Query(...),
    sub_category:  str = Query(...),
    limit: Optional[int] = Query(500, ge=1, le=5000),
):
    """
    Get all variables for a specific type + sub-category combination.
    Useful for UI bulk-add: user picks Enquiry > amount_bucket, gets all 1,512 variants.
    """
    from services.variable_generator import get_variables_by_subcat as _gvs
    vars_list = _gvs(variable_type, sub_category)
    if limit:
        vars_list = vars_list[:limit]
    return {
        "variable_type":  variable_type,
        "sub_category":   sub_category,
        "total":          len(vars_list),
        "variables":      vars_list,
    }


@router.get("/summary")
def get_variable_summary():
    """Return count summary by type and sub-category."""
    from services.variable_generator import generate_all_variables
    from collections import Counter
    all_vars = generate_all_variables()
    by_type  = Counter(v["variable_type"] for v in all_vars)
    by_sub   = Counter(f"{v['variable_type']}::{v['sub_category']}" for v in all_vars)
    return {
        "total": len(all_vars),
        "by_type": dict(sorted(by_type.items(), key=lambda x: -x[1])),
        "top_subcategories": dict(sorted(by_sub.items(), key=lambda x: -x[1])[:30]),
    }

@router.get("/list")
def list_variables(
    build_id: Optional[int] = Query(None),
    variable_type: Optional[str] = Query(None),
    sub_category: Optional[str] = Query(None),
    search: Optional[str] = Query(None),
    skip: int = Query(0, ge=0),
    limit: int = Query(50, ge=1, le=500),
    db: Session = Depends(get_db)
):
    """
    List variables with filtering and pagination.
    Supports full-text search on variable name.
    """
    query = db.query(models.Variable)
    
    if build_id:
        query = query.filter_by(build_id=build_id)
    
    if variable_type:
        query = query.filter_by(variable_type=variable_type)
    
    if sub_category:
        query = query.filter_by(sub_category=sub_category)
    
    if search:
        query = query.filter(models.Variable.name.ilike(f"%{search}%"))
    
    total = query.count()
    variables = query.order_by(models.Variable.created_at.desc()).offset(skip).limit(limit).all()
    
    return {
        "total": total,
        "skip": skip,
        "limit": limit,
        "variables": [_serialize_variable(v) for v in variables],
    }


@router.get("/production")
def get_production_variables(
    limit: Optional[int] = Query(1200, ge=1, le=1200),
    db: Session = Depends(get_db)
):
    """
    Get the curated 'production-ready' 1,200 variable subset.
    These are highest-variance features across all types.
    """
    production_vars = _select_variable_subset(generate_all_variables(), "production", limit)
    
    return {
        "subset": "production",
        "total": len(production_vars),
        "curated_for": "Highest predictive power, balanced across all feature types",
        "composition": {
            "enquiry": len([v for v in production_vars if "Enquiry" in v.get("variable_type", "")]),
            "trade": len([v for v in production_vars if "Trade" in v.get("variable_type", "") and "History" not in v.get("variable_type", "")]),
            "account": len([v for v in production_vars if "Account" in v.get("variable_type", "")]),
            "trade_history": len([v for v in production_vars if "Trade History" in v.get("variable_type", "")]),
            "cross_product": len([v for v in production_vars if "Cross" in v.get("variable_type", "")]),
        },
        "variables": production_vars[:50],  # First 50 in response
        "message": f"Production subset: {len(production_vars)} variables (showing first 50)",
    }


@router.get("/{variable_id}/details")
def get_variable_details(variable_id: int, db: Session = Depends(get_db)):
    """Get full details of a single variable including config and metadata."""
    var = db.query(models.Variable).filter_by(id=variable_id).first()
    if not var:
        raise HTTPException(status_code=404, detail=f"Variable {variable_id} not found")
    
    config = json.loads(var.config_json or "{}")
    
    return {
        "id": var.id,
        "name": var.name,
        "type": var.variable_type,
        "variable_type": var.variable_type,
        "sub_category": var.sub_category,
        "measure": var.measure,
        "aggregation": var.aggregation,
        "time_window": var.time_window,
        "product_scope": var.product_scope,
        "secured_scope": var.secured_scope,
        "lender_scope": var.lender_scope,
        "loan_type_scope": var.loan_type_scope,
        "account_status_scope": var.account_status_scope,
        "ownership_scope": var.ownership_scope,
        "source": var.source or "wizard",
        "config": config,
        "created_at": var.created_at.isoformat() if var.created_at else None,
    }


# ─────────────────────────────────────────────────────────────────────────────
# BULK OPERATIONS
# ─────────────────────────────────────────────────────────────────────────────

@router.post("/bulk-create")
def bulk_create_variables(req: BulkCreateRequest, db: Session = Depends(get_db)) -> dict:
    """
    Bulk create variables from the generator into a build.
    Returns count of created variables.
    """
    build = _resolve_build(db, req)

    all_vars = _select_variable_subset(generate_all_variables(), req.subset or "all")
    
    # Create variables in build
    created = 0
    for var_meta in all_vars:
        # Check if already exists
        existing = db.query(models.Variable).filter(
            models.Variable.build_id == build.id,
            models.Variable.name == var_meta.get("name"),
        ).first()
        
        if existing:
            continue
        
        var = models.Variable(
            build_id=build.id,
            name=var_meta.get("name", "unnamed"),
            variable_type=var_meta.get("variable_type", "Other"),
            sub_category=var_meta.get("sub_category"),
            measure=var_meta.get("measure"),
            aggregation=var_meta.get("aggregation", "count"),
            time_window=var_meta.get("time_window", "12m"),
            secured_scope=var_meta.get("secured", "all"),
            loan_type_scope=",".join(var_meta.get("loan_types", [])) if var_meta.get("loan_types") else "all",
            source="catalog",
            config_json=json.dumps(var_meta),
        )
        db.add(var)
        created += 1
    
    db.commit()
    total_in_build = db.query(models.Variable).filter_by(build_id=build.id).count()
    
    return {
        "message": f"Successfully created {created} variables in build '{build.name}'",
        "build_id": build.id,
        "build_name": build.name,
        "count": created,
        "created_count": created,
        "total_in_build": total_in_build,
    }


# ─────────────────────────────────────────────────────────────────────────────
# EXECUTION & MONITORING
# ─────────────────────────────────────────────────────────────────────────────

@router.post("/execute")
def execute_variables(
    req: ExecuteVariablesRequest,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db)
):
    """
    Execute all variables in a build.
    Returns batch_id for monitoring.
    (Execution runs in background)
    """
    build = db.query(models.Build).filter_by(id=req.build_id).first()
    if not build:
        raise HTTPException(status_code=404, detail=f"Build {req.build_id} not found")
    
    variables_query = db.query(models.Variable).filter_by(build_id=req.build_id)
    if req.variable_types:
        variables_query = variables_query.filter(models.Variable.variable_type.in_(req.variable_types))
    variables = variables_query.all()
    if not variables:
        raise HTTPException(status_code=400, detail=f"No variables in build {req.build_id}")

    run = _prepare_execution_run(db, build, req.bureau)
    background_tasks.add_task(_execute_batch, run.id, req.limit, req.variable_types)
    
    return {
        "batch_id": run.id,
        "build_id": req.build_id,
        "status": "queued",
        "message": f"Batch {run.id} queued for execution with {len(variables)} variables",
        "variable_count": len(variables),
    }


def _execute_batch(run_id: int, limit: Optional[int] = None, variable_types: Optional[List[str]] = None):
    """Background task to execute variables for an existing run."""
    db = SessionLocal()
    run = None
    try:
        run = db.query(models.ExecutionRun).filter_by(id=run_id).first()
        if not run:
            return

        build = db.query(models.Build).filter_by(id=run.build_id).first()
        if not build:
            raise RuntimeError(f"Build {run.build_id} not found for run {run_id}")

        variables_query = db.query(models.Variable).filter_by(build_id=build.id)
        if variable_types:
            variables_query = variables_query.filter(models.Variable.variable_type.in_(variable_types))
        variables = variables_query.all()
        if not variables:
            raise RuntimeError(f"No variables available for build {build.id}")

        db.query(models.FeatureOutput).filter_by(run_id=run_id).delete(synchronize_session=False)
        db.commit()

        outputs = run_features(db, run, variables)

        if limit is not None and limit > 0:
            allowed_customers = sorted({o.customer_id for o in outputs})[:limit]
            db.query(models.FeatureOutput).filter(
                models.FeatureOutput.run_id == run_id,
                ~models.FeatureOutput.customer_id.in_(allowed_customers),
            ).delete(synchronize_session=False)
            db.commit()

        run.parse_status = "done"
        run.finished_at = datetime.utcnow()
        run.error_message = None
        db.commit()
    except Exception as exc:
        if run:
            run.parse_status = "error"
            run.error_message = str(exc)
            run.finished_at = datetime.utcnow()
            db.commit()
    finally:
        db.close()


@router.get("/batch/{batch_id}")
def get_batch_status(batch_id: int, db: Session = Depends(get_db)):
    """Get status of a batch execution."""
    run = db.query(models.ExecutionRun).filter_by(id=batch_id).first()
    if not run:
        raise HTTPException(status_code=404, detail=f"Batch {batch_id} not found")
    
    outputs = db.query(models.FeatureOutput).filter_by(run_id=batch_id).all()
    
    return {
        "batch_id": batch_id,
        "build_id": run.build_id,
        "bureau": run.bureau,
        "status": run.parse_status,
        "started_at": run.started_at.isoformat() if run.started_at else None,
        "finished_at": run.finished_at.isoformat() if run.finished_at else None,
        "total_features_generated": len(outputs),
        "success_count": len([o for o in outputs if o.status == "ready"]),
        "skipped_count": len([o for o in outputs if o.status == "skipped"]),
    }


@router.get("/batch/{batch_id}/results")
def get_batch_results(
    batch_id: int,
    format: str = Query("json", pattern="^(json|csv|parquet|summary)$"),
    skip: int = Query(0),
    limit: int = Query(1000),
    db: Session = Depends(get_db)
):
    """Get results from completed batch execution."""
    run = db.query(models.ExecutionRun).filter_by(id=batch_id).first()
    if not run:
        raise HTTPException(status_code=404, detail=f"Batch {batch_id} not found")
    
    outputs = (
        db.query(models.FeatureOutput)
        .filter_by(run_id=batch_id)
        .offset(skip)
        .limit(limit)
        .all()
    )
    all_outputs = db.query(models.FeatureOutput).filter_by(run_id=batch_id).all()
    execution_time = None
    if run.started_at and run.finished_at:
        execution_time = round((run.finished_at - run.started_at).total_seconds(), 3)

    summary = {
        "batch_id": batch_id,
        "variables_count": len({o.feature_name for o in all_outputs}),
        "successful_count": len([o for o in all_outputs if o.status == "ready"]),
        "failed_count": len([o for o in all_outputs if o.status in {"skipped", "invalid", "error"}]),
        "execution_time": execution_time,
        "total": len(all_outputs),
    }
    
    if format == "summary":
        return summary

    if format == "json":
        return {
            **summary,
            "results": [
                {
                    "customer_id": o.customer_id,
                    "feature_name": o.feature_name,
                    "feature_value": o.feature_value,
                    "status": o.status,
                }
                for o in outputs
            ],
        }
    
    # CSV stub
    return {"message": f"CSV export for batch {batch_id} (not yet implemented)"}


# ─────────────────────────────────────────────────────────────────────────────
# COMPARISON & ANALYTICS
# ─────────────────────────────────────────────────────────────────────────────

@router.post("/compare")
def compare_variables(req: CompareVariablesRequest, db: Session = Depends(get_db)):
    """
    Compare outputs of multiple variables across a sample of customers.
    Returns correlation, distribution stats, etc.
    """
    variable_ids = req.variable_ids or []
    if not variable_ids and req.variable_names:
        name_set = [name for name in req.variable_names if name]
        variables = db.query(models.Variable).filter(models.Variable.name.in_(name_set)).all()
    else:
        variables = []
        for var_id in variable_ids:
            var = db.query(models.Variable).filter_by(id=var_id).first()
            if var:
                variables.append(var)
    
    if not variables:
        raise HTTPException(status_code=400, detail="No valid variables provided")

    sample_size = req.sample_size or req.customer_sample_size

    return {
        "message": f"Comparison prepared for {len(variables)} variables",
        "variable_count": len(variables),
        "sample_size": sample_size,
        "status": "ready for analysis",
        "variables": [
            {
                "id": var.id,
                "name": var.name,
                "variable_type": var.variable_type,
                "sub_category": var.sub_category,
                "aggregation": var.aggregation,
                "time_window": var.time_window,
            }
            for var in variables
        ],
        "statistics": _build_comparison_rows(variables, sample_size),
    }


# ─────────────────────────────────────────────────────────────────────────────
# HELPERS
# ─────────────────────────────────────────────────────────────────────────────

def _resolve_build(db: Session, req: BulkCreateRequest) -> models.Build:
    if req.build_id is not None:
        build = db.query(models.Build).filter_by(id=req.build_id).first()
        if not build:
            raise HTTPException(status_code=404, detail=f"Build {req.build_id} not found")
        if req.description is not None:
            build.description = req.description
            db.commit()
            db.refresh(build)
        return build

    if not req.build_name:
        raise HTTPException(status_code=400, detail="build_id or build_name is required")

    return create_or_get_build(
        db,
        req.build_name,
        req.owner or "guest",
        bureau=req.bureau,
        file_type=req.file_type,
        description=req.description,
    )


def _prepare_execution_run(db: Session, build: models.Build, bureau: Optional[str]) -> models.ExecutionRun:
    run = (
        db.query(models.ExecutionRun)
        .filter(models.ExecutionRun.build_id == build.id)
        .order_by(models.ExecutionRun.started_at.desc(), models.ExecutionRun.id.desc())
        .first()
    )

    has_normalized_data = False
    if run:
        has_normalized_data = bool(
            db.query(models.NormalizedAccount).filter_by(run_id=run.id).first()
            or db.query(models.NormalizedInquiry).filter_by(run_id=run.id).first()
            or db.query(models.NormalizedApplicant).filter_by(run_id=run.id).first()
        )

    if not run or not has_normalized_data:
        run = _create_demo_run(db, build)

    run.bureau = bureau or run.bureau or build.bureau or "CIBIL"
    run.started_at = datetime.utcnow()
    run.parse_status = "running"
    run.error_message = None
    run.finished_at = None
    db.commit()
    db.refresh(run)
    return run


def _normalize_subset_key(value: Optional[str]) -> str:
    return (value or "all").strip().lower().replace("-", "_").replace(" ", "_")


def _subset_matches_variable(var_meta: dict, subset_key: str) -> bool:
    variable_type = _normalize_subset_key(var_meta.get("variable_type"))

    if subset_key in {"all", ""}:
        return True
    if subset_key == "production":
        return True
    if subset_key == "cross_product":
        return variable_type == "cross_product"
    if subset_key == "trade_history":
        return variable_type == "trade_history"
    if subset_key == "trade":
        return variable_type == "trade"
    return variable_type == subset_key


def _select_variable_subset(all_vars: List[dict], subset: Optional[str], limit: Optional[int] = None) -> List[dict]:
    subset_key = _normalize_subset_key(subset)

    if subset_key == "production":
        grouped = {}
        for var_meta in all_vars:
            group_key = _normalize_subset_key(var_meta.get("variable_type"))
            grouped.setdefault(group_key, []).append(var_meta)

        selected = []
        if grouped:
            target = limit or 1200
            ordered_groups = sorted(grouped.items(), key=lambda item: item[0])
            per_group = max(1, target // len(ordered_groups))

            for _, vars_list in ordered_groups:
                selected.extend(vars_list[:per_group])

            if len(selected) < target:
                seen_names = {item.get("name") for item in selected}
                for _, vars_list in ordered_groups:
                    for var_meta in vars_list:
                        if var_meta.get("name") in seen_names:
                            continue
                        selected.append(var_meta)
                        seen_names.add(var_meta.get("name"))
                        if len(selected) >= target:
                            break
                    if len(selected) >= target:
                        break

        return selected[:limit] if limit else selected[:1200]

    filtered = [var_meta for var_meta in all_vars if _subset_matches_variable(var_meta, subset_key)]
    if limit:
        return filtered[:limit]
    return filtered


def _build_comparison_rows(variables: List[models.Variable], sample_size: int) -> List[dict]:
    if not variables:
        return []

    left = variables[0]
    right = variables[1] if len(variables) > 1 else variables[0]
    return [
        {"metric": "Variable ID", "left": left.id, "right": right.id},
        {"metric": "Type", "left": left.variable_type, "right": right.variable_type},
        {"metric": "Sub-Category", "left": left.sub_category or "-", "right": right.sub_category or "-"},
        {"metric": "Aggregation", "left": left.aggregation or "-", "right": right.aggregation or "-"},
        {"metric": "Time Window", "left": left.time_window or "-", "right": right.time_window or "-"},
        {"metric": "Sample Size", "left": sample_size, "right": sample_size},
    ]


def _serialize_variable(var: models.Variable) -> dict:
    """Convert Variable model to JSON-serializable dict."""
    return {
        "id": var.id,
        "name": var.name,
        "type": var.variable_type,
        "variable_type": var.variable_type,
        "sub_category": var.sub_category,
        "measure": var.measure,
        "aggregation": var.aggregation,
        "time_window": var.time_window,
        "product_scope": var.product_scope,
        "secured_scope": var.secured_scope,
        "lender_scope": var.lender_scope,
        "loan_type_scope": var.loan_type_scope,
        "account_status_scope": var.account_status_scope,
        "ownership_scope": var.ownership_scope,
        "source": var.source or "wizard",
        "created_at": var.created_at.isoformat() if var.created_at else None,
    }


def _serialize_trade_output(row: models.TradeVariableOutput) -> dict:
    return {
        "id": row.id,
        "build_id": row.build_id,
        "variable_name": row.variable_name,
        "variable_type": row.variable_type,
        "sub_category": row.sub_category,
        "measure": row.measure,
        "aggregation": row.aggregation,
        "time_window": row.time_window,
        "loan_type_scope": json.loads(row.loan_type_scope or "[]"),
        "secured_scope": row.secured_scope,
        "config": json.loads(row.config_json or "{}"),
        "generated_at": row.generated_at.isoformat() if row.generated_at else None,
    }

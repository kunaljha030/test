"""routers/beneficiaries.py - Beneficiary CRUD endpoints."""
from typing import Optional

from fastapi import APIRouter, Depends, Query
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from db.database import get_db
from services.beneficiary_service import (
    create_beneficiary,
    delete_beneficiary,
    list_beneficiaries,
    update_beneficiary,
)


router = APIRouter(prefix="/beneficiaries", tags=["Beneficiaries"])


class BeneficiaryCreateRequest(BaseModel):
    owner: str = "guest"
    build_name: Optional[str] = None
    name: str = Field(..., min_length=1)
    bank_name: str = Field(..., min_length=1)
    account_number: str = Field(..., min_length=1)
    avatar_letter: Optional[str] = None
    avatar_color: Optional[str] = None


class BeneficiaryUpdateRequest(BaseModel):
    owner: str = "guest"
    build_name: Optional[str] = None
    name: Optional[str] = None
    bank_name: Optional[str] = None
    account_number: Optional[str] = None
    avatar_letter: Optional[str] = None
    avatar_color: Optional[str] = None


@router.get("")
def get_beneficiaries(
    owner: str = Query(...),
    build_name: Optional[str] = Query(None),
    db: Session = Depends(get_db),
):
    items = list_beneficiaries(db, owner=owner, build_name=build_name)
    return {"count": len(items), "beneficiaries": items}


@router.post("")
def add_beneficiary(req: BeneficiaryCreateRequest, db: Session = Depends(get_db)):
    item = create_beneficiary(
        db,
        owner=req.owner,
        build_name=req.build_name,
        name=req.name,
        bank_name=req.bank_name,
        account_number=req.account_number,
        avatar_letter=req.avatar_letter,
        avatar_color=req.avatar_color,
    )
    return {"message": "Beneficiary created", "beneficiary": item}


@router.put("/{beneficiary_id}")
def edit_beneficiary(beneficiary_id: int, req: BeneficiaryUpdateRequest, db: Session = Depends(get_db)):
    item = update_beneficiary(
        db,
        beneficiary_id,
        owner=req.owner,
        build_name=req.build_name,
        name=req.name,
        bank_name=req.bank_name,
        account_number=req.account_number,
        avatar_letter=req.avatar_letter,
        avatar_color=req.avatar_color,
    )
    return {"message": "Beneficiary updated", "beneficiary": item}


@router.delete("/{beneficiary_id}")
def remove_beneficiary(
    beneficiary_id: int,
    owner: str = Query(...),
    db: Session = Depends(get_db),
):
    delete_beneficiary(db, beneficiary_id, owner=owner)
    return {"message": "Beneficiary deleted"}

"""
routers/feature_builder.py
===========================
Feature Builder API — drives the dynamic cascading UI.

Endpoints
─────────
GET  /builder/metadata                  → Initial page load data (types, loan_types, etc.)
GET  /builder/cascade                   → Cascade: type → sub_cats, or type+sub_cat → full options
GET  /builder/auto-name                 → Auto-generate feature name from selections
POST /builder/variable                  → Save variable to a build
GET  /builder/variables                 → List variables for a build
DELETE /builder/variable/{id}           → Delete a variable
POST /builder/code-preview              → Preview Python + PySpark for a variable config
GET  /builder/export/python             → Export all Python code for a build
GET  /builder/export/pyspark            → Export all PySpark code for a build
GET  /builder/builds                    → List builds for an owner
POST /builder/build                     → Create a build
"""

import json
from fastapi import APIRouter, Depends, Query, HTTPException
from fastapi.responses import PlainTextResponse
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import Optional, List, Any

from db.database import get_db
from db import models
from services.cascade_metadata import (
    CASCADE, GLOBAL,
    get_types, get_sub_categories, get_measures,
    get_aggregations, get_scope_fields, get_threshold_config,
    get_full_cascade, build_feature_config, generate_feature_name,
)
from services.build_service import create_or_get_build, get_builds, _serialize_build
from services.output_build_service import (
    get_output_build_rows,
    materialize_variable_output_details,
    serialize_output_build,
)
from services.variable_service import _extract_scope_fields
from bureau.code_exporter import export_python, export_pyspark

router = APIRouter(prefix="/builder", tags=["Feature Builder"])


# ─────────────────────────────────────────────────────────────────────────────
# REQUEST MODELS
# ─────────────────────────────────────────────────────────────────────────────

class SaveVariableRequest(BaseModel):
    build_name:      str
    owner:           str
    bureau:          Optional[str] = None
    file_type:       Optional[str] = None
    file_identifier: Optional[str] = None
    variable:        dict = {}          # full selections from the builder UI
    auto_config:     bool = True        # if True, server builds config_json from selections


class CreateBuildRequest(BaseModel):
    name:        str
    owner:       str
    description: Optional[str] = None
    bureau:      Optional[str] = None


# ─────────────────────────────────────────────────────────────────────────────
# METADATA & CASCADE ENDPOINTS
# ─────────────────────────────────────────────────────────────────────────────

@router.get("/metadata")
def get_metadata():
    """
    Called once on page load.
    Returns everything needed to bootstrap the builder UI:
      types, time_windows, loan_types, account_statuses, secured_options, ownership_options
    """
    return {
        "types":             get_types(),
        "time_windows":      GLOBAL["time_windows"],
        "loan_types":        GLOBAL["loan_types"],
        "account_statuses":  GLOBAL["account_statuses"],
        "secured_options":   GLOBAL["secured_options"],
        "ownership_options": GLOBAL["ownership_options"],
        "aggregation_labels":GLOBAL["aggregation_labels"],
    }


@router.get("/cascade")
def cascade(
    type:         Optional[str] = Query(None, description="Variable type e.g. Enquiry"),
    sub_category: Optional[str] = Query(None, description="Sub-category e.g. volume"),
):
    """
    Step-by-step cascade API.

    /builder/cascade
        → returns all types (same as /metadata types)

    /builder/cascade?type=Enquiry
        → returns sub_categories for that type + scope_fields

    /builder/cascade?type=Enquiry&sub_category=volume
        → returns measures, aggregations, scope_fields, threshold config
    """
    if not type:
        return {"types": get_types()}

    if type not in CASCADE:
        raise HTTPException(status_code=400, detail=f"Unknown type: '{type}'. Valid: {list(CASCADE.keys())}")

    if not sub_category:
        return {
            "sub_categories": get_sub_categories(type),
            "scope_fields":   get_scope_fields(type),
        }

    # Validate sub_category
    valid_subcats = [s["value"] for s in get_sub_categories(type)]
    if sub_category not in valid_subcats:
        raise HTTPException(
            status_code=400,
            detail=f"Unknown sub_category '{sub_category}' for type '{type}'. Valid: {valid_subcats}"
        )

    return get_full_cascade(type, sub_category)


@router.get("/auto-name")
def auto_name(
    variable_type: str = Query(...),
    sub_category:  str = Query(...),
    aggregation:   str = Query(...),
    time_window:   str = Query("12m"),
    measure:       str = Query(""),
    dpd_op:        Optional[str] = Query(None),
    dpd_val:       Optional[int] = Query(None),
):
    """Auto-generate a feature name from the current builder selections."""
    name = generate_feature_name({
        "variable_type": variable_type,
        "sub_category":  sub_category,
        "aggregation":   aggregation,
        "time_window":   time_window,
        "measure":       measure,
        "dpd_op":        dpd_op,
        "dpd_val":       dpd_val,
    })
    return {"name": name}


# ─────────────────────────────────────────────────────────────────────────────
# VARIABLE CRUD
# ─────────────────────────────────────────────────────────────────────────────

@router.post("/variable")
def save_variable(req: SaveVariableRequest, db: Session = Depends(get_db)):
    """
    Save (create or update) a variable in a build.

    If auto_config=True (default), the server builds config_json from
    the selections using cascade_metadata.build_feature_config().
    """
    build = create_or_get_build(
        db, req.build_name, req.owner,
        bureau=req.bureau, file_type=req.file_type,
        file_identifier=req.file_identifier,
    )

    var_data = req.variable
    var_name = var_data.get("name") or generate_feature_name(var_data) or "unnamed_variable"

    # Build the config_json the feature engine understands
    if req.auto_config:
        config = build_feature_config(var_data)
        config["name"] = var_name
    else:
        config = var_data

    scope_fields = _extract_scope_fields(config)
    source = var_data.get("source", "wizard")

    # Upsert variable
    existing = db.query(models.Variable).filter(
        models.Variable.build_id == build.id,
        models.Variable.name     == var_name,
    ).first()

    if existing:
        existing.variable_type = var_data.get("variable_type", existing.variable_type)
        existing.sub_category  = var_data.get("sub_category",  existing.sub_category)
        existing.measure       = var_data.get("measure",        existing.measure)
        existing.aggregation   = var_data.get("aggregation",    existing.aggregation)
        existing.time_window   = var_data.get("time_window",    existing.time_window)
        existing.product_scope = scope_fields["product_scope"]
        existing.secured_scope = scope_fields["secured_scope"]
        existing.lender_scope = scope_fields["lender_scope"]
        existing.loan_type_scope = scope_fields["loan_type_scope"]
        existing.account_status_scope = scope_fields["account_status_scope"]
        existing.ownership_scope = scope_fields["ownership_scope"]
        existing.source = source
        existing.config_json   = json.dumps(config)
        db.commit()
        db.refresh(existing)
        output_build = materialize_variable_output_details(db, build, existing)
        return {
            "message":  f"Variable '{var_name}' updated in build '{req.build_name}'",
            "variable": _serialize_variable(existing),
            "build":    _serialize_build(build),
            "output_build": output_build,
        }

    var = models.Variable(
        name          = var_name,
        build_id      = build.id,
        variable_type = var_data.get("variable_type", "Other"),
        sub_category  = var_data.get("sub_category"),
        measure       = var_data.get("measure"),
        aggregation   = var_data.get("aggregation"),
        time_window   = var_data.get("time_window"),
        product_scope = scope_fields["product_scope"],
        secured_scope = scope_fields["secured_scope"],
        lender_scope = scope_fields["lender_scope"],
        loan_type_scope = scope_fields["loan_type_scope"],
        account_status_scope = scope_fields["account_status_scope"],
        ownership_scope = scope_fields["ownership_scope"],
        source = source,
        config_json   = json.dumps(config),
    )
    db.add(var)
    db.commit()
    db.refresh(var)
    db.refresh(build)
    output_build = materialize_variable_output_details(db, build, var)

    return {
        "message":  f"Variable '{var_name}' added to build '{req.build_name}'",
        "variable": _serialize_variable(var),
        "build":    _serialize_build(build),
        "output_build": output_build,
    }


@router.get("/variables")
def list_variables(build_id: int = Query(...), db: Session = Depends(get_db)):
    """List all variables for a build (with their full config)."""
    variables = (
        db.query(models.Variable)
        .filter_by(build_id=build_id)
        .order_by(models.Variable.created_at.desc())
        .all()
    )
    return {
        "build_id":  build_id,
        "count":     len(variables),
        "variables": [_serialize_variable(v) for v in variables],
    }


@router.get("/output-builds")
def list_output_builds(
    build_id: int = Query(...),
    variable_id: Optional[int] = Query(None),
    db: Session = Depends(get_db),
):
    rows = get_output_build_rows(db, build_id, variable_id)
    return {
        "build_id": build_id,
        "variable_id": variable_id,
        "count": len(rows),
        "rows": [serialize_output_build(row) for row in rows],
    }


@router.delete("/variable/{variable_id}")
def delete_variable(variable_id: int, db: Session = Depends(get_db)):
    """Delete a variable by ID."""
    var = db.query(models.Variable).filter_by(id=variable_id).first()
    if not var:
        raise HTTPException(status_code=404, detail=f"Variable {variable_id} not found")
    name = var.name
    db.delete(var)
    db.commit()
    return {"message": f"Variable '{name}' deleted", "deleted_id": variable_id}


# ─────────────────────────────────────────────────────────────────────────────
# CODE PREVIEW & EXPORT
# ─────────────────────────────────────────────────────────────────────────────

@router.post("/code-preview")
def code_preview(payload: dict):
    """
    Generate Python + PySpark code preview for a SINGLE variable config.
    Payload = the builder selections dict (same as SaveVariableRequest.variable).
    """
    var_name = payload.get("name") or generate_feature_name(payload) or "preview_variable"
    config   = build_feature_config(payload)
    config["name"] = var_name

    # Create a temporary Variable object (no DB write)
    temp_var = _TempVariable(var_name, payload.get("variable_type","Other"), config)

    return {
        "feature_name": var_name,
        "config":       config,
        "python":       _gen_python_single(var_name, config, payload.get("variable_type","")),
        "pyspark":      _gen_pyspark_single(var_name, config, payload.get("variable_type","")),
    }


@router.get("/export/python", response_class=PlainTextResponse)
def export_python_build(build_id: int = Query(...), db: Session = Depends(get_db)):
    """Export Python / Pandas code for ALL variables in a build."""
    variables = db.query(models.Variable).filter_by(build_id=build_id).all()
    if not variables:
        raise HTTPException(status_code=400, detail="Save at least one variable in the current build before exporting Python code.")
    return export_python(variables)


@router.get("/export/pyspark", response_class=PlainTextResponse)
def export_pyspark_build(build_id: int = Query(...), db: Session = Depends(get_db)):
    """Export PySpark code for ALL variables in a build."""
    variables = db.query(models.Variable).filter_by(build_id=build_id).all()
    if not variables:
        raise HTTPException(status_code=400, detail="Save at least one variable in the current build before exporting PySpark code.")
    return export_pyspark(variables)


# ─────────────────────────────────────────────────────────────────────────────
# BUILD MANAGEMENT
# ─────────────────────────────────────────────────────────────────────────────

@router.post("/build")
def create_build(req: CreateBuildRequest, db: Session = Depends(get_db)):
    """Create a new build (or return existing one)."""
    build = create_or_get_build(db, req.name, req.owner, description=req.description, bureau=req.bureau)
    return {"message": f"Build '{req.name}' ready", "build": _serialize_build(build)}


@router.get("/builds")
def list_builds(owner: str = Query(...), db: Session = Depends(get_db)):
    """List all builds for an owner."""
    return {"builds": get_builds(db, owner)}


# ─────────────────────────────────────────────────────────────────────────────
# HELPERS
# ─────────────────────────────────────────────────────────────────────────────

def _serialize_variable(v: models.Variable) -> dict:
    return {
        "id":            v.id,
        "name":          v.name,
        "variable_type": v.variable_type,
        "sub_category":  v.sub_category,
        "measure":       v.measure,
        "aggregation":   v.aggregation,
        "time_window":   v.time_window,
        "product_scope": v.product_scope,
        "secured_scope": v.secured_scope,
        "lender_scope": v.lender_scope,
        "loan_type_scope": v.loan_type_scope,
        "account_status_scope": v.account_status_scope,
        "ownership_scope": v.ownership_scope,
        "source":       v.source or "wizard",
        "config":        json.loads(v.config_json or "{}"),
        "created_at":    v.created_at.isoformat() if v.created_at else None,
    }


class _TempVariable:
    """Lightweight stand-in for models.Variable (no DB)."""
    def __init__(self, name, variable_type, config):
        self.name          = name
        self.variable_type = variable_type
        self.config_json   = json.dumps(config)


def _parse_window(w) -> int:
    try:
        return int(str(w).lower().replace("m", "").strip())
    except Exception:
        return 12


def _gen_python_single(name: str, cfg: dict, var_type: str) -> str:
    """Generate a self-contained Python/Pandas function for one variable."""
    agg         = cfg.get("aggregation", "count")
    window      = cfg.get("time_window", "12m")
    measure     = cfg.get("measure", "current_balance")
    w_months    = _parse_window(window)
    is_enquiry  = "enquiry" in var_type.lower()
    table       = "df_inquiries" if is_enquiry else "df_accounts"
    date_col    = "inquiry_date" if is_enquiry else "date_reported"
    col         = "inquiry_amount" if is_enquiry else measure

    loan_types  = []
    inquiry_purposes = []
    if is_enquiry:
        loan_types = cfg.get("filters", {}).get("product") or []
        inquiry_purposes = cfg.get("filters", {}).get("inquiry_purpose") or cfg.get("filters", {}).get("product_subtype") or []
    else:
        ts = cfg.get("trade_scope") or cfg.get("acc_scope") or {}
        loan_types = ts.get("loanType") or []
    if isinstance(inquiry_purposes, str):
        inquiry_purposes = [inquiry_purposes]

    dpd_thresh  = cfg.get("dpd_threshold")
    dpd_op_raw  = (cfg.get("conditions") or {}).get("dpd_op") or ">="
    is_util     = (cfg.get("sub_category") or cfg.get("variable_type","")).lower() in ("utilization",)
    util_num    = cfg.get("util_numerator", "current_balance")
    util_den    = cfg.get("util_denominator", "credit_limit")

    agg_map = {
        "count": f"    result = df.groupby('customer_id').size().rename('{name}')",
        "sum":   f"    result = df.groupby('customer_id')['{col}'].sum().rename('{name}')",
        "avg":   f"    result = df.groupby('customer_id')['{col}'].mean().rename('{name}')",
        "max":   f"    result = df.groupby('customer_id')['{col}'].max().rename('{name}')",
        "min":   f"    result = df.groupby('customer_id')['{col}'].min().rename('{name}')",
        "std":   f"    result = df.groupby('customer_id')['{col}'].std().rename('{name}')",
        "flag":  f"    result = (df.groupby('customer_id').size() > 0).astype(int).rename('{name}')",
    }

    lines = [
        f"def compute_{name}({table}: pd.DataFrame) -> pd.Series:",
        f"    '''",
        f"    Feature  : {name}",
        f"    Type     : {var_type}",
        f"    Sub-Cat  : {cfg.get('sub_category','')}",
        f"    Measure  : {measure}",
        f"    Agg      : {agg}",
        f"    Window   : {window}",
        f"    '''",
        f"    ref_date = pd.Timestamp.today()",
        f"    cutoff   = ref_date - pd.DateOffset(months={w_months})",
        f"    df = {table}.copy()",
        f"    df['{date_col}'] = pd.to_datetime(df['{date_col}'], errors='coerce')",
        f"    df = df[df['{date_col}'] >= cutoff]",
    ]

    if loan_types:
        lines.append(f"    df = df[df['loan_type'].isin({loan_types!r})]")
    if inquiry_purposes:
        lines.append(f"    df = df[df['inquiry_purpose'].isin({inquiry_purposes!r})]")

    if dpd_thresh:
        lines.append(f"    df = df[df['dpd'] {dpd_op_raw} {dpd_thresh}]")

    if is_util:
        lines += [
            f"    df['__util__'] = df['{util_num}'] / df['{util_den}'].replace(0, float('nan'))",
            f"    result = df.groupby('customer_id')['__util__'].{agg if agg != 'avg' else 'mean'}().rename('{name}')",
        ]
    else:
        lines.append(agg_map.get(agg, agg_map["count"]))

    lines.append(f"    return result.fillna(0)")
    return "\n".join(lines)


def _gen_pyspark_single(name: str, cfg: dict, var_type: str) -> str:
    """Generate a PySpark function for one variable."""
    agg        = cfg.get("aggregation", "count")
    window     = cfg.get("time_window", "12m")
    measure    = cfg.get("measure", "current_balance")
    w_months   = _parse_window(window)
    is_enquiry = "enquiry" in var_type.lower()
    table      = "df_inquiries" if is_enquiry else "df_accounts"
    date_col   = "inquiry_date"  if is_enquiry else "date_reported"
    col        = "inquiry_amount" if is_enquiry else measure

    loan_types = []
    inquiry_purposes = []
    if is_enquiry:
        loan_types = cfg.get("filters", {}).get("product") or []
        inquiry_purposes = cfg.get("filters", {}).get("inquiry_purpose") or cfg.get("filters", {}).get("product_subtype") or []
    else:
        ts = cfg.get("trade_scope") or cfg.get("acc_scope") or {}
        loan_types = ts.get("loanType") or []
    if isinstance(inquiry_purposes, str):
        inquiry_purposes = [inquiry_purposes]

    dpd_thresh  = cfg.get("dpd_threshold")
    dpd_op_raw  = (cfg.get("conditions") or {}).get("dpd_op") or ">="

    agg_map = {
        "count": "F.count('*')",
        "sum":   f"F.sum('{col}')",
        "avg":   f"F.avg('{col}')",
        "max":   f"F.max('{col}')",
        "min":   f"F.min('{col}')",
        "std":   f"F.stddev('{col}')",
        "flag":  "(F.count('*') > 0).cast('int')",
    }
    agg_expr = agg_map.get(agg, "F.count('*')")

    lines = [
        f"def compute_{name}_spark({table}):",
        f"    '''PySpark | {name} | {var_type} | {agg} | {window}'''",
        f"    from pyspark.sql.functions import months_between, current_date",
        f"    df = {table}.filter(",
        f"        months_between(current_date(), F.col('{date_col}').cast('date')) <= {w_months}",
        f"    )",
    ]

    if loan_types:
        lines.append(f"    df = df.filter(F.col('loan_type').isin({loan_types!r}))")
    if inquiry_purposes:
        lines.append(f"    df = df.filter(F.col('inquiry_purpose').isin({inquiry_purposes!r}))")

    if dpd_thresh:
        lines.append(f"    df = df.filter(F.col('dpd') {dpd_op_raw} {dpd_thresh})")

    lines.append(
        f"    return df.groupBy('customer_id').agg({agg_expr}.alias('{name}'))"
    )
    return "\n".join(lines)

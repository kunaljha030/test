"""core/security.py — JWT + password hashing (no bcrypt dependency)"""
from datetime import datetime, timedelta
from typing import Optional
import hashlib, hmac, json, base64, os
from core.config import settings

# ── Password Hashing (PBKDF2 — built into Python, no extra packages) ──────
def hash_password(password: str) -> str:
    salt = os.urandom(16).hex()
    key  = hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), 260000)
    return f"pbkdf2${salt}${key.hex()}"


def verify_password(plain: str, hashed: str) -> bool:
    try:
        if hashed.startswith("pbkdf2$"):
            _, salt, stored_key = hashed.split("$")
            key = hashlib.pbkdf2_hmac("sha256", plain.encode(), salt.encode(), 260000)
            return hmac.compare_digest(key.hex(), stored_key)
        # Legacy sha256 fallback
        legacy = hashlib.sha256(f"creditiq_salt_2024{plain}".encode()).hexdigest()
        return hmac.compare_digest(legacy, hashed)
    except Exception:
        return False


# ── JWT (pure Python fallback if jose not available) ──────────────────────
def create_access_token(data: dict, expires_delta: Optional[timedelta] = None) -> str:
    to_encode = data.copy()
    expire    = datetime.utcnow() + (
        expires_delta or timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
    )
    to_encode["exp"] = expire.isoformat()
    try:
        from jose import jwt
        to_encode["exp"] = int(expire.timestamp())
        return jwt.encode(to_encode, settings.SECRET_KEY, algorithm=settings.ALGORITHM)
    except Exception:
        payload = json.dumps(to_encode, default=str)
        return base64.urlsafe_b64encode(payload.encode()).decode()


def decode_token(token: str) -> Optional[dict]:
    try:
        from jose import jwt
        return jwt.decode(token, settings.SECRET_KEY, algorithms=[settings.ALGORITHM])
    except Exception:
        pass
    try:
        payload = base64.urlsafe_b64decode(token.encode()).decode()
        return json.loads(payload)
    except Exception:
        return None

from pydantic import BaseModel
from typing import Optional, Any, Dict
from datetime import datetime

class VariableCreate(BaseModel):
    build_name: str
    owner: str
    bureau: Optional[str] = None
    file_type: Optional[str] = None
    file_identifier: Optional[str] = None
    variable: Dict[str, Any] = {}

class VariableResponse(BaseModel):
    id: int
    name: str
    variable_type: str
    sub_category: Optional[str]
    measure: Optional[str]
    aggregation: Optional[str]
    time_window: Optional[str]
    product_scope: Optional[str]
    secured_scope: Optional[str]
    lender_scope: Optional[str]
    loan_type_scope: Optional[str]
    account_status_scope: Optional[str]
    ownership_scope: Optional[str]
    config: dict
    created_at: datetime
    class Config:
        from_attributes = True

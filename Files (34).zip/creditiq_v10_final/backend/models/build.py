from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime

class BuildCreate(BaseModel):
    name: str
    owner: str
    bureau: Optional[str] = None
    file_type: Optional[str] = None
    file_identifier: Optional[str] = None
    description: Optional[str] = None

class BuildResponse(BaseModel):
    id: int
    name: str
    owner: str
    bureau: Optional[str]
    file_type: Optional[str]
    file_identifier: Optional[str]
    description: Optional[str]
    created_at: datetime
    updated_at: datetime
    variable_count: Optional[int] = 0
    variables_by_type: Optional[dict] = {}
    class Config:
        from_attributes = True

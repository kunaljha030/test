"""
Bureau Variable Generator
==========================
Creates 2 variables per bureau (CIBIL, EQUIFAX, EXPERIAN, CRIF)
Executes against sample data and generates output files

Structure:
- 2 variables per bureau = 8 total variables
- Each variable captures key metrics from bureau data
- Output: JSON results with accuracy metrics
"""

import json
from typing import Dict, List, Any, Optional
from datetime import datetime

# ═══════════════════════════════════════════════════════════════════════════════
# BUREAU VARIABLE DEFINITIONS (2 per bureau)
# ═══════════════════════════════════════════════════════════════════════════════

BUREAU_VARIABLES = {
    "CIBIL": [
        {
            "id": "var_cibil_001",
            "name": "cibil_total_accounts_open",
            "description": "Total number of open/active accounts from CIBIL",
            "variable_type": "Account",
            "sub_category": "count",
            "measure": "total_accounts",
            "aggregation": "count",
            "time_window": "current",
            "logic": "Count accounts where account_status NOT IN ('Closed', 'Written-Off')",
            "expected_range": [0, 50],
            "data_source": "AccountSegment",
        },
        {
            "id": "var_cibil_002",
            "name": "cibil_total_outstanding_balance",
            "description": "Total outstanding balance across all CIBIL accounts",
            "variable_type": "Account",
            "sub_category": "amount",
            "measure": "outstanding_balance",
            "aggregation": "sum",
            "time_window": "current",
            "logic": "SUM(current_balance) for all active accounts",
            "expected_range": [0, 100000000],
            "data_source": "AccountSegment",
        },
    ],
    "EQUIFAX": [
        {
            "id": "var_equifax_001",
            "name": "equifax_secured_accounts_ratio",
            "description": "Ratio of secured to total accounts from Equifax",
            "variable_type": "Account",
            "sub_category": "ratio",
            "measure": "secured_ratio",
            "aggregation": "ratio",
            "time_window": "current",
            "logic": "COUNT(secured_accounts) / COUNT(total_accounts)",
            "expected_range": [0, 1],
            "data_source": "AccountInformation",
        },
        {
            "id": "var_equifax_002",
            "name": "equifax_recent_inquiries_3m",
            "description": "Number of inquiries in last 3 months from Equifax",
            "variable_type": "Enquiry",
            "sub_category": "volume",
            "measure": "inquiry_count",
            "aggregation": "count",
            "time_window": "3m",
            "logic": "COUNT(inquiries) WHERE inquiry_date >= (today - 90 days)",
            "expected_range": [0, 20],
            "data_source": "InquiryHistory",
        },
    ],
    "EXPERIAN": [
        {
            "id": "var_experian_001",
            "name": "experian_dpd_highest",
            "description": "Highest Days Past Due across all accounts",
            "variable_type": "Account",
            "sub_category": "delinquency",
            "measure": "max_dpd",
            "aggregation": "max",
            "time_window": "current",
            "logic": "MAX(dpd_value) across all accounts",
            "expected_range": [0, 180],
            "data_source": "AccountData",
        },
        {
            "id": "var_experian_002",
            "name": "experian_credit_utilization",
            "description": "Average credit utilization across credit products",
            "variable_type": "Account",
            "sub_category": "utilization",
            "measure": "avg_utilization",
            "aggregation": "avg",
            "time_window": "current",
            "logic": "AVG(current_balance / credit_limit) for credit accounts",
            "expected_range": [0, 1],
            "data_source": "AccountData",
        },
    ],
    "CRIF": [
        {
            "id": "var_crif_001",
            "name": "crif_account_age_months",
            "description": "Average age of accounts in months from CRIF",
            "variable_type": "Account",
            "sub_category": "age",
            "measure": "avg_account_age",
            "aggregation": "avg",
            "time_window": "current",
            "logic": "AVG(months_since_opened) for all accounts",
            "expected_range": [0, 360],
            "data_source": "TradeData",
        },
        {
            "id": "var_crif_002",
            "name": "crif_default_accounts_count",
            "description": "Count of defaulted/charged-off accounts from CRIF",
            "variable_type": "Account",
            "sub_category": "default",
            "measure": "default_count",
            "aggregation": "count",
            "time_window": "current",
            "logic": "COUNT(accounts) WHERE status IN ('Defaulted', 'Charged-Off', 'Written-Off')",
            "expected_range": [0, 10],
            "data_source": "TradeData",
        },
    ],
}


# ═══════════════════════════════════════════════════════════════════════════════
# VARIABLE EXECUTION ENGINE
# ═══════════════════════════════════════════════════════════════════════════════

class VariableExecutor:
    """Executes bureau variables against sample data"""

    def __init__(self):
        self.results = {}
        self.error_log = []
        self.execution_timestamp = datetime.now().isoformat()

    def execute_variable(
        self,
        variable: Dict[str, Any],
        bureau_data: Dict[str, Any],
        customer_id: str,
    ) -> Dict[str, Any]:
        """Execute single variable against customer data"""
        var_id = variable["id"]
        var_name = variable["name"]

        try:
            result_value = None

            # CIBIL VARIABLES
            if var_id == "var_cibil_001":
                # Count open accounts
                accounts = bureau_data.get("accounts", [])
                result_value = len(
                    [
                        a
                        for a in accounts
                        if a.get("account_status") not in ["Closed", "Written-Off"]
                    ]
                )

            elif var_id == "var_cibil_002":
                # Sum outstanding balance
                accounts = bureau_data.get("accounts", [])
                result_value = sum(
                    float(a.get("current_balance", 0)) for a in accounts
                )

            # EQUIFAX VARIABLES
            elif var_id == "var_equifax_001":
                # Secured ratio
                accounts = bureau_data.get("accounts", [])
                if len(accounts) == 0:
                    result_value = 0
                else:
                    secured_count = len(
                        [a for a in accounts if a.get("is_secured", False)]
                    )
                    result_value = secured_count / len(accounts)

            elif var_id == "var_equifax_002":
                # Inquiries in 3 months
                inquiries = bureau_data.get("inquiries", [])
                result_value = len(inquiries)

            # EXPERIAN VARIABLES
            elif var_id == "var_experian_001":
                # Max DPD
                accounts = bureau_data.get("accounts", [])
                dpd_values = [int(a.get("dpd", 0)) for a in accounts]
                result_value = max(dpd_values) if dpd_values else 0

            elif var_id == "var_experian_002":
                # Average credit utilization
                accounts = bureau_data.get("accounts", [])
                utilization_values = []
                for a in accounts:
                    credit_limit = float(a.get("credit_limit") or a.get("sanction_amount", 0))
                    current_balance = float(a.get("current_balance", 0))
                    if credit_limit > 0:
                        utilization_values.append(current_balance / credit_limit)
                result_value = (
                    sum(utilization_values) / len(utilization_values)
                    if utilization_values
                    else 0
                )

            # CRIF VARIABLES
            elif var_id == "var_crif_001":
                # Average account age
                accounts = bureau_data.get("accounts", [])
                ages = []
                for a in accounts:
                    date_opened = a.get("date_opened")
                    if date_opened:
                        try:
                            # Simple month calculation
                            ages.append(
                                (datetime.now() - datetime.fromisoformat(date_opened)).days // 30
                            )
                        except:
                            pass
                result_value = (
                    sum(ages) / len(ages) if ages else 0
                )

            elif var_id == "var_crif_002":
                # Count defaulted accounts
                accounts = bureau_data.get("accounts", [])
                result_value = len(
                    [
                        a
                        for a in accounts
                        if a.get("account_status")
                        in ["Defaulted", "Charged-Off", "Written-Off"]
                    ]
                )

            return {
                "variable_id": var_id,
                "variable_name": var_name,
                "customer_id": customer_id,
                "result": result_value,
                "status": "success",
                "execution_time": datetime.now().isoformat(),
            }

        except Exception as e:
            error_msg = f"Error executing {var_name}: {str(e)}"
            self.error_log.append(error_msg)
            return {
                "variable_id": var_id,
                "variable_name": var_name,
                "customer_id": customer_id,
                "result": None,
                "status": "error",
                "error": error_msg,
                "execution_time": datetime.now().isoformat(),
            }

    def execute_bureau_variables(
        self, bureau: str, bureau_data: Dict[str, Any], customer_id: str
    ) -> List[Dict[str, Any]]:
        """Execute all variables for a bureau"""
        bureau_results = []
        variables = BUREAU_VARIABLES.get(bureau, [])

        for variable in variables:
            result = self.execute_variable(variable, bureau_data, customer_id)
            bureau_results.append(result)

        return bureau_results


# ═══════════════════════════════════════════════════════════════════════════════
# ACCURACY VALIDATION
# ═══════════════════════════════════════════════════════════════════════════════

class AccuracyValidator:
    """Validates execution results against expected ranges"""

    def __init__(self):
        self.validation_report = {
            "total_variables": 0,
            "valid_results": 0,
            "accuracy_score": 0.0,
            "issues": [],
        }

    def validate_result(
        self, result: Dict[str, Any], variable_def: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Validate single result"""
        self.validation_report["total_variables"] += 1

        if result["status"] == "error":
            self.validation_report["issues"].append(
                f"EXECUTION_ERROR: {result['variable_name']} - {result['error']}"
            )
            return {"valid": False, "reason": "execution_error"}

        result_value = result["result"]
        expected_range = variable_def.get("expected_range", [None, None])

        if result_value is None:
            self.validation_report["issues"].append(
                f"NULL_VALUE: {result['variable_name']} returned None"
            )
            return {"valid": False, "reason": "null_value"}

        # Check range
        if expected_range[0] is not None and result_value < expected_range[0]:
            self.validation_report["issues"].append(
                f"OUT_OF_RANGE_LOW: {result['variable_name']} = {result_value} (min: {expected_range[0]})"
            )
            return {"valid": False, "reason": "out_of_range_low"}

        if expected_range[1] is not None and result_value > expected_range[1]:
            self.validation_report["issues"].append(
                f"OUT_OF_RANGE_HIGH: {result['variable_name']} = {result_value} (max: {expected_range[1]})"
            )
            return {"valid": False, "reason": "out_of_range_high"}

        self.validation_report["valid_results"] += 1
        return {"valid": True, "reason": "in_range"}

    def generate_report(self) -> Dict[str, Any]:
        """Generate accuracy report"""
        if self.validation_report["total_variables"] > 0:
            self.validation_report["accuracy_score"] = round(
                (
                    self.validation_report["valid_results"]
                    / self.validation_report["total_variables"]
                )
                * 100,
                2,
            )
        return self.validation_report


# ═══════════════════════════════════════════════════════════════════════════════
# MAIN EXECUTION
# ═══════════════════════════════════════════════════════════════════════════════

def generate_sample_bureau_data() -> Dict[str, Any]:
    """Generate sample bureau data for demonstration"""
    return {
        "CIBIL": {
            "accounts": [
                {
                    "account_number": "ACC001",
                    "account_status": "Active",
                    "current_balance": 50000,
                    "sanction_amount": 100000,
                    "credit_limit": 100000,
                    "dpd": 0,
                    "is_secured": True,
                    "date_opened": "2020-01-15",
                },
                {
                    "account_number": "ACC002",
                    "account_status": "Active",
                    "current_balance": 75000,
                    "sanction_amount": 200000,
                    "credit_limit": 200000,
                    "dpd": 15,
                    "is_secured": False,
                    "date_opened": "2021-06-20",
                },
                {
                    "account_number": "ACC003",
                    "account_status": "Closed",
                    "current_balance": 0,
                    "sanction_amount": 50000,
                    "credit_limit": None,
                    "dpd": 0,
                    "is_secured": True,
                    "date_opened": "2019-03-10",
                },
            ],
            "inquiries": [
                {"inquiry_date": "2024-01-01", "inquiry_amount": 100000},
                {"inquiry_date": "2024-02-15", "inquiry_amount": 150000},
            ],
        },
        "EQUIFAX": {
            "accounts": [
                {
                    "account_number": "EQ001",
                    "account_status": "Active",
                    "current_balance": 60000,
                    "sanction_amount": 150000,
                    "credit_limit": 150000,
                    "dpd": 0,
                    "is_secured": True,
                    "date_opened": "2020-05-10",
                },
                {
                    "account_number": "EQ002",
                    "account_status": "Active",
                    "current_balance": 80000,
                    "sanction_amount": 250000,
                    "credit_limit": 250000,
                    "dpd": 30,
                    "is_secured": False,
                    "date_opened": "2022-01-15",
                },
            ],
            "inquiries": [
                {"inquiry_date": "2024-03-01", "inquiry_amount": 200000},
            ],
        },
        "EXPERIAN": {
            "accounts": [
                {
                    "account_number": "EX001",
                    "account_status": "Active",
                    "current_balance": 45000,
                    "sanction_amount": 120000,
                    "credit_limit": 120000,
                    "dpd": 0,
                    "is_secured": True,
                    "date_opened": "2021-02-20",
                },
                {
                    "account_number": "EX002",
                    "account_status": "Active",
                    "current_balance": 90000,
                    "sanction_amount": 300000,
                    "credit_limit": 300000,
                    "dpd": 45,
                    "is_secured": False,
                    "date_opened": "2023-01-10",
                },
            ],
            "inquiries": [],
        },
        "CRIF": {
            "accounts": [
                {
                    "account_number": "CR001",
                    "account_status": "Active",
                    "current_balance": 55000,
                    "sanction_amount": 180000,
                    "credit_limit": 180000,
                    "dpd": 0,
                    "is_secured": True,
                    "date_opened": "2019-08-15",
                },
                {
                    "account_number": "CR002",
                    "account_status": "Written-Off",
                    "current_balance": 0,
                    "sanction_amount": 50000,
                    "credit_limit": None,
                    "dpd": 180,
                    "is_secured": False,
                    "date_opened": "2017-05-20",
                },
            ],
            "inquiries": [],
        },
    }


def main():
    """Main execution pipeline"""
    print("=" * 80)
    print("BUREAU VARIABLE GENERATOR & EXECUTOR")
    print("=" * 80)

    # Initialize
    executor = VariableExecutor()
    validator = AccuracyValidator()

    # Load sample data
    bureau_data = generate_sample_bureau_data()
    customer_id = "CUST001"

    # Execute all variables
    all_results = {
        "execution_timestamp": executor.execution_timestamp,
        "customer_id": customer_id,
        "bureaus": {},
    }

    for bureau, data in bureau_data.items():
        print(f"\n🏢 Processing {bureau}...")
        bureau_results = executor.execute_bureau_variables(bureau, data, customer_id)

        # Store results
        all_results["bureaus"][bureau] = {
            "variables_executed": len(bureau_results),
            "results": bureau_results,
        }

        # Validate each result
        for result in bureau_results:
            var_id = result["variable_id"]
            var_def = next(
                (v for v in BUREAU_VARIABLES[bureau] if v["id"] == var_id), {}
            )
            validation = validator.validate_result(result, var_def)

            status_icon = "✅" if validation["valid"] else "❌"
            print(
                f"  {status_icon} {result['variable_name']}: {result['result']} ({validation['reason']})"
            )

    # Generate accuracy report
    accuracy_report = validator.generate_report()

    # Save results
    output_data = {
        "metadata": {
            "title": "Bureau Variable Execution Report",
            "timestamp": executor.execution_timestamp,
            "total_bureaus": len(bureau_data),
            "total_variables": 8,
            "customer_id": customer_id,
        },
        "execution_results": all_results,
        "accuracy_validation": accuracy_report,
        "error_log": executor.error_log,
    }

    # Write JSON output
    output_file = "bureau_variable_execution_output.json"
    with open(output_file, "w") as f:
        json.dump(output_data, f, indent=2)

    print("\n" + "=" * 80)
    print(f"✅ EXECUTION COMPLETE")
    print("=" * 80)
    print(f"\n📊 ACCURACY REPORT:")
    print(f"  Total Variables: {accuracy_report['total_variables']}")
    print(f"  Valid Results: {accuracy_report['valid_results']}")
    print(f"  Accuracy Score: {accuracy_report['accuracy_score']}%")

    if accuracy_report["issues"]:
        print(f"\n⚠️  ISSUES FOUND ({len(accuracy_report['issues'])}):")
        for issue in accuracy_report["issues"][:5]:
            print(f"    - {issue}")

    print(f"\n💾 Output saved to: {output_file}")

    return output_data


if __name__ == "__main__":
    results = main()

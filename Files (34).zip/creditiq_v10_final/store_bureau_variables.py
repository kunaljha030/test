"""
store_bureau_variables.py
==========================
Insert the 8 bureau variables into the database

Usage:
  cd backend
  python ../store_bureau_variables.py
"""

import sys
import json
from datetime import datetime

# Add backend to path
sys.path.insert(0, ".")

from db.database import SessionLocal, engine
from db import models
from sqlalchemy.orm import Session

# Create all tables
models.Base.metadata.create_all(bind=engine)

# ═══════════════════════════════════════════════════════════════════════════════
# BUREAU VARIABLES (From bureau_variable_generator.py)
# ═══════════════════════════════════════════════════════════════════════════════

BUREAU_VARIABLES = {
    "CIBIL": [
        {
            "id": "var_cibil_001",
            "name": "cibil_total_accounts_open",
            "description": "Total number of open/active accounts from CIBIL",
            "variable_type": "Account",
            "sub_category": "count",
            "measure": "total_accounts",
            "aggregation": "count",
            "time_window": "current",
            "logic": "Count accounts where account_status NOT IN ('Closed', 'Written-Off')",
            "expected_range": [0, 50],
            "data_source": "AccountSegment",
        },
        {
            "id": "var_cibil_002",
            "name": "cibil_total_outstanding_balance",
            "description": "Total outstanding balance across all CIBIL accounts",
            "variable_type": "Account",
            "sub_category": "amount",
            "measure": "outstanding_balance",
            "aggregation": "sum",
            "time_window": "current",
            "logic": "SUM(current_balance) for all active accounts",
            "expected_range": [0, 100000000],
            "data_source": "AccountSegment",
        },
    ],
    "EQUIFAX": [
        {
            "id": "var_equifax_001",
            "name": "equifax_secured_accounts_ratio",
            "description": "Ratio of secured to total accounts from Equifax",
            "variable_type": "Account",
            "sub_category": "ratio",
            "measure": "secured_ratio",
            "aggregation": "ratio",
            "time_window": "current",
            "logic": "COUNT(secured_accounts) / COUNT(total_accounts)",
            "expected_range": [0, 1],
            "data_source": "AccountInformation",
        },
        {
            "id": "var_equifax_002",
            "name": "equifax_recent_inquiries_3m",
            "description": "Number of inquiries in last 3 months from Equifax",
            "variable_type": "Enquiry",
            "sub_category": "volume",
            "measure": "inquiry_count",
            "aggregation": "count",
            "time_window": "3m",
            "logic": "COUNT(inquiries) WHERE inquiry_date >= (today - 90 days)",
            "expected_range": [0, 20],
            "data_source": "InquiryHistory",
        },
    ],
    "EXPERIAN": [
        {
            "id": "var_experian_001",
            "name": "experian_dpd_highest",
            "description": "Highest Days Past Due across all accounts",
            "variable_type": "Account",
            "sub_category": "delinquency",
            "measure": "max_dpd",
            "aggregation": "max",
            "time_window": "current",
            "logic": "MAX(dpd_value) across all accounts",
            "expected_range": [0, 180],
            "data_source": "AccountData",
        },
        {
            "id": "var_experian_002",
            "name": "experian_credit_utilization",
            "description": "Average credit utilization across credit products",
            "variable_type": "Account",
            "sub_category": "utilization",
            "measure": "avg_utilization",
            "aggregation": "avg",
            "time_window": "current",
            "logic": "AVG(current_balance / credit_limit) for credit accounts",
            "expected_range": [0, 1],
            "data_source": "AccountData",
        },
    ],
    "CRIF": [
        {
            "id": "var_crif_001",
            "name": "crif_account_age_months",
            "description": "Average age of accounts in months from CRIF",
            "variable_type": "Account",
            "sub_category": "age",
            "measure": "avg_account_age",
            "aggregation": "avg",
            "time_window": "current",
            "logic": "AVG(months_since_opened) for all accounts",
            "expected_range": [0, 360],
            "data_source": "TradeData",
        },
        {
            "id": "var_crif_002",
            "name": "crif_default_accounts_count",
            "description": "Count of defaulted/charged-off accounts from CRIF",
            "variable_type": "Account",
            "sub_category": "default",
            "measure": "default_count",
            "aggregation": "count",
            "time_window": "current",
            "logic": "COUNT(accounts) WHERE status IN ('Defaulted', 'Charged-Off', 'Written-Off')",
            "expected_range": [0, 10],
            "data_source": "TradeData",
        },
    ],
}


def create_or_get_build(db: Session, build_name: str = "Bureau Variables Build") -> models.Build:
    """Create or get build for bureau variables"""
    existing = db.query(models.Build).filter(models.Build.name == build_name).first()
    if existing:
        print(f"✅ Using existing build: {build_name} (ID: {existing.id})")
        return existing

    build = models.Build(
        name=build_name,
        owner="system",
        bureau="Multi-Bureau",
        file_type="bureau_variable",
        file_identifier="bureau_variables_2026_03_25",
        description="Bureau variables generated from sample data - 2 per bureau",
        created_at=datetime.utcnow(),
        updated_at=datetime.utcnow(),
    )
    db.add(build)
    db.commit()
    db.refresh(build)
    print(f"✅ Created build: {build_name} (ID: {build.id})")
    return build


def store_variables_in_db(db: Session, build_id: int) -> tuple:
    """Insert all 8 variables into database"""

    total_stored = 0
    total_updated = 0
    total_errors = 0

    print("\n" + "=" * 80)
    print("STORING BUREAU VARIABLES IN DATABASE")
    print("=" * 80)

    for bureau, variables in BUREAU_VARIABLES.items():
        print(f"\n🏢 Bureau: {bureau}")
        print(f"   Variables to store: {len(variables)}")

        for var_def in variables:
            var_id = var_def["id"]
            var_name = var_def["name"]

            try:
                # Check if variable already exists
                existing = db.query(models.Variable).filter(
                    models.Variable.name == var_name,
                    models.Variable.build_id == build_id,
                ).first()

                config = {
                    "variable_id": var_id,
                    "description": var_def["description"],
                    "logic": var_def["logic"],
                    "expected_range": var_def["expected_range"],
                    "data_source": var_def["data_source"],
                }

                if existing:
                    # Update existing
                    existing.variable_type = var_def["variable_type"]
                    existing.sub_category = var_def["sub_category"]
                    existing.measure = var_def["measure"]
                    existing.aggregation = var_def["aggregation"]
                    existing.time_window = var_def["time_window"]
                    existing.config_json = json.dumps(config)
                    existing.source = "bureau_generator"
                    db.commit()
                    print(
                        f"   ✏️  UPDATED: {var_name}"
                    )
                    total_updated += 1

                else:
                    # Create new
                    new_var = models.Variable(
                        name=var_name,
                        build_id=build_id,
                        variable_type=var_def["variable_type"],
                        sub_category=var_def["sub_category"],
                        measure=var_def["measure"],
                        aggregation=var_def["aggregation"],
                        time_window=var_def["time_window"],
                        product_scope="all",
                        secured_scope="all",
                        lender_scope="all",
                        loan_type_scope="all",
                        account_status_scope="all",
                        ownership_scope="all",
                        config_json=json.dumps(config),
                        source="bureau_generator",
                        created_at=datetime.utcnow(),
                    )
                    db.add(new_var)
                    db.commit()
                    print(
                        f"   ✅ CREATED: {var_name} (ID: {new_var.id})"
                    )
                    total_stored += 1

            except Exception as e:
                print(f"   ❌ ERROR storing {var_name}: {str(e)}")
                db.rollback()
                total_errors += 1

    print("\n" + "=" * 80)
    print("STORAGE COMPLETE")
    print("=" * 80)
    print(f"✅ Created: {total_stored}")
    print(f"✏️  Updated: {total_updated}")
    print(f"❌ Errors: {total_errors}")
    print()

    return total_stored, total_updated, total_errors


def verify_storage(db: Session, build_id: int) -> dict:
    """Verify that all 8 variables are stored in database"""

    print("\n" + "=" * 80)
    print("VERIFICATION - CHECKING DATABASE")
    print("=" * 80)

    variables = db.query(models.Variable).filter(
        models.Variable.build_id == build_id
    ).all()

    print(f"\n✅ Total variables in database: {len(variables)}")

    stored_data = {}

    for var in variables:
        bureau = None
        for b in BUREAU_VARIABLES.keys():
            if var.name.lower().startswith(b.lower()):
                bureau = b
                break

        if bureau not in stored_data:
            stored_data[bureau] = []

        config = json.loads(var.config_json or "{}")

        stored_data[bureau].append(
            {
                "id": var.id,
                "name": var.name,
                "type": var.variable_type,
                "aggregation": var.aggregation,
                "config": config,
            }
        )

        print(f"\n📊 {var.name}")
        print(f"   ID: {var.id}")
        print(f"   Type: {var.variable_type}")
        print(f"   Sub-Category: {var.sub_category}")
        print(f"   Aggregation: {var.aggregation}")
        print(f"   Time Window: {var.time_window}")

    print("\n" + "=" * 80)
    print("SUMMARY BY BUREAU")
    print("=" * 80)

    for bureau, vars_list in stored_data.items():
        print(f"\n🏢 {bureau}: {len(vars_list)} variables")
        for v in vars_list:
            print(f"   ✅ {v['name']}")

    return stored_data


def main():
    """Main execution"""
    db = SessionLocal()

    try:
        # Step 1: Create/get build
        build = create_or_get_build(db, "Bureau Variables Build")

        # Step 2: Store variables
        stored, updated, errors = store_variables_in_db(db, build.id)

        # Step 3: Verify
        stored_data = verify_storage(db, build.id)

        # Print summary
        print("\n" + "=" * 80)
        print("✅ OPERATION COMPLETE")
        print("=" * 80)
        print(f"Build ID: {build.id}")
        print(f"Build Name: {build.name}")
        print(f"Variables Created: {stored}")
        print(f"Variables Updated: {updated}")
        print(f"Errors: {errors}")
        print(f"\n💾 All 8 variables stored in database!")
        print(f"\nNext: Query variables with:")
        print(f"  SELECT * FROM variables WHERE build_id = {build.id};")
        print()

    finally:
        db.close()


if __name__ == "__main__":
    main()

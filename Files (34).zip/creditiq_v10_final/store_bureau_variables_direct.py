"""
store_bureau_variables_direct.py
==================================
Store variables directly using SQLite without dependencies
"""

import sqlite3
import json
from datetime import datetime

# Use SQLite database file - default location
DB_FILE = "credit_iq.db"  # Check actual location or use default

# Variables to store (8 total, 2 per bureau)
VARIABLES = [
    # CIBIL
    {
        "name": "cibil_total_accounts_open",
        "variable_type": "Account",
        "sub_category": "count",
        "measure": "total_accounts",
        "aggregation": "count",
        "time_window": "current",
        "config": {
            "variable_id": "var_cibil_001",
            "description": "Total number of open/active accounts from CIBIL",
            "logic": "Count accounts where account_status NOT IN ('Closed', 'Written-Off')",
            "expected_range": [0, 50],
            "data_source": "AccountSegment",
        },
        "source": "bureau_generator",
        "build_id": 1,
    },
    {
        "name": "cibil_total_outstanding_balance",
        "variable_type": "Account",
        "sub_category": "amount",
        "measure": "outstanding_balance",
        "aggregation": "sum",
        "time_window": "current",
        "config": {
            "variable_id": "var_cibil_002",
            "description": "Total outstanding balance across all CIBIL accounts",
            "logic": "SUM(current_balance) for all active accounts",
            "expected_range": [0, 100000000],
            "data_source": "AccountSegment",
        },
        "source": "bureau_generator",
        "build_id": 1,
    },
    # EQUIFAX
    {
        "name": "equifax_secured_accounts_ratio",
        "variable_type": "Account",
        "sub_category": "ratio",
        "measure": "secured_ratio",
        "aggregation": "ratio",
        "time_window": "current",
        "config": {
            "variable_id": "var_equifax_001",
            "description": "Ratio of secured to total accounts from Equifax",
            "logic": "COUNT(secured_accounts) / COUNT(total_accounts)",
            "expected_range": [0, 1],
            "data_source": "AccountInformation",
        },
        "source": "bureau_generator",
        "build_id": 1,
    },
    {
        "name": "equifax_recent_inquiries_3m",
        "variable_type": "Enquiry",
        "sub_category": "volume",
        "measure": "inquiry_count",
        "aggregation": "count",
        "time_window": "3m",
        "config": {
            "variable_id": "var_equifax_002",
            "description": "Number of inquiries in last 3 months from Equifax",
            "logic": "COUNT(inquiries) WHERE inquiry_date >= (today - 90 days)",
            "expected_range": [0, 20],
            "data_source": "InquiryHistory",
        },
        "source": "bureau_generator",
        "build_id": 1,
    },
    # EXPERIAN
    {
        "name": "experian_dpd_highest",
        "variable_type": "Account",
        "sub_category": "delinquency",
        "measure": "max_dpd",
        "aggregation": "max",
        "time_window": "current",
        "config": {
            "variable_id": "var_experian_001",
            "description": "Highest Days Past Due across all accounts",
            "logic": "MAX(dpd_value) across all accounts",
            "expected_range": [0, 180],
            "data_source": "AccountData",
        },
        "source": "bureau_generator",
        "build_id": 1,
    },
    {
        "name": "experian_credit_utilization",
        "variable_type": "Account",
        "sub_category": "utilization",
        "measure": "avg_utilization",
        "aggregation": "avg",
        "time_window": "current",
        "config": {
            "variable_id": "var_experian_002",
            "description": "Average credit utilization across credit products",
            "logic": "AVG(current_balance / credit_limit) for credit accounts",
            "expected_range": [0, 1],
            "data_source": "AccountData",
        },
        "source": "bureau_generator",
        "build_id": 1,
    },
    # CRIF
    {
        "name": "crif_account_age_months",
        "variable_type": "Account",
        "sub_category": "age",
        "measure": "avg_account_age",
        "aggregation": "avg",
        "time_window": "current",
        "config": {
            "variable_id": "var_crif_001",
            "description": "Average age of accounts in months from CRIF",
            "logic": "AVG(months_since_opened) for all accounts",
            "expected_range": [0, 360],
            "data_source": "TradeData",
        },
        "source": "bureau_generator",
        "build_id": 1,
    },
    {
        "name": "crif_default_accounts_count",
        "variable_type": "Account",
        "sub_category": "default",
        "measure": "default_count",
        "aggregation": "count",
        "time_window": "current",
        "config": {
            "variable_id": "var_crif_002",
            "description": "Count of defaulted/charged-off accounts from CRIF",
            "logic": "COUNT(accounts) WHERE status IN ('Defaulted', 'Charged-Off', 'Written-Off')",
            "expected_range": [0, 10],
            "data_source": "TradeData",
        },
        "source": "bureau_generator",
        "build_id": 1,
    },
]


def find_database():
    """Find the database file"""
    import os
    
    search_paths = [
        "backend/creditiq.db",
        "creditiq.db",
        "backend/credit_iq.db",
        "credit_iq.db",
        "backend/app.db",
        "app.db",
    ]
    
    for path in search_paths:
        if os.path.exists(path):
            print(f"✅ Found database: {path}")
            return path
    
    print("⚠️  Database not found, will create new SQLite database in backend/")
    return "backend/creditiq.db"


def create_variables_table(cursor):
    """Create variables table if it doesn't exist"""
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS variables (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name VARCHAR(255) NOT NULL UNIQUE,
            build_id INTEGER,
            variable_type VARCHAR(50),
            sub_category VARCHAR(100),
            measure VARCHAR(100),
            aggregation VARCHAR(50),
            time_window VARCHAR(50),
            product_scope VARCHAR(255),
            secured_scope VARCHAR(50),
            lender_scope TEXT,
            loan_type_scope TEXT,
            account_status_scope VARCHAR(100),
            ownership_scope VARCHAR(100),
            config_json TEXT,
            source VARCHAR(20),
            created_at DATETIME,
            updated_at DATETIME
        )
    """)


def store_variables():
    """Store variables in database"""
    
    db_path = find_database()
    
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # Create table first
        create_variables_table(cursor)
        conn.commit()
        
        print("\n" + "=" * 80)
        print("STORING 8 BUREAU VARIABLES IN DATABASE")
        print("=" * 80)
        print(f"Database: {db_path}\n")
        
        created = 0
        updated = 0
        errors = 0
        
        timestamp = datetime.utcnow().isoformat()
        
        for var in VARIABLES:
            try:
                var_name = var["name"]
                
                # Check if exists
                cursor.execute(
                    "SELECT id FROM variables WHERE name = ?",
                    (var_name,)
                )
                existing = cursor.fetchone()
                
                config_json = json.dumps(var["config"])
                
                if existing:
                    # Update
                    cursor.execute(
                        """
                        UPDATE variables 
                        SET variable_type = ?, sub_category = ?, measure = ?, 
                            aggregation = ?, time_window = ?, config_json = ?, 
                            source = ?, updated_at = ?
                        WHERE name = ?
                        """,
                        (
                            var["variable_type"],
                            var["sub_category"],
                            var["measure"],
                            var["aggregation"],
                            var["time_window"],
                            config_json,
                            var["source"],
                            timestamp,
                            var_name,
                        ),
                    )
                    print(f"✏️  UPDATED: {var_name}")
                    updated += 1
                else:
                    # Create
                    cursor.execute(
                        """
                        INSERT INTO variables 
                        (name, build_id, variable_type, sub_category, measure, 
                         aggregation, time_window, product_scope, secured_scope, 
                         lender_scope, loan_type_scope, account_status_scope, 
                         ownership_scope, config_json, source, created_at)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                        """,
                        (
                            var_name,
                            var["build_id"],
                            var["variable_type"],
                            var["sub_category"],
                            var["measure"],
                            var["aggregation"],
                            var["time_window"],
                            "all",
                            "all",
                            "all",
                            "all",
                            "all",
                            "all",
                            config_json,
                            var["source"],
                            timestamp,
                        ),
                    )
                    print(f"✅ CREATED: {var_name}")
                    created += 1
                
                conn.commit()
                
            except Exception as e:
                print(f"❌ ERROR: {var_name} - {str(e)}")
                errors += 1
        
        print("\n" + "=" * 80)
        print("STORAGE RESULTS")
        print("=" * 80)
        print(f"✅ Created: {created}")
        print(f"✏️  Updated: {updated}")
        print(f"❌ Errors: {errors}")
        print(f"\nTotal Variables in DB: {created + updated}")
        
        # Verify
        cursor.execute(
            "SELECT COUNT(*) FROM variables WHERE source = 'bureau_generator'"
        )
        count = cursor.fetchone()[0]
        print(f"\n📊 Verification: {count} bureau variables in database")
        
        # List them
        print("\nVariables stored:")
        cursor.execute(
            "SELECT id, name, variable_type FROM variables WHERE source = 'bureau_generator' ORDER BY id"
        )
        for row in cursor.fetchall():
            print(f"   {row[0]:3d}. {row[1]:45s} [{row[2]}]")
        
        conn.close()
        
        return True
        
    except sqlite3.DatabaseError as e:
        print(f"❌ Database error: {e}")
        return False
    except Exception as e:
        print(f"❌ Error: {e}")
        return False


if __name__ == "__main__":
    success = store_variables()
    if success:
        print("\n✅ Variables successfully stored in database!")
    else:
        print("\n❌ Failed to store variables")

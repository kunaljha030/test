# CreditIQ System Architecture & Workflow Diagram

## 🏗️ System Architecture Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                      CREDITIQ SYSTEM (v3)                       │
└─────────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────────────┐
│                    FRONTEND (Browser)                            │
├──────────────────────────────────────────────────────────────────┤
│                                                                  │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │              dashboard.html (Interactive UI)            │   │
│  │                                                         │   │
│  │  ┌─────────────┬──────────────┬───────────┬──────────┬──┐ │
│  │  │ Variable    │  Generator   │ Execution │ Results  │CM│ │
│  │  │ Browser     │  (Create)    │ (Execute) │ (View)   │PR│ │
│  │  └─────────────┴──────────────┴───────────┴──────────┴──┘ │
│  │                                                         │   │
│  │  Tabs: 📊 |  ⚙️ |  ▶️ |  📈 |  🔄                      │   │
│  │                                                         │   │
│  └─────────────────────────────────────────────────────────┘   │
│                            ↓                                    │
│                    fetch('/api/variables/...')                  │
└──────────────────────────────────────────────────────────────────┘
                             ↕ HTTP
┌──────────────────────────────────────────────────────────────────┐
│                    BACKEND (FastAPI)                             │
├──────────────────────────────────────────────────────────────────┤
│                                                                  │
│  ┌───────────────────────────────────────────────────────────┐  │
│  │         variable_management.py (15 Endpoints)            │  │
│  │                                                           │  │
│  │  GET    /api/variables/generate         ─┐              │  │
│  │  GET    /api/variables/list              ├─ Discovery   │  │
│  │  GET    /api/variables/production        │              │  │
│  │  GET    /api/variables/{id}/details     ─┘              │  │
│  │                                                           │  │
│  │  POST   /api/variables/bulk-create         ┐            │  │
│  │  POST   /api/variables/execute             ├─ Execution │  │
│  │  GET    /api/variables/batch/{id}          │            │  │
│  │  GET    /api/variables/batch/{id}/results ─┘            │  │
│  │                                                           │  │
│  │  POST   /api/variables/compare         ──  Analytics    │  │
│  │                                                           │  │
│  └───────────────────────────────────────────────────────────┘  │
│                            ↓                                    │
│  ┌───────────────────────────────────────────────────────────┐  │
│  │            Service Layer & Business Logic                │  │
│  │                                                           │  │
│  │   variable_generator.py                                  │  │
│  │   ├─ generate_all_variables()  →  8,128 variables       │  │
│  │   └─ Production subset         →  1,200 variables       │  │
│  │                                                           │  │
│  │   feature_engine.py                                      │  │
│  │   ├─ _compute_enquiry()        →  Inquiry features      │  │
│  │   ├─ _compute_trade()          →  Trade features        │  │
│  │   ├─ _compute_account()        →  Account features      │  │
│  │   ├─ _compute_trade_history()  →  DPD/payment features  │  │
│  │   └─ _compute_cross_product()  →  Inquiry↔Trade joins   │  │
│  │                                                           │  │
│  │   behavioral_engine.py                                   │  │
│  │   ├─ payment_consistency_score()    →  0-100 score      │  │
│  │   ├─ credit_stress_index()          →  Risk index       │  │
│  │   └─ 6 more behavioral composites...                    │  │
│  │                                                           │  │
│  └───────────────────────────────────────────────────────────┘  │
│                            ↓                                    │
│  ┌───────────────────────────────────────────────────────────┐  │
│  │             Database Layer (SQLAlchemy ORM)              │  │
│  │                                                           │  │
│  │   Variable     ← {name, type, category, config_json}    │  │
│  │   Build        ← {name, description, created_at}        │  │
│  │   ExecutionRun ← {build_id, bureau, status}             │  │
│  │   FeatureOutput← {run_id, customer_id, value, status}   │  │
│  │   Normalized*  ← {customer data from bureaus}           │  │
│  │                                                           │  │
│  └───────────────────────────────────────────────────────────┘  │
│                            ↓                                    │
│                       Database (.db)                            │
└──────────────────────────────────────────────────────────────────┘
```

---

## 🔄 Workflow Flow Diagrams

### Workflow 1: Data Scientist (UI-Based, 10-30 min)

```
START: Need features for ML model
  │
  ├─→ Open Dashboard (http://localhost:8000/dashboard.html)
  │
  ├─→ Tab 1: "📊 Variable Browser"
  │   └─→ Search: "trade_dpd" 
  │   └─→ Filter: "Trade" type
  │   └─→ View: 3,426 trade variables
  │
  ├─→ Tab 2: "⚙️ Generator"
  │   └─→ Select: "Production (1,200)"
  │   └─→ Name: "Q1-Experiment"
  │   └─→ Click: "Generate"
  │   └─→ Result: ✅ 1,200 variables created
  │
  ├─→ Tab 3: "▶️ Execution"
  │   └─→ Build: "Q1-Experiment"
  │   └─→ Customer: "BATCH-001"
  │   └─→ Types: All 5 selected
  │   └─→ Format: "JSON"
  │   └─→ Click: "Start Execution"
  │   └─→ Result: "Batch 42 queued"
  │   └─→ Wait: 5-30 minutes
  │   └─→ Status: Running → Completed
  │
  ├─→ Tab 4: "📈 Results"
  │   └─→ Batch: "42"
  │   └─→ Format: "JSON"
  │   └─→ Click: "Download"
  │   └─→ File: features_batch_42.json
  │
  ├─→ Python/Excel
  │   └─→ Load JSON → import json
  │   └─→ Convert DataFrame → pd.DataFrame(...)
  │   └─→ Train Model → model.fit(X, y)
  │
  END: ✅ 1,200 features ready for modeling
```

### Workflow 2: ML Engineer (API-Based, 5-20 min)

```
START: Automated feature pipeline
  │
  ├─→ Python: requests library
  │
  ├─→ Step 1: Generate
  │   └─→ GET /api/variables/generate?subset=production
  │   └─→ Response: 1,200 variables metadata
  │
  ├─→ Step 2: Create Build
  │   └─→ POST /api/variables/bulk-create
  │   └─→ Input: {build_id, subset: "production"}
  │   └─→ Response: {created_count: 1200}
  │
  ├─→ Step 3: Execute
  │   └─→ POST /api/variables/execute
  │   └─→ Input: {build_id, bureau: "CIBIL"}
  │   └─→ Response: {batch_id: 42}
  │
  ├─→ Step 4: Monitor (Poll every 5 sec)
  │   └─→ GET /api/variables/batch/42
  │   └─→ Loop until status == "completed"
  │
  ├─→ Step 5: Download
  │   └─→ GET /api/variables/batch/42/results?format=json
  │   └─→ Response: {results: [{customer_id, feature_name, value}]}
  │
  ├─→ Step 6: Process
  │   └─→ Convert to DataFrame
  │   └─→ Pivot to feature matrix (customers × features)
  │   └─→ Ready for sklearn/XGBoost/etc
  │
  END: ✅ Automatic daily pipeline running
```

### Workflow 3: Analyst (Comparison-Based, 5 min per comparison)

```
START: Compare two variables
  │
  ├─→ Open Dashboard
  │
  ├─→ Tab: "🔄 Comparison"
  │   ├─→ Variable 1: "enq_volume_count_1m"
  │   ├─→ Variable 2: "trade_dpd_history_consistency"
  │   ├─→ Sample: 100 customers
  │   └─→ Click: "Compare"
  │
  ├─→ Results:
  │   ├─→ Mean Comparison
  │   ├─→ Distribution
  │   ├─→ Correlation
  │   ├─→ Statistics (std, min, max)
  │   └─→ Insights
  │       • Correlation: 0.42 (moderate positive)
  │       • Var1 more volatile (std 2.1 vs 18.5)
  │       • Both useful but different signals
  │
  END: ✅ Feature comparison complete
```

---

## 📊 Data Flow Through System

```
USER ACTION (Frontend)
    ↓
  [Browser Event]
    ↓
fetch('/api/variables/...')
    ↓
HTTP Request (JSON payload)
    ↓
FastAPI Router (variable_management.py)
    ├─ Validate input (Pydantic)
    ├─ Extract parameters
    └─ Route to handler
    ↓
HANDLER FUNCTION
    ├─ Call service layer (variable_generator.py)
    ├─ Query database (SQLAlchemy models)
    ├─ Run feature engine (feature_engine.py)
    └─ Format response (JSON)
    ↓
Database (SQLAlchemy ORM)
    ├─ Execute SQL query
    └─ Return rows
    ↓
Service Layer
    ├─ Process results
    ├─ Call behavioral_engine if needed
    └─ Return formatted output
    ↓
HTTP Response (JSON)
    ↓
JavaScript Handler
    ├─ Parse JSON
    ├─ Update DOM
    └─ Show results
    ↓
USER SEES RESULT (Frontend UI)
```

---

## 🎯 Variable Generation Process

```
generate_all_variables()
    │
    ├─→ Enquiry Variables (714)
    │   ├─ Measures: volume, amount, recency, ratio
    │   ├─ Aggregations: count, sum, avg, max, min, std
    │   ├─ Time Windows: 1m, 3m, 6m, 12m, 24m, 36m
    │   └─ Total: 4 × 6 × 6 × 5 = ~714
    │
    ├─→ Trade Variables (3,426)
    │   ├─ Measures: volume, amount, dpd, balance, utilization
    │   ├─ Aggregations: 15+
    │   ├─ Time Windows: 6
    │   └─ Total: ~3,426
    │
    ├─→ Account Variables (1,878)
    │   ├─ Measures: tenure, balance, status, utilization
    │   ├─ Aggregations: 15+
    │   ├─ Time Windows: 6
    │   └─ Total: ~1,878
    │
    ├─→ Trade History Variables (2,040)
    │   ├─ Measures: DPD patterns, payment consistency
    │   ├─ Sub-categories: dpd_history, payment_pattern, balance_history
    │   ├─ Time Windows: 6
    │   └─ Total: ~2,040
    │
    └─→ Cross-Product Variables (70)
        ├─ Measures: Inquiry↔Trade ratios, concentration
        ├─ Sub-categories: volume_ratio, amount_ratio, mix_overlap
        └─ Total: ~70

TOTAL: 8,128 Variables Generated
         ↓
Production Curation (Select best 1,200)
         ↓
1,200 Production-Ready Variables
┌────────────┬─────────────┬─────────────┬────────────┬──────────┐
│ Enquiry    │ Trade       │ Account     │ Tr.History │ Cross    │
│ 240 vars   │ 240 vars    │ 240 vars    │ 240 vars   │ 70 vars  │
└────────────┴─────────────┴─────────────┴────────────┴──────────┘
```

---

## ⚡ Execution Timeline

```
USER CLICKS "START EXECUTION"
    ↓
[T=0s] Request queued
        • Batch ID created: 42
        • Status: "queued"
        • Job added to background queue
    ↓
[T=1-5s] Processing begins
        • Status: "running"
        • Feature computation starts
        • 1,200 variables begin calculating
    ↓
[T=5-30s] Computing features
        • For each customer:
        •   - Parse trade history (DPD string)
        •   - Calculate aggregations (avg, std, count)
        •   - Run behavioral scoring
        •   - Compute cross-product ratios
        •   - Store results in FeatureOutput table
        • Progress: Feature count increases
    ↓
[T=30min] Execution complete
        • Status: "completed"
        • Total: 1,200 features executed
        • Success: 1,195 features
        • Skipped: 5 features (missing data)
    ↓
USER CLICKS "DOWNLOAD RESULTS"
        • Results retrieved from FeatureOutput table
        • Formatted as JSON/CSV
        • File ready to download
    ↓
READY FOR ANALYSIS ✓
```

---

## 🔀 Feature Execution Routing

```
_execute_variable(config)
    │
    ├─→ variable_type == "Enquiry"?
    │   └─→ _compute_enquiry()
    │       ├─ Filter by inquiry_type
    │       ├─ Apply aggregation
    │       ├─ Apply time window
    │       └─ Return numeric value
    │
    ├─→ variable_type == "Trade"?
    │   └─→ _compute_trade()
    │       ├─ Filter by loan_type
    │       ├─ Filter by secured
    │       ├─ Apply aggregation
    │       ├─ Call feature_engine handlers
    │       └─ Return numeric value
    │
    ├─→ variable_type == "Account"?
    │   └─→ _compute_account()
    │       ├─ Account-level metrics
    │       ├─ Tenure, status, balance
    │       └─ Return numeric value
    │
    ├─→ variable_type == "Trade History"?
    │   └─→ _compute_trade_history()
    │       ├─ Parse DPD string (e.g., "00-00-30-30-60-90-00")
    │       ├─ Calculate sub-categories:
    │       │  ├─ dpd_bucket_counts
    │       │  ├─ payment_consistency (via behavioral_engine)
    │       │  ├─ recovery_rate
    │       │  └─ balance_trend
    │       └─ Return numeric value
    │
    └─→ variable_type == "Cross-Product"?
        └─→ _compute_cross_product()
            ├─ Join Enquiry + Trade data
            ├─ Calculate ratios:
            │  ├─ inquiry_vs_trade_volume
            │  ├─ amount_comparison
            │  └─ concentration_comparison
            ├─ Call behavioral_engine for scoring
            └─ Return numeric value
```

---

## 📋 API Request/Response Examples

### Generate Request
```bash
GET /api/variables/generate?subset=production&limit=1200
```

### Generate Response
```json
{
  "subset": "production",
  "total_generated": 1200,
  "estimated_total": 8128,
  "variables": [
    {
      "name": "enq_volume_count_1m",
      "variable_type": "Enquiry",
      "sub_category": "volume",
      "measure": "count",
      "aggregation": "count",
      "time_window": "1m",
      "loan_types": [],
      "secured_filter": null
    },
    ...
  ]
}
```

### Execute Request
```json
POST /api/variables/execute
{
  "build_id": 1,
  "bureau": "CIBIL",
  "variable_types": ["Enquiry", "Trade", "Account"],
  "output_format": "json",
  "limit": 5000
}
```

### Execute Response
```json
{
  "batch_id": 42,
  "build_id": 1,
  "status": "queued",
  "message": "Batch 42 queued for execution with 1200 variables",
  "variable_count": 1200
}
```

---

## 🎯 System Decision Logic

```
USER REQUEST
    │
    ├─ Is it a generation request?
    │  └─→ Call variable_generator.generate_all_variables()
    │      └─→ Filter by subset (production, enquiry, trade, etc.)
    │      └─→ Return variable metadata
    │
    ├─ Is it an execution request?
    │  └─→ Create ExecutionRun record in DB
    │      └─→ Queue background task
    │         ├─ For each customer:
    │         │  └─ For each variable:
    │         │     └─ _execute_variable(config)
    │         │        └─ Dispatch to sub-engine
    │         │        └─ Store in FeatureOutput
    │         └─ Update status: "completed"
    │
    ├─ Is it a status request?
    │  └─→ Query ExecutionRun table
    │      └─→ Count FeatureOutput records
    │      └─→ Return progress stats
    │
    └─ Is it a results request?
       └─→ Query FeatureOutput table
           └─→ Filter by batch_id
           └─→ Format as JSON/CSV
           └─→ Return data
```

---

## ✨ Summary: How Everything Connects

```
┌────────────────────────────────────────────────────────────────┐
│ USER (Data Scientist / ML Engineer / Analyst)                  │
└────────────────────────┬───────────────────────────────────────┘
                         │
        ┌────────────────┼────────────────┐
        │                │                │
        ▼                ▼                ▼
   Dashboard.html    requests.get()    requests.post()
        │                │                │
        └────────────────┴────────────────┘
                         │
                         ▼
              FastAPI Backend (main.py)
                         │
          ┌──────────────┴──────────────┐
          │                             │
          ▼                             ▼
    variable_management.py        Existing Routers
      (15 endpoints)              (auth, builds, etc.)
          │
    ┌─────┴──────────────────────────────┐
    │                                    │
    ▼                                    ▼
 Service Layer                      Database Layer
 ├─ variable_generator.py           ├─ Variable
 ├─ feature_engine.py               ├─ Build
 └─ behavioral_engine.py            ├─ ExecutionRun
                                    └─ FeatureOutput
    │
    └──→ Output: 8,128 variables
          • 1,200 production-ready
          • In JSON/CSV format
          • Ready for modeling
```

---

**This is your complete CreditIQ system architecture!** 🚀

For detailed usage: See `WORKFLOW_GUIDE.md`  
For quick reference: See `QUICK_REFERENCE.md`  
For API details: See `PHASE_3_FRONTEND_INTEGRATION.md`
